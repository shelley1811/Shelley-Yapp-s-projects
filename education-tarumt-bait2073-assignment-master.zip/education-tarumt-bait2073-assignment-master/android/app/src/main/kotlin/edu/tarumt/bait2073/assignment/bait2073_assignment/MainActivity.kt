package edu.tarumt.bait2073.assignment.bait2073_assignment

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()

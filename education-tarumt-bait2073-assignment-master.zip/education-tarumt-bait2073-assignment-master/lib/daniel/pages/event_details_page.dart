import 'package:flutter/material.dart';
import 'main_event_hub.dart';
import 'events_page.dart';
import 'filter_page.dart';
import 'registration_confirmation_page.dart';

class EventDetailsPage extends StatefulWidget {
  final Event event; //Details of the specific event to show
  final List<Map<String, String>> allEvents; //list of all upcoming events

  const EventDetailsPage({super.key, required this.event, required this.allEvents});

  @override
  State<EventDetailsPage> createState() => _EventDetailsPageState();
}

//This shows all the information about a selected event and allows user registration
class _EventDetailsPageState extends State<EventDetailsPage> {
  final _fullNameController = TextEditingController(); //Controls text input for full name
  final _phoneController = TextEditingController(); //Controls text input for phone number
  final _emergencyContactController = TextEditingController(); //Controls text input for emergency contact
  final _medicalConditionsController = TextEditingController(); //Controls text input for medical conditions

  //Function to get a list of upcoming events (without the current ones)
  List<Event> _getUpcomingEvents(Event registeredEvent) {
    final now = DateTime.now(); //Get current date and time
    return widget.allEvents //Go through all the events
        .where((eventMap) { //Keep only events that meet the following conditions
      try {
        final eventDate = DateTime.parse( // Convert the event's date string to a DateTime object.
            eventMap['date']!.replaceAll(RegExp(r'[A-Za-z]+ '), '').replaceAll(',', '')); // Clean up the date string.
        final eventTimeParts = eventMap['time']!.split(':'); // Split the time string into hours and minutes.
        final eventDateTime = eventDate.add(Duration(hours: int.parse(eventTimeParts[0]), minutes: int.parse(eventTimeParts[1].split(' ').first))); // Combine date and time.
        return eventDateTime.isAfter(now) && eventMap['title'] != registeredEvent.title; // Check if the event is in the future and not the currently viewed event.
      } catch (e) {
        print("Error parsing date/time for upcoming event: ${eventMap['title']}");
        return false;
      }
    })
        .map((eventMap) => Event( // Convert the filtered event maps into Event objects.
      title: eventMap['title']!,
      location: eventMap['location']!,
      date: eventMap['date']!,
      time: eventMap['time']!,
      category: eventMap['category']!,
      organizer: eventMap['organizer'] ?? 'Unknown', // Use 'Unknown' if no organizer is provided.
      description: eventMap['description'] ?? '', // Use an empty string if no description.
      briefDescription: eventMap['briefDescription'] ?? '', // Use an empty string if no brief description.
      image: eventMap['image'] ?? 'assets/images/placeholder.jpg', // Use a placeholder image if none is provided.
    ))
        .toList(); //Put all event objects into a list
  }

  // Get Upcoming Events: Finds and returns a list of events that are scheduled in the future
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Join Event', style: TextStyle(color: Colors.black)),
        backgroundColor: Colors.white,
        elevation: 0,
        leading: const BackButton(color: Colors.black),
        actions: const [
          Icon(Icons.share, color: Colors.black),
          SizedBox(width: 16),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Event Cover Image Placeholder
            ClipRRect(
              borderRadius: BorderRadius.circular(12),
              child: Image.asset(
                widget.event.image,
                height: 200,
                width: double.infinity,
                fit: BoxFit.cover,
                errorBuilder: (context, error, stackTrace) => Container(
                  height: 200,
                  color: Colors.grey[300],
                  alignment: Alignment.center,
                  child: const Text('Image not found'),
                ),
              ),
            ),
            const SizedBox(height: 16),
            Text(widget.event.title, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            Row(
              children: [
                const Icon(Icons.calendar_today, color: Colors.grey, size: 16),
                const SizedBox(width: 4),
                Text('${widget.event.date} • ${widget.event.time}', style: const TextStyle(color: Colors.grey)),
              ],
            ),
            const SizedBox(height: 4),
            Row(
              children: [
                const Icon(Icons.location_on, color: Colors.grey, size: 16),
                const SizedBox(width: 4),
                Text(widget.event.location, style: const TextStyle(color: Colors.grey)),
              ],
            ),
            const SizedBox(height: 16),
            const Divider(),
            const SizedBox(height: 16),

            // Event Organizer
            Row( // Arranges the organizer info horizontally.
              children: [
                const CircleAvatar( //profile picture
                  radius: 20,
                  backgroundColor: Colors.grey,
                  child: Icon(Icons.person_outline, color: Colors.white),
                ),
                const SizedBox(width: 8),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(widget.event.organizer, style: const TextStyle(fontWeight: FontWeight.bold)),
                    Text('Event Organizer', style: TextStyle(color: Colors.grey[600])),
                  ],
                ),
              ],
            ),
            const SizedBox(height: 16), //Empty space
            const Divider(), //Seperator line
            const SizedBox(height: 16), //Empty space

            // Brief Event Description
            const Text('About the Event', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)), // "About the Event" heading.
            const SizedBox(height: 8),
            Text(
              widget.event.description, // The full description of the event.
              style: const TextStyle(color: Colors.black87),
            ),
            const SizedBox(height: 16),
            const Divider(),
            const SizedBox(height: 16),

            // Registration Details
            const Text('Registration Details', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
            const SizedBox(height: 12),
            TextFormField( // Input field for full name.
              controller: _fullNameController,
              decoration: const InputDecoration(
                labelText: 'Full Name',
                hintText: 'Enter your full name',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 12),
            TextFormField( // Input field for phone number.
              controller: _phoneController,
              keyboardType: TextInputType.phone, // Suggests a phone keyboard.
              decoration: const InputDecoration(
                labelText: 'Phone Number',
                hintText: '+60', // Shows '+60 ' at the beginning.
                border: OutlineInputBorder(),
                prefixText: '+60 ',
              ),
            ),
            const SizedBox(height: 12),
            TextFormField( // Input field for emergency contact.
              controller: _emergencyContactController,
              keyboardType: TextInputType.phone,
              decoration: const InputDecoration(
                labelText: 'Emergency Contact',
                hintText: 'Emergency contact number',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 12),
            TextFormField( // Input field for medical conditions (can have multiple lines)
              controller: _medicalConditionsController,
              maxLines: 3,
              decoration: const InputDecoration(
                labelText: 'Any Medical Conditions?',
                hintText: 'Please specify if any',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 24),

            // Confirm Registration Button
            SizedBox( // Button that takes full width.
              width: double.infinity,
              child: ElevatedButton(
                onPressed: () {
                  final fullName = _fullNameController.text.trim(); // Get the entered full name (remove extra spaces).
                  final phone = _phoneController.text.trim(); // Get the entered phone number.
                  final emergencyContact = _emergencyContactController.text.trim(); // Get the emergency contact.
                  final medicalConditions = _medicalConditionsController.text.trim(); // Get the medical conditions.

                  if (fullName.isEmpty || phone.isEmpty) { // Check if full name or phone number is empty.
                    // Show an alert dialog if required fields are empty
                    showDialog( // Pop up a dialog box.
                      context: context,
                      builder: (context) => AlertDialog(
                        title: const Text('Missing Information'),
                        content: const Text('Please fill in all required fields (Full Name and Phone Number).'),
                        actions: [
                          TextButton(
                            onPressed: () => Navigator.pop(context),
                            child: const Text('OK'), // Close the dialog when "OK" is pressed.
                          ),
                        ],
                      ),
                    );
                    return; // Stops the process here, do not proceed with registration.
                  }

                  print('Full Name: $fullName'); // Print registration info
                  print('Phone Number: $phone');
                  print('Emergency Contact: $emergencyContact');
                  print('Medical Conditions: $medicalConditions');

                  final upcomingEvents = _getUpcomingEvents(widget.event); // Get the list of upcoming events.

                  Navigator.pushReplacement( // Go to the registration confirmation screen and replace the current screen.
                    context,
                    MaterialPageRoute(
                      builder: (context) => RegistrationConfirmationPage( //The confirmation screen
                        eventName: widget.event.title, //Pass event name
                        registeredEvent: widget.event, //Pass details
                        upcomingEvents: upcomingEvents, //Pass list of upcoming events
                        allEvents: widget.allEvents, //Pass list of all events
                      ),
                    ),
                  );
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.black,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                ),
                child: const Text('Confirm Registration', style: TextStyle(fontSize: 16)),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
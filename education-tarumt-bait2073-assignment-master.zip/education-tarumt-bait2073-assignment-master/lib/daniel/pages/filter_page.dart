import 'package:flutter/material.dart';
import 'events_page.dart';
import 'event_details_page.dart';
import 'main_event_hub.dart';
import 'registration_confirmation_page.dart';

//Filter page: Allowing users to filter events by date and location
class FilterPage extends StatefulWidget {
  final List<String> availableLocations; //List of locations to filter by
  final DateTime? initialStartDate; //Initial selected start date (if any)
  final DateTime? initialEndDate; //Initial selected end date (if any)
  final String? initialLocation; //Initial selected location (if any)
  final Function(String?)? onApplyFilter; // Callback function to apply the location filter.

  const FilterPage({
    super.key,
    required this.availableLocations,
    this.initialStartDate,
    this.initialEndDate,
    this.initialLocation,
    this.onApplyFilter, // Receive the callback function
  });

  @override
  State<FilterPage> createState() => _FilterPageState();
}
//State of the FilterPage widget
class _FilterPageState extends State<FilterPage> {
  DateTime? _startDate; //Selected start date
  DateTime? _endDate; //Selected end date
  String? _selectedLocation; //Selected location
  final TextEditingController _locationSearchController = TextEditingController(); // Controls the location search input.
  late List<String> _availableLocations; //Local copy of the available locations

  @override
  void initState() {
    super.initState();
    _availableLocations = widget.availableLocations; //Initialize with provided locations
    _startDate = widget.initialStartDate; //Sets initial start date
    _endDate = widget.initialEndDate; //Sets initial end date
    _selectedLocation = widget.initialLocation; //Sets initial location
    _locationSearchController.text = _selectedLocation ?? ''; //Sets initial text in location search box
  }

  //Function to show the date picker for selecting the start date
  Future<void> _selectStartDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: _startDate ?? DateTime.now(), // Use current date if none selected.
      firstDate: DateTime(2000),
      lastDate: DateTime(2100),
    );
    if (picked != null && picked != _startDate) {
      setState(() {
        _startDate = picked;  // Update the selected start date.
      });
    }
  }
  // Function to show the date picker for selecting the end date.
  Future<void> _selectEndDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: _endDate ?? DateTime.now(), // Use current date if none selected
      firstDate: DateTime(2000),
      lastDate: DateTime(2100),
    );
    if (picked != null && picked != _endDate) {
      setState(() {
        _endDate = picked; // Update the selected end date.
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Filters', style: TextStyle(color: Colors.black)),
        backgroundColor: Colors.white,
        elevation: 0,
        leading: const BackButton(color: Colors.black),
        actions: [
          IconButton(
            icon: const Icon(Icons.close, color: Colors.black), // The close button.
            onPressed: () {
              Navigator.pop(context); // Closes the filter screen.
            },
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Date', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
            const SizedBox(height: 8),
            TextFormField(
              readOnly: true, // Prevents any manual editing done by user
              onTap: () => _selectStartDate(context), // Shows date picker on tap.
              decoration: InputDecoration(
                labelText: 'Start Date',
                suffixIcon: const Icon(Icons.calendar_today), // Calendar icon.
                border: const OutlineInputBorder(),
                contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 16),
                hintText: _startDate == null ? 'Select start date' : '${_startDate!.day}/${_startDate!.month}/${_startDate!.year}', // Hint text.
              ),
            ),
            const SizedBox(height: 12),
            TextFormField(
              readOnly: true, // Prevents manual editing.
              onTap: () => _selectEndDate(context), // Show date picker on tap.
              decoration: InputDecoration(
                labelText: 'End Date',
                suffixIcon: const Icon(Icons.calendar_today), // Calendar icon.
                border: const OutlineInputBorder(),
                contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 16),
                hintText: _endDate == null ? 'Select end date' : '${_endDate!.day}/${_endDate!.month}/${_endDate!.year}', // Hint text.
              ),
            ),
            const SizedBox(height: 24),
            const Text('Location', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)), // Location filter heading.
            const SizedBox(height: 8),
            TextFormField(
              controller: _locationSearchController, // Connects to the text input.
              decoration: const InputDecoration(
                labelText: 'Search location',
                prefixIcon: Icon(Icons.search), // Search icon.
                border: OutlineInputBorder(),
                contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 16),
              ),
              onChanged: (value) {
                setState(() {
                  _locationSearchController.text = value; // Update search text.
                });
              },
            ),
            const SizedBox(height: 8),
            Expanded(
              child: ListView.builder(
                shrinkWrap: true,
                itemCount: _availableLocations.length, // Number of locations.
                itemBuilder: (context, index) {
                  final location = _availableLocations[index]; // Current location.
                  final isSelected = _selectedLocation == location;  // Check if selected.
                  // Show location if search is empty or if it matches the search term.
                  if (_locationSearchController.text.isEmpty ||
                      location.toLowerCase().contains(_locationSearchController.text.toLowerCase())) {
                    return RadioListTile<String>(
                      title: Text(location), // Displays the location name.
                      value: location, // Value of this radio button.
                      groupValue: _selectedLocation, // Currently selected value.
                      onChanged: (String? value) {
                        setState(() {
                          _selectedLocation = value; // Updates the selected location.
                          _locationSearchController.text = value ?? '';  // Updates search text.
                        });
                      },
                      selected: isSelected, // Marks it as selected if it is.
                    );
                  } else {
                    return const SizedBox.shrink(); // Hides if it doesn't match search.
                  }
                },
              ),
            ),
            const SizedBox(height: 24),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                Expanded(
                  child: OutlinedButton(
                    onPressed: () {
                      setState(() {
                        _startDate = null; //Reset start date
                        _endDate = null; //Reset end date
                        _selectedLocation = null; //Reset selected location
                        _locationSearchController.clear(); //Clear search input
                      });
                    },
                    child: const Text('Reset'), //Reset button text
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: ElevatedButton(
                    onPressed: () {
                      widget.onApplyFilter?.call(_selectedLocation); // Call the filter callback with selected location.
                      Navigator.pop(context, { // Go back to the previous screen with filter data.
                        'startDate': _startDate,
                        'endDate': _endDate,
                        'location': _selectedLocation,
                      });
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.black,
                      foregroundColor: Colors.white,
                    ),
                    child: const Text('Apply Filters'), // Apply filters button text.
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
import 'package:flutter/material.dart';
import 'events_page.dart';
import 'event_details_page.dart';
import 'filter_page.dart';

/// Shared Event model
class Event {
  final String title;
  final String date;
  final String time;
  final String location;
  final String category;
  final String organizer;
  final String description;
  final String briefDescription;
  final String image;

  Event({
    required this.title,
    required this.date,
    required this.time,
    required this.location,
    required this.category,
    required this.organizer,
    required this.description,
    this.briefDescription = '',
    required this.image,
  });
}

/// The renamed “home” for the Events module
class EventHomeScreen extends StatefulWidget {
  const EventHomeScreen({super.key});
  @override
  State<EventHomeScreen> createState() => _EventHomeScreenState();
}

class _EventHomeScreenState extends State<EventHomeScreen> {
  final TextEditingController _searchController = TextEditingController();
  List<Map<String, String>> _searchResults = [];
  final List<Map<String, String>> _allEvents = [
    {
      'title': 'Beach Cleanup Drive',
      'location': 'Pantai Batu Ferringhi, Penang',
      'date': 'Mar 15, 2025',
      'category': 'Environment',
      'image': 'assets/images/beach_cleanup.jpg',
    },
    // … your other event entries …
  ];

  void _searchEvents(String query) {
    setState(() {
      if (query.isEmpty) {
        _searchResults = [];
      } else {
        final q = query.toLowerCase();
        _searchResults = _allEvents.where((e) {
          return e['title']!.toLowerCase().contains(q)
              || e['location']!.toLowerCase().contains(q);
        }).toList();
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        title: const Text('CareCircle', style: TextStyle(color: Colors.black)),
        actions: [
          IconButton(
            icon: const Icon(Icons.notifications_none, color: Colors.black),
            onPressed: () {},
          ),
          IconButton(
            icon: const Icon(Icons.account_circle, color: Colors.black),
            onPressed: () {},
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Search Bar
            TextField(
              controller: _searchController,
              onChanged: _searchEvents,
              decoration: InputDecoration(
                hintText: 'Search for volunteering activities',
                prefixIcon: const Icon(Icons.search),
                filled: true,
                fillColor: Colors.grey.shade100,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide.none,
                ),
              ),
            ),
            const SizedBox(height: 24),

            if (_searchController.text.isNotEmpty)
              _buildSearchResults()
            else ...[
              _buildFeatured(),
              const SizedBox(height: 24),
              _buildCategories(),
              const SizedBox(height: 24),
              _buildUpcoming(),
            ]
          ],
        ),
      ),
    );
  }

  Widget _buildSearchResults() {
    if (_searchResults.isEmpty) {
      return const Text(
        'No events found matching your search.',
        style: TextStyle(fontStyle: FontStyle.italic),
      );
    }
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('Search Results (${_searchResults.length})',
            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        const SizedBox(height: 12),
        ListView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          itemCount: _searchResults.length,
          itemBuilder: (ctx, i) => _buildSearchResultCard(ctx, _searchResults[i], _allEvents),
        ),
      ],
    );
  }

  Widget _buildFeatured() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('Featured Events',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        const SizedBox(height: 12),
        Card(
          shape:
          RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          elevation: 2,
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  height: 150,
                  decoration: BoxDecoration(
                    color: Colors.grey.shade300,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Image.asset(
                    'assets/images/beach_cleanup.jpg',
                    width: double.infinity,
                    fit: BoxFit.cover,
                    errorBuilder: (context, error, stackTrace) => Container(
                      color: Colors.grey.shade300,
                      alignment: Alignment.center,
                      child: const Text('Image Failed'),
                    ),
                  ),
                ),
                const SizedBox(height: 12),
                const Text('Beach Cleanup Drive',
                    style: TextStyle(fontWeight: FontWeight.bold)),
                const Text('Pantai Batu Ferringhi, Penang'),
                const SizedBox(height: 6),
                Row(
                  children: const [
                    Icon(Icons.calendar_today, size: 16, color: Colors.grey),
                    SizedBox(width: 4),
                    Text('March 15, 2025'),
                  ],
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildCategories() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        const Text('Categories',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        TextButton(
          onPressed: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => const EventsPage(category: 'All Events'),
              ),
            );
          },
          child: const Text('See All',
              style: TextStyle(fontWeight: FontWeight.bold)),
        ),
      ],
    );
  }

  Widget _buildUpcoming() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: const [
        Text('Upcoming Events',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        SizedBox(height: 12),
        UpcomingEventCard(
            title: 'Food Bank Distribution',
            location: 'Kuala Lumpur',
            date: 'April 2, 2025'),
        UpcomingEventCard(
            title: 'Elderly Home Visit & Companionship',
            location: 'Seremban, Negeri Sembilan',
            date: 'April 20, 2025'),
      ],
    );
  }

  /// Helper: build each search‐result card
  Widget _buildSearchResultCard(
      BuildContext context,
      Map<String, String> event,
      List<Map<String, String>> allEvents,
      ) {
    return Card(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
      margin: const EdgeInsets.symmetric(vertical: 8),
      child: ListTile(
        leading: SizedBox(
          width: 80,
          height: 80,
          child: Image.asset(
            event['image']!,
            fit: BoxFit.cover,
            errorBuilder: (context, error, stackTrace) {
              return const Icon(Icons.event, color: Colors.blue);
            },
          ),
        ),
        title: Text(event['title']!),
        subtitle: Text(event['location']!),
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => EventDetailsPage(
                event: Event(
                  title: event['title']!,
                  date: event['date']!,
                  time: event['time']!,
                  location: event['location']!,
                  category: event['category']!,
                  organizer: event['organizer'] ?? 'Unknown',
                  description: event['description'] ?? '',
                  image: event['image']!,
                ),
                allEvents: allEvents,
              ),
            ),
          );
        },
      ),
    );
  }
}

/// Widget used in Featured, Categories & Upcoming
class UpcomingEventCard extends StatelessWidget {
  final String title, location, date;
  const UpcomingEventCard({
    super.key,
    required this.title,
    required this.location,
    required this.date,
  });
  @override
  Widget build(BuildContext context) {
    return Card(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      elevation: 2,
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title,
                style:
                const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
            const SizedBox(height: 6),
            Text(location, style: const TextStyle(color: Colors.grey)),
            const SizedBox(height: 6),
            Row(
              children: [
                const Icon(Icons.calendar_today, size: 16, color: Colors.grey),
                const SizedBox(width: 4),
                Text(date),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

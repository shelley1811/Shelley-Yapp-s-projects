import 'package:flutter/material.dart';
import 'main_event_hub.dart';
import 'event_details_page.dart';

class RegistrationConfirmationPage extends StatelessWidget {
  final Event registeredEvent;
  final List<Event> upcomingEvents;
  final List<Map<String, String>> allEvents;

  const RegistrationConfirmationPage({
    super.key,
    required this.registeredEvent,
    this.upcomingEvents = const [],
    required this.allEvents,
    required String eventName,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('CareCircle', style: TextStyle(color: Colors.black)),
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.black),
          onPressed: () {
            Navigator.pushReplacement(
              context,
              MaterialPageRoute(
                builder: (context) => const EventHomeScreen(),
              ),
            );
          },
        ),
        actions: const [
          Icon(Icons.notifications_none, color: Colors.black),
          SizedBox(width: 16),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            const SizedBox(height: 32),
            const Icon(Icons.check_circle_outline,
                color: Colors.green, size: 80),
            const SizedBox(height: 24),
            const Text(
              'Registration Confirmed!',
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 12),
            Text(
              'You\'re now registered for ${registeredEvent.title}',
              style: const TextStyle(fontSize: 16, color: Colors.black87),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 24),
            Card(
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12)),
              elevation: 1,
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(children: [
                      const Icon(Icons.person_outline, color: Colors.grey),
                      const SizedBox(width: 8),
                      Text(registeredEvent.title,
                          style: const TextStyle(fontWeight: FontWeight.bold)),
                    ]),
                    const SizedBox(height: 8),
                    Row(children: [
                      const Icon(Icons.calendar_today, color: Colors.grey),
                      const SizedBox(width: 8),
                      Text(registeredEvent.date),
                    ]),
                    const SizedBox(height: 8),
                    Row(children: [
                      const Icon(Icons.timer_outlined, color: Colors.grey),
                      const SizedBox(width: 8),
                      Text(registeredEvent.time),
                    ]),
                    const SizedBox(height: 8),
                    Row(children: [
                      const Icon(Icons.location_on_outlined,
                          color: Colors.grey),
                      const SizedBox(width: 8),
                      Text(registeredEvent.location),
                    ]),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 32),
            const Divider(),
            const SizedBox(height: 24),
            const Text('Upcoming Events',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 16),
            ListView.separated(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: upcomingEvents.length,
              separatorBuilder: (context, index) =>
              const SizedBox(height: 12),
              itemBuilder: (context, index) {
                final ev = upcomingEvents[index];
                return UpcomingEventCard(
                  title: ev.title,
                  location: ev.location,
                  date: ev.date,
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}

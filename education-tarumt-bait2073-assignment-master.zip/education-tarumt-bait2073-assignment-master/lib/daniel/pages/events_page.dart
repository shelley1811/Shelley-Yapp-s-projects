import 'package:flutter/material.dart';
import 'event_details_page.dart';
import 'filter_page.dart';
import 'main_event_hub.dart';
import 'registration_confirmation_page.dart';

class EventsPage extends StatefulWidget {
  final String category; //The categories of events to display

  const EventsPage({super.key, required this.category});

  @override
  State<EventsPage> createState() => _EventsPageState();
}

//This is the events list screen: Shows a list of events, filtered by category
class _EventsPageState extends State<EventsPage> {
  late String selectedCategory; //The currently selected category of events
  DateTime? _filteredStartDate; //The starting date for filtering items (if any)
  DateTime? _filteredEndDate; //The ending date for filtering items (if any)
  String? _filteredLocation; //The location to filter by events (if any)

  //Current list of event categories
  final List<String> categories = [
    "All Events", "Education", "Environment", "Healthcare", "Community"
  ];

  @override
  void initState() {
    super.initState();
    selectedCategory = widget.category; //Sets the initial category when the page loads
  }

  // Called when the page is first created
  //Function after filtering a location
  void _onLocationFiltered(String? location) {
    if (location != null && location.isNotEmpty) {
      // If a location is selected...
      String? relevantCategory = _getCategoryForLocation(location);
      if (relevantCategory != null) {
        setState(() {
          selectedCategory = relevantCategory;
        });
        //If a category is found, update the displayed category
      } else {
        setState(() {
          selectedCategory = "All Events"; // If no category is selected, show all events instead
        });
      }
    } else {
      setState(() {
        selectedCategory = "All Events";
      });
    }
  }

  // The logic after location filter: Updating the displayed category based on the chosen location
  // Helper function to determine the category for a location
  String? _getCategoryForLocation(String location) {
    final allEvents = [
      {
        'title': 'Beach Cleanup Drive',
        'location': 'Port Dickson, Negeri Sembilan',
        'date': 'Mar 15, 2025',
        'category': 'Environment',
        'image': 'assets/images/beach_cleanup.jpg',
      },
      {
        'title': 'English Teaching Program',
        'location': 'Petaling Jaya, Selangor',
        'date': 'Mar 20, 2025',
        'category': 'Education',
      },
      {
        'title': 'Food Bank Distribution',
        'location': 'Kuala Lumpur City Center',
        'date': 'Mar 25, 2025',
        'category': 'Community',
      },
      {
        'title': 'Food Bank Distribution',
        'location': 'Kuala Lumpur City Center',
        'date': 'Mar 25, 2025',
        'category': 'Community',
      },
      {
        'title': 'Tree-Replanting Initiative',
        'location': 'Hulu Langat, Selangor',
        'date': 'Apr 05, 2025',
        'category': 'Environment',
      },
      {
        'title': 'Online Math Tutoring for Underprivileged Students',
        'location': 'Online',
        'date': 'Apr 12, 2025',
        'category': 'Education',
      },
      {
        'title': 'Elderly Home Visit & Companionship',
        'location': 'Seremban, Negeri Sembilan',
        'date': 'Apr 20, 2025',
        'category': 'Community',
      },
      {
        'title': 'Coastal Cleanup & Marine Debris Collection',
        'location': 'Tanjung Bidara, Melaka',
        'date': 'Apr 27, 2025',
        'category': 'Environment',
      },
      {
        'title': 'Coding Workshop for Beginners',
        'location': 'Cyberjaya, Selangor',
        'date': 'May 04, 2025',
        'category': 'Education',
      },
      {
        'title': 'Community Garden Planting & Maintenance',
        'location': 'Shah Alam, Selangor',
        'date': 'May 11, 2025',
        'category': 'Community',
      },
      {
        'title': 'River Cleanup Initiative',
        'location': 'Sungai Klang, Kuala Lumpur',
        'date': 'May 18, 2025',
        'category': 'Environment',
      },
      {
        'title': 'Science Experiment Mentoring for Kids',
        'location': 'Melaka City',
        'date': 'May 25, 2025',
        'category': 'Education',
      },
      {
        'title': 'Distribution of Hygiene Kits to Vulnerable Families',
        'location': 'Ipoh, Perak',
        'date': 'Jun 01, 2025',
        'category': 'Community',
      },
    ];
    for (var event in allEvents) {
      if (event['location']!.toLowerCase().contains(location.toLowerCase())) {
        return event['category'];
      }
    }
    return null;
  }

  // Find Category by Location: Checks all events and returns the category of the first event found at the given location.
  List<Map<String, String>> _getAllEventsData() {
    return const [
      {
        'title': 'Beach Cleanup Drive',
        'location': 'Port Dickson, Negeri Sembilan',
        'date': 'Mar 15, 2025',
        'time': '8:00 AM',
        'category': 'Environment',
        'description': 'Join us for a morning of environmental stewardship as we clean up the beautiful beaches of Port Dickson. Let\'s work together to preserve our coastline and make a positive impact on our local ecosystem. Gloves and bags will be provided. Please wear comfortable clothing and bring a reusable water bottle.',
        'briefDescription': 'Help keep our beaches clean! Join us for a rewarding morning in Port Dickson.', // Add brief description
        'organizer': 'Green Earth Malaysia',
        'image': 'assets/images/beach_cleanup.jpg',
      },
      {
        'title': 'English Teaching Program',
        'location': 'Petaling Jaya, Selangor',
        'date': 'Mar 20, 2025',
        'time': '2:00 PM',
        'category': 'Education',
        'description': 'Volunteer your time to help students improve their English language skills. We are looking for patient and enthusiastic individuals to assist with conversation practice and basic grammar. No prior teaching experience is required.',
        'briefDescription': 'Share your English skills and make a difference in students\' lives in Petaling Jaya.',
        'organizer': 'Education For All Foundation',
      },
      {
        'title': 'Food Bank Distribution',
        'location': 'Kuala Lumpur City Center',
        'date': 'Mar 25, 2025',
        'time': '10:00 AM',
        'category': 'Community',
        'description': 'Assist us in distributing essential food items to families in need in the Kuala Lumpur city center. Your help will bring smiles and support to our community members facing hardship.',
        'briefDescription': 'Help distribute food to those in need in KL City Center.',
        'organizer': 'KL Community Aid',
      },
      {
        'title': 'Tree Re-planting Initiative',
        'location': 'Hulu Langat, Selangor',
        'date': 'Apr 05, 2025',
        'time': '9:00 AM',
        'category': 'Environment',
        'description': 'Be a part of our green mission to reforest degraded land in Hulu Langat. We will be planting native tree saplings to enhance biodiversity and combat climate change. Please bring gardening gloves and wear sturdy shoes. Lunch will be provided.',
        'briefDescription': 'Help reforest Selangor! Plant trees and support our ecosystem.',
        'organizer': 'Forest Restoration Society',
      },
      {
        'title': 'Online Math Tutoring for Underprivileged Students',
        'location': 'Online',
        'date': 'Apr 12, 2025',
        'time': '4:00 PM',
        'category': 'Education',
        'description': 'Share your math skills by providing online tutoring to students from underprivileged backgrounds. Help them grasp key concepts and improve their academic performance. Flexible hours are available, and training will be provided.',
        'briefDescription': 'Mentor students in math online and empower their learning journey.',
        'organizer': 'Digital Learning Initiative',
      },
      {
        'title': 'Elderly Home Visit & Companionship',
        'location': 'Seremban, Negeri Sembilan',
        'date': 'Apr 20, 2025',
        'time': '11:00 AM',
        'category': 'Community',
        'description': 'Spend a meaningful afternoon with the residents of a local elderly home in Seremban. Engage in conversations, play games, or simply offer companionship to bring joy and connection to their day. Your presence can make a big difference.',
        'briefDescription': 'Bring joy to the elderly! Visit and spend time with residents in Seremban.',
        'organizer': 'Care for Seniors Association',
      },
      {
        'title': 'Coastal Cleanup & Marine Debris Collection',
        'location': 'Tanjung Bidara, Melaka',
        'date': 'Apr 27, 2025',
        'time': '8:30 AM',
        'category': 'Environment',
        'description': 'Join us in preserving the beauty of Tanjung Bidara beach by collecting marine debris and cleaning up the coastline. Help protect marine life and maintain a clean environment for everyone to enjoy. Gloves and collection bags will be provided.',
        'briefDescription': 'Protect our oceans! Help clean up the coast of Tanjung Bidara.',
        'organizer': 'Ocean Conservation Project',
      },
      {
        'title': 'Coding Workshop for Beginners',
        'location': 'Cyberjaya, Selangor',
        'date': 'May 04, 2025',
        'time': '1:00 PM',
        'category': 'Education',
        'description': 'Volunteer to assist in a beginner-friendly coding workshop for young adults in Cyberjaya. Guide participants through basic programming concepts and help them build their first simple applications. Basic coding knowledge is beneficial but not mandatory.',
        'briefDescription': 'Inspire future coders! Help out at our beginner coding workshop.',
        'organizer': 'Tech Education Foundation',
      },
      {
        'title': 'Community Garden Planting & Maintenance',
        'location': 'Shah Alam, Selangor',
        'date': 'May 11, 2025',
        'time': '10:00 AM',
        'category': 'Community',
        'description': 'Contribute to a local community garden in Shah Alam by helping with planting vegetables, weeding, and general maintenance. Learn about sustainable gardening practices and connect with fellow community members.',
        'briefDescription': 'Get your hands dirty! Help grow food at our community garden.',
        'organizer': 'Sustainable Shah Alam',
      },
      {
        'title': 'River Cleanup Initiative',
        'location': 'Sungai Klang, Kuala Lumpur',
        'date': 'May 18, 2025',
        'time': '9:30 AM',
        'category': 'Environment',
        'description': 'Participate in an effort to clean up a section of the iconic Sungai Klang. Help remove trash and pollutants to improve the river\'s health and the surrounding environment. Wear appropriate attire and be prepared to get a little muddy!',
        'briefDescription': 'Restore our river! Join the Sungai Klang cleanup initiative.',
        'organizer': 'River Restoration Network',
      },
      {
        'title': 'Science Experiment Mentoring for Kids',
        'location': 'Melaka City',
        'date': 'May 25, 2025',
        'time': '2:30 PM',
        'category': 'Education',
        'description': 'Guide and mentor primary school children through fun and engaging science experiments in Melaka City. Help spark their curiosity and foster a love for science. All experiment materials will be provided.',
        'briefDescription': 'Inspire young scientists! Mentor kids through exciting experiments.',
        'organizer': 'Science for Young Minds',
      },
      {
        'title': 'Distribution of Hygiene Kits to Vulnerable Families',
        'location': 'Sham Alam, Selangor',
        'date': 'Jun 01, 2025',
        'time': '11:00 AM',
        'category': 'Community',
        'description': 'Assist in the distribution of essential hygiene kits to vulnerable families in the Ipoh area. Help ensure that community members have access to basic necessities that promote health and well-being.',
        'briefDescription': 'Support families in need! Help distribute essential hygiene kits in Ipoh.',
        'organizer': 'Community Welfare Society of Ipoh',
      },
    ];
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar( //Top bar of screen
        title: const Text("Events", style: TextStyle(color: Colors.black)), //Design for 'events' title
        backgroundColor: Colors.white,
        elevation: 0,
        leading: const BackButton(color: Colors.black), //Back button to go back to previous screen
        actions: [
          IconButton( //Filter icon
            icon: const Icon(Icons.filter_list, color: Colors.black),
            onPressed: () async {
              const List<String> malaysianStates = [ //List of Malaysian states for the filter
                "Johor",
                "Kedah",
                "Kelantan",
                "Melaka",
                "Negeri Sembilan",
                "Pahang",
                "Penang",
                "Perak",
                "Perlis",
                "Sabah",
                "Sarawak",
                "Selangor",
                "Terengganu",
                "Kuala Lumpur",
                "Labuan",
                "Putrajaya",
              ];
              final filters = await Navigator.push( //Going to the filter screen and waiting for results
                context,
                MaterialPageRoute(
                  builder: (context) => FilterPage( //The filter screen
                    availableLocations: malaysianStates, //Passes the list of states
                    initialStartDate: _filteredStartDate, // Pass current start date filter
                    initialEndDate: _filteredEndDate,     // Pass current end date filter
                    initialLocation: _filteredLocation, //Pass the current location filter
                    onApplyFilter: _onLocationFiltered, // Pass current location
                  ),
                ),
              ) as Map<String, dynamic>?; // Receive the filters back

              if (filters != null) { //If user applies any filters
                setState(() { //Updates the screen to show the filtered results
                  _filteredStartDate = filters['startDate'] as DateTime?; //Get the selected start date
                  _filteredEndDate = filters['endDate'] as DateTime?; //Get the selected end date
                  _filteredLocation = filters['location'] as String?; //Get the selected location
                });
              }
            },
          ), // Closing the filter button
        ],
      ),
      body: Column( //Arranging items vertically on screen
        children: [
          SizedBox( //Creating a fixed-height box
            height: 48,
            child: ListView.builder( //Builds a scrollable list of categories
              scrollDirection: Axis.horizontal,
              itemCount: categories.length,
              padding: const EdgeInsets.symmetric(horizontal: 8),
              itemBuilder: (context, index) {
                final cat = categories[index]; //The current category
                final selected = selectedCategory == cat; //Checks if the current category is selected
                return Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 4.0),
                  child: ChoiceChip( //Tappable chip that can be selected
                    label: Text(cat), //Name of the category of the chip
                    selected: selected, //Whether it is currently selected or not
                    onSelected: (val) { //What happens if the chip is tapped
                      setState(() { //Updates the screen to show the selected category
                        selectedCategory = cat;
                      });
                    },
                    selectedColor: Colors.black,
                    backgroundColor: Colors.grey[200],
                    labelStyle: TextStyle(
                      color: selected ? Colors.white : Colors.black,
                    ),
                  ),
                );
              },
            ),
          ),
          Expanded( //Takes up the remaining available vertical space
            child: ListView(
              padding: const EdgeInsets.all(8),
              children:
              _getFilteredEvents().map((event) => _buildEventCard(event)).toList(),
            ),
          ),
        ],
      ),
    );
  }

  //List containing all the event data as maps.
  List<Event> _getFilteredEvents({bool applyCategoryFilter = true}) {
    final allEventsData = [
      {
        'title': 'Beach Cleanup Drive',
        'location': 'Port Dickson, Negeri Sembilan',
        'date': 'Mar 15, 2025',
        'time': '8:00 AM',
        'category': 'Environment',
        'description': 'Join us for a morning of environmental stewardship as we clean up the beautiful beaches of Port Dickson. Let\'s work together to preserve our coastline and make a positive impact on our local ecosystem. Gloves and bags will be provided. Please wear comfortable clothing and bring a reusable water bottle.',
        'briefDescription': 'Help keep our beaches clean! Join us for a rewarding morning in Port Dickson.', // Add brief description
        'organizer': 'Green Earth Malaysia',
        'image' : 'assets/images/beach_cleanup.jpg',
      },
      {
        'title': 'English Teaching Program',
        'location': 'Petaling Jaya, Selangor',
        'date': 'Mar 20, 2025',
        'time': '2:00 PM',
        'category': 'Education',
        'description': 'Volunteer your time to help students improve their English language skills. We are looking for patient and enthusiastic individuals to assist with conversation practice and basic grammar. No prior teaching experience is required.',
        'briefDescription': 'Share your English skills and make a difference in students\' lives in Petaling Jaya.',
        'organizer': 'Education For All Foundation',
        'image': 'assets/images/english_tutor.jpg',
      },
      {
        'title': 'Food Bank Distribution',
        'location': 'Kuala Lumpur City Center',
        'date': 'Mar 25, 2025',
        'time': '10:00 AM',
        'category': 'Community',
        'description': 'Assist us in distributing essential food items to families in need in the Kuala Lumpur city center. Your help will bring smiles and support to our community members facing hardship.',
        'briefDescription': 'Help distribute food to those in need in KL City Center.',
        'organizer': 'KL Community Aid',
        'image': 'assets/images/food_bank.jpg',
      },
      {
        'title': 'Tree Re-planting Initiative',
        'location': 'Hulu Langat, Selangor',
        'date': 'Apr 05, 2025',
        'time': '9:00 AM',
        'category': 'Environment',
        'description': 'Be a part of our green mission to reforest degraded land in Hulu Langat. We will be planting native tree saplings to enhance biodiversity and combat climate change. Please bring gardening gloves and wear sturdy shoes. Lunch will be provided.',
        'briefDescription': 'Help reforest Selangor! Plant trees and support our ecosystem.',
        'organizer': 'Forest Restoration Society',
        'image': 'assets/images/tree_planting.jpg',
      },
      {
        'title': 'Online Math Tutoring for Underprivileged Students',
        'location': 'Online',
        'date': 'Apr 12, 2025',
        'time': '4:00 PM',
        'category': 'Education',
        'description': 'Share your math skills by providing online tutoring to students from underprivileged backgrounds. Help them grasp key concepts and improve their academic performance. Flexible hours are available, and training will be provided.',
        'briefDescription': 'Mentor students in math online and empower their learning journey.',
        'organizer': 'Digital Learning Initiative',
        'image': 'assets/images/online_math.jpg',
      },
      {
        'title': 'Elderly Home Visit & Companionship',
        'location': 'Seremban, Negeri Sembilan',
        'date': 'Apr 20, 2025',
        'time': '11:00 AM',
        'category': 'Community',
        'description': 'Spend a meaningful afternoon with the residents of a local elderly home in Seremban. Engage in conversations, play games, or simply offer companionship to bring joy and connection to their day. Your presence can make a big difference.',
        'briefDescription': 'Bring joy to the elderly! Visit and spend time with residents in Seremban.',
        'organizer': 'Care for Seniors Association',
        'image': 'assets/images/elderly_visit.jpg',
      },
      {
        'title': 'Coastal Cleanup & Marine Debris Collection',
        'location': 'Tanjung Bidara, Melaka',
        'date': 'Apr 27, 2025',
        'time': '8:30 AM',
        'category': 'Environment',
        'description': 'Join us in preserving the beauty of Tanjung Bidara beach by collecting marine debris and cleaning up the coastline. Help protect marine life and maintain a clean environment for everyone to enjoy. Gloves and collection bags will be provided.',
        'briefDescription': 'Protect our oceans! Help clean up the coast of Tanjung Bidara.',
        'organizer': 'Ocean Conservation Project',
        'image': 'assets/images/coastal_cleanup.jpg',
      },
      {
        'title': 'Coding Workshop for Beginners',
        'location': 'Cyberjaya, Selangor',
        'date': 'May 04, 2025',
        'time': '1:00 PM',
        'category': 'Education',
        'description': 'Volunteer to assist in a beginner-friendly coding workshop for young adults in Cyberjaya. Guide participants through basic programming concepts and help them build their first simple applications. Basic coding knowledge is beneficial but not mandatory.',
        'briefDescription': 'Inspire future coders! Help out at our beginner coding workshop.',
        'organizer': 'Tech Education Foundation',
        'image': 'assets/images/coding_workshop.jpg',
      },
      {
        'title': 'Community Garden Planting & Maintenance',
        'location': 'Shah Alam, Selangor',
        'date': 'May 11, 2025',
        'time': '10:00 AM',
        'category': 'Community',
        'description': 'Contribute to a local community garden in Shah Alam by helping with planting vegetables, weeding, and general maintenance. Learn about sustainable gardening practices and connect with fellow community members.',
        'briefDescription': 'Get your hands dirty! Help grow food at our community garden.',
        'organizer': 'Sustainable Shah Alam',
        'image': 'assets/images/community_garden.jpg',
      },
      {
        'title': 'River Cleanup Initiative',
        'location': 'Sungai Klang, Kuala Lumpur',
        'date': 'May 18, 2025',
        'time': '9:30 AM',
        'category': 'Environment',
        'description': 'Participate in an effort to clean up a section of the iconic Sungai Klang. Help remove trash and pollutants to improve the river\'s health and the surrounding environment. Wear appropriate attire and be prepared to get a little muddy!',
        'briefDescription': 'Restore our river! Join the Sungai Klang cleanup initiative.',
        'organizer': 'River Restoration Network',
        'image': 'assets/images/river_cleanup.jpg',
      },
      {
        'title': 'Science Experiment Mentoring for Kids',
        'location': 'Melaka City',
        'date': 'May 25, 2025',
        'time': '2:30 PM',
        'category': 'Education',
        'description': 'Guide and mentor primary school children through fun and engaging science experiments in Melaka City. Help spark their curiosity and foster a love for science. All experiment materials will be provided.',
        'briefDescription': 'Inspire young scientists! Mentor kids through exciting experiments.',
        'organizer': 'Science for Young Minds',
        'image': 'assets/images/science_experiment.jpg',
      },
      {
        'title': 'Distribution of Hygiene Kits to Vulnerable Families',
        'location': 'Shah Alam, Selangor',
        'date': 'Jun 01, 2025',
        'time': '11:00 AM',
        'category': 'Community',
        'description': 'Assist in the distribution of essential hygiene kits to vulnerable families in the Ipoh area. Help ensure that community members have access to basic necessities that promote health and well-being.',
        'briefDescription': 'Support families in need! Help distribute essential hygiene kits in Ipoh.',
        'organizer': 'Community Welfare Society of Ipoh',
        'image': 'assets/images/hygiene_kits.jpg',
      },
    ];

    // Convert the list of maps to a list of Event objects
    List<Event> allEvents = allEventsData.map((data) => Event( // Goes through each event data map and create an Event object.
      title: data['title']!,
      location: data['location']!,
      date: data['date']!,
      time: data['time']!,
      category: data['category']!,
      description: data['description']!,
      briefDescription: data['briefDescription']!,
      organizer: data['organizer']!,
      image: data['image'] ?? 'assets/images/placeholder.jpg', //using a default image is none is provided
    )).toList();

    Iterable<Event> filteredEvents = allEvents; // Start with all events

    // Filter by category first
    if (applyCategoryFilter && selectedCategory != "All Events") { // If filter by category and a specific category is selected.
      filteredEvents =
          filteredEvents.where((e) => e.category == selectedCategory); //Keeping only events matching the selected category
    }

    // Then filter by start date
    if (_filteredStartDate != null) { //A start date filter is set
      filteredEvents = filteredEvents.where((event) {
        try {
          final eventDate = DateTime.parse( //Converts the events' date string into a date object
              event.date.replaceAll(RegExp(r'[A-Za-z]+ '), '').replaceAll(',', '')); //Cleans up the date string for easier conversion
          return eventDate
              .isAfter(_filteredStartDate!.subtract(const Duration(days: 1))); //Checks if the event date is after the day before the selected start date
        } catch (e) {
          print("Error parsing date: ${event.date}");
          return true; // Include if parsing fails
        }
      });
    }

    // Then filter by end date
    if (_filteredEndDate != null) { //If an end date filter is set
      filteredEvents = filteredEvents.where((event) { // Keep events that are on or before the end date.
        try {
          final eventDate = DateTime.parse( //Converts the events' date string into a date object
              event.date.replaceAll(RegExp(r'[A-Za-z]+ '), '').replaceAll(',', '')); //Cleans up the date string for easier conversion
          return eventDate
              .isBefore(_filteredEndDate!.add(const Duration(days: 1)));
        } catch (e) {
          print("Error parsing date: ${event.date}");
          return true; // Include if parsing fails
        }
      });
    }

    // Finally, filter by location
    if (_filteredLocation != null && _filteredLocation!.isNotEmpty) { // If a location filter is set and it's not empty.
      filteredEvents = filteredEvents.where((event) =>
          event.location.toLowerCase().contains(_filteredLocation!.toLowerCase()));
    }

    return filteredEvents.toList(); // Convert the filtered events back into a list.
  }
  Widget _buildEventCard(Event event) {
    return Card(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      elevation: 2,
      margin: const EdgeInsets.symmetric(vertical: 8),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              height: 120,
              width: double.infinity,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(12),
                color: Colors.grey[300], // Fallback color
              ),
              child: Image.asset(
                event.image,
                width: double.infinity,
                fit: BoxFit.cover,
                errorBuilder: (context, error, stackTrace) {
                  return Center(
                    child: Text(event.title, style: const TextStyle(color: Colors.white70)),
                  );
                },
              ),
            ),
            const SizedBox(height: 8),
            Text(event.title,
                style: const TextStyle(fontWeight: FontWeight.bold)),
            Text(event.location),
            Row( // Arranges date/time and the "Join" button horizontally.
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row( // Arranges the calendar icon and date/time.
                  children: [
                    const Icon(Icons.calendar_today, size: 16),
                    const SizedBox(width: 4),
                    Text('${event.date} • ${event.time}'), // Event date and time.
                  ],
                ),
                ElevatedButton(
                  onPressed: () {
                    Navigator.push(  // Go to the event details screen.
                      context,
                      MaterialPageRoute(
                        builder: (_) => EventDetailsPage(
                            event: event,
                          allEvents: _getAllEventsData(),
                        ),
                      ),
                    );
                  },
                  child: const Text('Join'), // Text on the button.
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class UpcomingEventCard extends StatelessWidget {
  final String title;
  final String location;
  final String date;

  const UpcomingEventCard({
    required this.title,
    required this.location,
    required this.date,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      elevation: 2,
      child: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              title,
              style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
            ),
            const SizedBox(height: 6),
            Text(location, style: const TextStyle(color: Colors.grey)),
            const SizedBox(height: 6),
            Row(
              children: [
                const Icon(Icons.calendar_today, size: 16, color: Colors.grey),
                const SizedBox(width: 4),
                Text(date),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
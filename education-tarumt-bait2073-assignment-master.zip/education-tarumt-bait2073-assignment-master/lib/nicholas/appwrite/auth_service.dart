import 'package:appwrite/appwrite.dart';
import 'package:appwrite/models.dart' as aw;
import 'client.dart';

class AuthService {
  AuthService._();
  static final instance = AuthService._();

  final _account = Account(appwriteClient);

  Future<aw.User?> current() async {
    try { return await _account.get(); } catch (_) { return null; }
  }


  Future<void> logout() => _account.deleteSessions();

  Future<aw.Session> login(String email, String pwd) =>
      _account.createEmailPasswordSession(email: email, password: pwd);

  Future<aw.User?> register(String name, String email, String pwd) async {
    await _account.create(
        userId: ID.unique(), email: email, password: pwd, name: name);
    await login(email, pwd);
    return current();
  }

  Future<void> updateEmail(String email, String pwd) =>
      _account.updateEmail(email: email, password: pwd);

  Future<void> updatePassword(String newPwd, String oldPwd) =>
      _account.updatePassword(password: newPwd, oldPassword: oldPwd);

  Future<void> deactivate() => _account.updateStatus(); // v15 replacement for delete
}

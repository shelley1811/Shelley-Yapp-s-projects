import 'package:appwrite/appwrite.dart';

/// Appwrite config
const String appwriteEndpoint = 'https://cloud.appwrite.io/v1';
const String projectId        = '67d1bcf0003b2de21206';

const String databaseId   = 'community_db';
const String groupsColId  = 'groups_db';
const String msgsColId    = 'msgs_col';
const String bucketId     = 'community_uploads';
const membershipColId = 'memberships_col';

final Client appwriteClient = Client()
  ..setEndpoint(appwriteEndpoint)
  ..setProject(projectId)
  ..setSelfSigned(status: true);          // remove if using real TLS cert

import 'package:flutter/material.dart';
import '../appwrite/auth_service.dart';
import 'package:appwrite/models.dart' as aw;

class AuthState extends ChangeNotifier {
  final _svc = AuthService.instance;
  aw.User? _user;
  bool _loading = true;

  AuthState() {
    _init();
  }

  /* ───── getters ──────────────────────────────── */
  bool get loading   => _loading;
  aw.User? get user  => _user;
  bool get signedIn  => _user != null;

  /* ───── init / refresh ───────────────────────── */
  Future<void> _init() async {
    _user = await _svc.current();
    _loading = false;
    notifyListeners();
  }

  Future<void> refresh() async {
    _user = await _svc.current();
    notifyListeners();
  }

  /* ───── auth actions ─────────────────────────── */
  Future<String?> login(String e, String p) async {
    try {
      await _svc.login(e, p);
      await refresh();
      return null;
    } catch (e) {
      return e.toString();
    }
  }

  Future<String?> register(String n, String e, String p) async {
    try {
      await _svc.register(n, e, p);
      await refresh();
      return null;
    } catch (e) {
      return e.toString();
    }
  }

  Future<void> logout() async {
    await _svc.logout();
    _user = null;
    notifyListeners();
  }
}

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:appwrite/appwrite.dart';
import 'package:appwrite/models.dart' as aw;

import '../appwrite/client.dart';
import '../models/auth_state.dart';
import '../widgets/bottom_nav.dart';
import 'community_page.dart';

/// Appwrite Databases instance
final _db = Databases(appwriteClient);

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int _idx = 0;

  @override
  Widget build(BuildContext ctx) {
    final aw.User user = ctx.watch<AuthState>().user!;
    final pages = [
      _buildDashboard(ctx, user),
      _buildMePage(ctx, user),
      const CommunityPage(),
    ];

    return Scaffold(
      appBar: AppBar(
        title: Text('CareCircle • ${['Home','Me','Community'][_idx]}'),
      ),
      body: pages[_idx],
      bottomNavigationBar: CareBottomNav(
        index: _idx,
        onTap: (i) => setState(() => _idx = i),
      ),
    );
  }

  /// Home tab: welcome + stats
  Widget _buildDashboard(BuildContext ctx, aw.User user) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 24),
      child: SizedBox(
        width: double.infinity,
        child: Card(
          elevation: 4,
          shape:
          RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              CircleAvatar(
                radius: 36,
                backgroundColor: Colors.teal.shade200,
                child: const Icon(Icons.person, size: 48, color: Colors.white),
              ),
              const SizedBox(height: 16),
              Text('Welcome,', style: Theme.of(ctx).textTheme.titleMedium),
              Text(user.name ?? '',
                  style: Theme.of(ctx)
                      .textTheme
                      .headlineSmall
                      ?.copyWith(fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              Text(user.email ?? '',
                  style: Theme.of(ctx).textTheme.bodyMedium),
              const SizedBox(height: 16),

              // Groups created stat
              FutureBuilder<aw.DocumentList>(
                future: _db.listDocuments(
                  databaseId: databaseId,
                  collectionId: groupsColId,
                  queries: [Query.equal('ownerId', [user.$id])],
                ),
                builder: (c, snap) {
                  if (snap.connectionState == ConnectionState.waiting) {
                    return const Text('Groups created: loading...',
                        style: TextStyle(fontWeight: FontWeight.bold));
                  }
                  if (snap.hasError) {
                    return const Text('Groups created: error',
                        style: TextStyle(fontWeight: FontWeight.bold));
                  }
                  final count = snap.data!.total;
                  return Text('Groups created: $count',
                      style: const TextStyle(fontWeight: FontWeight.bold));
                },
              ),

              const SizedBox(height: 8),

              // Groups joined stat
              FutureBuilder<aw.DocumentList>(
                future: _db.listDocuments(
                  databaseId: databaseId,
                  collectionId: membershipColId,
                  queries: [Query.equal('memberId', [user.$id])],
                ),
                builder: (c, snap) {
                  if (snap.connectionState == ConnectionState.waiting) {
                    return const Text('Groups joined: loading...',
                        style: TextStyle(fontWeight: FontWeight.bold));
                  }
                  if (snap.hasError) {
                    return const Text('Groups joined: error',
                        style: TextStyle(fontWeight: FontWeight.bold));
                  }
                  final joinedCount = snap.data!.total;
                  return Text('Groups joined: $joinedCount',
                      style: const TextStyle(fontWeight: FontWeight.bold));
                },
              ),
            ]),
          ),
        ),
      ),
    );
  }

  /// Me tab: account settings + chat administration
  Widget _buildMePage(BuildContext ctx, aw.User user) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(children: [
        // Account settings button
        SizedBox(
          width: double.infinity,
          child: ElevatedButton.icon(
            icon: const Icon(Icons.settings),
            label: const Text('Account settings'),
            onPressed: () => Navigator.pushNamed(ctx, '/settings'),
          ),
        ),
        const SizedBox(height: 24),

        // Note card
        Card(
          color: Colors.yellow.shade100,
          margin: const EdgeInsets.symmetric(vertical: 8),
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Text(
              'Note: Below you can delete any group chats you have created. '
                  'Deleting a group will also remove all its memberships.',
              style: Theme.of(ctx).textTheme.bodyMedium,
            ),
          ),
        ),

        const SizedBox(height: 12),

        Align(
          alignment: Alignment.centerLeft,
          child: Text('Chat Administration',
              style: Theme.of(ctx).textTheme.titleLarge),
        ),
        const SizedBox(height: 12),

        FutureBuilder<aw.DocumentList>(
          future: _db.listDocuments(
            databaseId: databaseId,
            collectionId: groupsColId,
            queries: [Query.equal('ownerId', [user.$id])],
          ),
          builder: (c, snap) {
            if (snap.connectionState == ConnectionState.waiting) {
              return const Center(child: CircularProgressIndicator());
            }
            if (snap.hasError) {
              return const Text('Error loading your groups');
            }
            final docs = snap.data!.documents;
            if (docs.isEmpty) {
              return const Text('No group chats created');
            }
            return Column(
              children: docs.map((doc) {
                final name = doc.data['name'] as String? ?? 'Unnamed';
                return Card(
                  child: ListTile(
                    title: Text(name),
                    trailing: IconButton(
                      icon: const Icon(Icons.delete, color: Colors.red),
                      onPressed: () async {
                        try {
                          // delete memberships
                          final mems = await _db.listDocuments(
                            databaseId: databaseId,
                            collectionId: membershipColId,
                            queries: [Query.equal('groupId', [doc.$id])],
                          );
                          for (final m in mems.documents) {
                            await _db.deleteDocument(
                              databaseId: databaseId,
                              collectionId: membershipColId,
                              documentId: m.$id,
                            );
                          }
                          // delete group
                          await _db.deleteDocument(
                            databaseId: databaseId,
                            collectionId: groupsColId,
                            documentId: doc.$id,
                          );
                          setState(() {});
                          ScaffoldMessenger.of(ctx).showSnackBar(
                            const SnackBar(content: Text('Group deleted')),
                          );
                        } catch (e) {
                          ScaffoldMessenger.of(ctx).showSnackBar(
                            SnackBar(content: Text('Delete error: $e')),
                          );
                        }
                      },
                    ),
                  ),
                );
              }).toList(),
            );
          },
        ),
      ]),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/auth_state.dart';
import '../appwrite/auth_service.dart';

class SettingsPage extends StatefulWidget {
  const SettingsPage({super.key});
  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  final _email = TextEditingController();
  final _pwd   = TextEditingController();
  bool _busy = false;
  String? _msg;

  @override
  Widget build(BuildContext ctx) {
    final auth = ctx.watch<AuthState>();
    final svc  = AuthService.instance;

    return Scaffold(
      appBar: AppBar(title: const Text('Account Settings')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Text('Current E-mail: ${auth.user?.email ?? ''}'),
          const SizedBox(height: 24),

          TextField(
            controller: _email,
            decoration: const InputDecoration(labelText: 'New e-mail'),
          ),
          TextField(
            controller: _pwd,
            obscureText: true,
            decoration: const InputDecoration(labelText: 'Current password'),
          ),
          const SizedBox(height: 16),
          ElevatedButton(
            onPressed: _busy
                ? null
                : () async {
              setState(() {
                _busy = true;
                _msg = null;
              });
              try {
                await svc.updateEmail(_email.text, _pwd.text);
                await auth.login(_email.text, _pwd.text);
                await auth.refresh();
                setState(() => _msg = 'E-mail updated!');
              } catch (e) {
                setState(() => _msg = e.toString());
              }
              setState(() => _busy = false);
            },
            child: const Text('Change e-mail'),
          ),
          if (_msg != null) ...[
            const SizedBox(height: 12),
            Text(_msg!, style: const TextStyle(color: Colors.green)),
          ],

          const Divider(height: 32),

          // Deactivate account...
          OutlinedButton(
            style: OutlinedButton.styleFrom(foregroundColor: Colors.red),
            onPressed: () async {
              final ok = await showDialog<bool>(
                context: ctx,
                builder: (_) => AlertDialog(
                  title: const Text('Deactivate account?'),
                  content: const Text('You can reactivate later via support.'),
                  actions: [
                    TextButton(
                      onPressed: () => Navigator.pop(ctx, false),
                      child: const Text('Cancel'),
                    ),
                    FilledButton(
                      onPressed: () => Navigator.pop(ctx, true),
                      child: const Text('Deactivate'),
                    ),
                  ],
                ),
              );
              if (ok != true) return;
              await svc.deactivate();
              await auth.logout();
              // go back to login on root navigator
              Navigator.of(ctx, rootNavigator: true)
                  .pushNamedAndRemoveUntil('/login', (_) => false);
            },
            child: const Text('Deactivate account'),
          ),

          const Divider(height: 32),

          // Logout
          OutlinedButton.icon(
            icon: const Icon(Icons.logout),
            label: const Text('Logout'),
            onPressed: () async {
              await auth.logout();
              Navigator.of(ctx, rootNavigator: true)
                  .pushNamedAndRemoveUntil('/login', (_) => false);
            },
          ),

          if (_busy) const Center(child: CircularProgressIndicator()),
        ],
      ),
    );
  }
}

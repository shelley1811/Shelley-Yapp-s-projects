import 'dart:async';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:appwrite/appwrite.dart';
import 'package:appwrite/models.dart' as aw;
import 'package:provider/provider.dart';
import '../appwrite/client.dart';
import '../models/auth_state.dart';

/* ─── Appwrite handles ────────────────────────────────────────────── */
final _db   = Databases(appwriteClient);
final _sto  = Storage(appwriteClient);
final _pick = ImagePicker();

class GroupPage extends StatefulWidget {
  final aw.Document group;
  const GroupPage({super.key, required this.group});

  @override
  State<GroupPage> createState() => _GroupPageState();
}

class _GroupPageState extends State<GroupPage> {
  List<aw.Document> _messages = [];
  final Set<String> _msgIds   = {};             // quick de-dup
  bool _loading = true;
  final _msgCtl = TextEditingController();
  late final Timer _poll;                       // 3-second poller

  @override
  void initState() {
    super.initState();
    _fetchInitial();
    _poll = Timer.periodic(const Duration(seconds: 3), (_) => _fetchNew());
  }

  @override
  void dispose() {
    _poll.cancel();
    _msgCtl.dispose();
    super.dispose();
  }

  /* ─── Initial load (last 50 messages) ───────────────────────────── */
  Future<void> _fetchInitial() async {
    final res = await _db.listDocuments(
        databaseId: databaseId,
        collectionId: msgsColId,
        queries: [
          Query.equal('groupId', [widget.group.$id]),
          Query.orderDesc('createdAt'),
          Query.limit(50),
        ]);
    setState(() {
      _messages = res.documents;
      _msgIds.addAll(res.documents.map((d) => d.$id));
      _loading = false;
    });
  }

  /* ─── Poll: only fetch messages newer than the newest we have ───── */
  Future<void> _fetchNew() async {
    if (_messages.isEmpty) return;
    final latestIso = _messages.first.data['createdAt'] as String;

    final res = await _db.listDocuments(
        databaseId: databaseId,
        collectionId: msgsColId,
        queries: [
          Query.equal('groupId', [widget.group.$id]),
          Query.greaterThan('createdAt', latestIso),
          Query.orderDesc('createdAt'),
        ]);

    if (res.documents.isNotEmpty && mounted) {
      setState(() {
        for (final d in res.documents) {
          if (_msgIds.add(d.$id)) _messages.insert(0, d);
        }
      });
    }
  }

  /* ─── Send text or image (local insert + server save) ───────────── */
  Future<void> _send({String? text, XFile? img}) async {
    try {
      String? fileId;
      if (img != null) {
        final up = await _sto.createFile(
            bucketId: bucketId,
            fileId: ID.unique(),
            file: InputFile.fromPath(filename: img.name, path: img.path));
        fileId = up.$id;
      }

      final user = context.read<AuthState>().user!;
      final doc = await _db.createDocument(
          databaseId: databaseId,
          collectionId: msgsColId,
          documentId: ID.unique(),
          data: {
            'groupId'   : widget.group.$id,
            'authorId'  : user.$id,
            'authorName': user.name,
            'text'      : text ?? '',
            'imageId'   : fileId,
            'createdAt' : DateTime.now().toUtc().toIso8601String(),
          });

      // instant local display
      if (mounted) {
        setState(() {
          _msgIds.add(doc.$id);
          _messages.insert(0, doc);
        });
      }
    } on AppwriteException catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text('${e.code}: ${e.message}')));
      }
    }
  }

  /* ─── Helpers ───────────────────────────────────────────────────── */
  String _imgUrl(String fid) =>
      '${appwriteClient.endPoint}/storage/buckets/$bucketId/files/$fid/view?project=$projectId';

  String _fmt(DateTime d) =>
      '${d.year}-${d.month.toString().padLeft(2,'0')}-${d.day.toString().padLeft(2,'0')} '
          '${d.hour.toString().padLeft(2,'0')}:${d.minute.toString().padLeft(2,'0')}';

  /* ─── UI ─────────────────────────────────────────────────────────── */
  @override
  Widget build(BuildContext ctx) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.group.data['name'])),
      body: Column(
        children: [
          Expanded(
            child: _loading
                ? const Center(child: CircularProgressIndicator())
                : ListView.builder(
                reverse: true,
                itemCount: _messages.length,
                itemBuilder: (_, i) {
                  final m  = _messages[i];
                  final dt = DateTime.parse(m.data['createdAt']).toLocal();
                  return ListTile(
                    title: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          if (m.data['text']?.isNotEmpty == true)
                            Text(m.data['text']),
                          if (m.data['imageId'] != null)
                            Padding(
                                padding: const EdgeInsets.only(top: 4),
                                child: Image.network(
                                    _imgUrl(m.data['imageId']),
                                    height: 150,
                                    fit: BoxFit.cover)),
                        ]),
                    subtitle: Text(
                        '${m.data['authorName']} • ${_fmt(dt)}'),
                  );
                }),
          ),
          Row(
            children: [
              IconButton(
                  icon: const Icon(Icons.photo),
                  onPressed: () async {
                    final x = await _pick.pickImage(
                        source: ImageSource.gallery);
                    if (x != null) await _send(img: x);
                  }),
              Expanded(
                child: TextField(
                    controller: _msgCtl,
                    decoration:
                    const InputDecoration(hintText: 'Say something…'),
                    onSubmitted: (v) {
                      final t = v.trim();
                      if (t.isNotEmpty) {
                        _send(text: t);
                        _msgCtl.clear();
                      }
                    }),
              ),
              IconButton(
                  icon: const Icon(Icons.send),
                  onPressed: () {
                    final t = _msgCtl.text.trim();
                    if (t.isNotEmpty) {
                      _send(text: t);
                      _msgCtl.clear();
                    }
                  }),
            ],
          ),
        ],
      ),
    );
  }
}

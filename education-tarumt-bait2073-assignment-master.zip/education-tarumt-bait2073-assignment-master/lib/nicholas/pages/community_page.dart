import 'dart:async';
import 'dart:math';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:appwrite/appwrite.dart';
import 'package:appwrite/models.dart' as aw;

import '../appwrite/client.dart';
import '../models/auth_state.dart';
import 'group_page.dart';

/// Appwrite Databases instance
final _db = Databases(appwriteClient);

class CommunityPage extends StatefulWidget {
  const CommunityPage({super.key});
  @override
  State<CommunityPage> createState() => _CommunityPageState();
}

class _CommunityPageState extends State<CommunityPage> {
  late Future<List<aw.Document>> _future;
  late final Realtime _rtClient;
  late final RealtimeSubscription _rtSub;
  late final StreamSubscription _rtStreamSub;

  final TextEditingController _searchController = TextEditingController();
  String _searchQuery = '';

  @override
  void initState() {
    super.initState();
    _future = _loadMyGroups();

    // Subscribe to real-time updates on groups and memberships
    _rtClient = Realtime(appwriteClient);
    _rtSub = _rtClient.subscribe([
      'databases.$databaseId.collections.$groupsColId.documents',
      'databases.$databaseId.collections.$membershipColId.documents',
    ]);
    _rtStreamSub = _rtSub.stream.listen((_) {
      setState(() {
        _future = _loadMyGroups();
      });
    });
  }

  @override
  void dispose() {
    _rtStreamSub.cancel();
    _rtSub.close();
    _searchController.dispose();
    super.dispose();
  }

  /// Load all groups the user owns or has joined
  Future<List<aw.Document>> _loadMyGroups() async {
    final uid = context.read<AuthState>().user!.$id;

    // Groups the user owns
    final owned = await _db
        .listDocuments(
      databaseId: databaseId,
      collectionId: groupsColId,
      queries: [Query.equal('ownerId', [uid])],
    )
        .then((r) => r.documents);

    // Groups the user has joined (via membership)
    final memDocs = await _db
        .listDocuments(
      databaseId: databaseId,
      collectionId: membershipColId,
      queries: [Query.equal('memberId', [uid])],
    )
        .then((r) => r.documents);

    final joinedIds = memDocs.map((m) => m.data['groupId'] as String).toList();

    final joined = joinedIds.isEmpty
        ? <aw.Document>[]
        : await _db
        .listDocuments(
      databaseId: databaseId,
      collectionId: groupsColId,
      queries: [Query.equal('\$id', joinedIds)],
    )
        .then((r) => r.documents);

    return [...owned, ...joined];
  }

  /// Create a new group via dialog
  Future<void> _createGroup() async {
    final nameCtl = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('New group'),
        content: TextField(
          controller: nameCtl,
          decoration: const InputDecoration(labelText: 'Group name'),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Create')),
        ],
      ),
    );
    if (ok != true || !mounted) return;

    final uid = context.read<AuthState>().user!.$id;
    try {
      final doc = await _db.createDocument(
        databaseId: databaseId,
        collectionId: groupsColId,
        documentId: ID.unique(),
        data: {
          'name': nameCtl.text.trim(),
          'code': _randCode(),
          'ownerId': uid,
          'createdAt': DateTime.now().toUtc().toIso8601String(),
        },
      );
      if (!mounted) return;
      Navigator.push(context, MaterialPageRoute(builder: (_) => GroupPage(group: doc)));
    } on AppwriteException catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('${e.code}: ${e.message}')),
        );
      }
    }
  }

  /// Join an existing group via invite code dialog
  Future<void> _joinGroup() async {
    final codeCtl = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Join group'),
        content: TextField(
          controller: codeCtl,
          decoration: const InputDecoration(labelText: 'Invite code'),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Join')),
        ],
      ),
    );
    if (ok != true || !mounted) return;

    final code = codeCtl.text.trim().toUpperCase();
    try {
      final res = await _db.listDocuments(
        databaseId: databaseId,
        collectionId: groupsColId,
        queries: [Query.equal('code', [code])],
      );
      if (res.documents.isEmpty) throw 'Invalid code';

      final group = res.documents.first;
      final uid = context.read<AuthState>().user!.$id;
      await _db.createDocument(
        databaseId: databaseId,
        collectionId: membershipColId,
        documentId: ID.unique(),
        data: {'groupId': group.$id, 'memberId': uid},
      );
      if (!mounted) return;
      Navigator.push(context, MaterialPageRoute(builder: (_) => GroupPage(group: group)));
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(e.toString())),
        );
      }
    }
  }

  /// Generate a random 6-character code
  String _randCode() {
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    final rand = Random.secure();
    return List.generate(6, (_) => chars[rand.nextInt(chars.length)]).join();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Community')),
      body: Column(
        children: [
          // Search bar
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: TextField(
              controller: _searchController,
              decoration: InputDecoration(
                hintText: 'Search chats...',
                prefixIcon: const Icon(Icons.search),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
              ),
              onChanged: (val) => setState(() => _searchQuery = val.trim().toLowerCase()),
            ),
          ),

          // Group list
          Expanded(
            child: FutureBuilder<List<aw.Document>>(
              future: _future,
              builder: (ctx, snap) {
                if (snap.connectionState == ConnectionState.waiting) {
                  return const Center(child: CircularProgressIndicator());
                }
                if (snap.hasError) {
                  return Center(child: Text('Error loading groups: ${snap.error}'));
                }

                final allGroups = snap.data ?? [];
                final filtered = _searchQuery.isEmpty
                    ? allGroups
                    : allGroups.where((doc) {
                  final name = (doc.data['name'] as String?) ?? '';
                  return name.toLowerCase().contains(_searchQuery);
                }).toList();

                if (filtered.isEmpty) {
                  return Center(
                    child: Text(
                      _searchQuery.isEmpty
                          ? 'No groups yet.\nTap create or join below.'
                          : 'No chats found matching "$_searchQuery".',
                      textAlign: TextAlign.center,
                    ),
                  );
                }

                return ListView.builder(
                  padding: const EdgeInsets.all(16),
                  itemCount: filtered.length,
                  itemBuilder: (ctx, i) {
                    final g = filtered[i];
                    final name = (g.data['name'] as String?) ?? 'Unnamed';
                    return Card(
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                      child: ListTile(
                        leading: const Icon(Icons.group, color: Colors.teal),
                        title: Text(name, style: const TextStyle(fontWeight: FontWeight.bold)),
                        subtitle: Text('Code: ${g.data['code']}'),
                        trailing: const Icon(Icons.arrow_forward_ios, size: 16),
                        onTap: () => Navigator.push(
                          ctx,
                          MaterialPageRoute(builder: (_) => GroupPage(group: g)),
                        ),
                      ),
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),

      // Create / Join FABs
      floatingActionButton: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          FloatingActionButton.extended(
            heroTag: 'create',
            icon: const Icon(Icons.group_add),
            label: const Text('Create'),
            onPressed: _createGroup,
          ),
          const SizedBox(height: 12),
          FloatingActionButton.extended(
            heroTag: 'join',
            icon: const Icon(Icons.input),
            label: const Text('Join'),
            onPressed: _joinGroup,
          ),
        ],
      ),
    );
  }
}

import 'package:flutter/material.dart';

class CareBottomNav extends StatelessWidget {
  const CareBottomNav({super.key, required this.index, required this.onTap});

  final int index;
  final ValueChanged<int> onTap;

  @override
  Widget build(BuildContext ctx) {
    return NavigationBar(
      selectedIndex: index,
      onDestinationSelected: onTap,
      destinations: const [
        NavigationDestination(icon: Icon(Icons.dashboard), label: 'Home'),
        NavigationDestination(icon: Icon(Icons.person),    label: 'Me'),
        NavigationDestination(icon: Icon(Icons.group),     label: 'Community'),
      ],
    );
  }
}

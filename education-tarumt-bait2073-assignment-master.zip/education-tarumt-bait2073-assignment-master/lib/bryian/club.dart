import 'package:cloud_firestore/cloud_firestore.dart';

class Club {
  String name;
  String description;
  String creator;
  String category;
  String? imageUrl;
  int members;
  String status;
  Timestamp createdAt;

  Club({
    required this.name,
    required this.description,
    required this.creator,
    required this.category,
    this.imageUrl,
    required this.members,
    required this.status,
    required this.createdAt,
  });

  factory Club.fromMap(Map<String, dynamic> data) {
    return Club(
      name: data['name'] ?? '',
      description: data['description'] ?? '',
      creator: data['creator'] ?? '',
      category: data['category'] ?? '',
      imageUrl: data['image'] ?? '',
      members: data['members'] ?? 0,
      status: data['status'] ?? 'pending',
      createdAt: data['createdAt'] ?? Timestamp.now(),
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'name': name,
      'description': description,
      'creator': creator,
      'category': category,
      'image': imageUrl,
      'members': members,
      'status': status,
      'createdAt': createdAt,
    };
  }
}

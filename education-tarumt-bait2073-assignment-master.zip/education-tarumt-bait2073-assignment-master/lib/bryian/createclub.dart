import 'dart:io';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:image_picker/image_picker.dart';
import 'package:firebase_storage/firebase_storage.dart';

class CreateClubPage extends StatefulWidget {
  @override
  _CreateClubPageState createState() => _CreateClubPageState();
}

class _CreateClubPageState extends State<CreateClubPage> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _descController = TextEditingController();
  final TextEditingController _creatorController = TextEditingController();

  String? selectedCategory;
  File? _selectedImage;
  bool isSubmitting = false;

  final ImagePicker _picker = ImagePicker();

  Future<void> _pickImage() async {
    final pickedFile = await _picker.pickImage(source: ImageSource.gallery, imageQuality: 70); // reduce quality (smaller size)
    if (pickedFile != null) {
      setState(() {
        _selectedImage = File(pickedFile.path);
      });
    }
  }

  Future<String?> _uploadImage(File imageFile) async {
    try {
      final fileName = '${DateTime.now().millisecondsSinceEpoch}.jpg';
      final ref = FirebaseStorage.instance.ref().child('club_images/$fileName');

      final uploadTask = ref.putFile(imageFile);
      final snapshot = await uploadTask;

      if (snapshot.state == TaskState.success) {
        final downloadUrl = await ref.getDownloadURL();
        return downloadUrl;
      } else {
        throw Exception('Image upload failed');
      }
    } catch (e) {
      print('Image upload error: $e');
      ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Image upload failed. Please try again or pick a smaller image.'))
      );
      return null;
    }
  }


  Future<void> _submitClubProposal() async {
    if (!_formKey.currentState!.validate()) return;

    if (selectedCategory == null) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Please select a category')));
      return;
    }

    setState(() {
      isSubmitting = true;
    });

    final clubName = _nameController.text.trim();
    final clubDescription = _descController.text.trim();
    final creator = _creatorController.text.trim();
    final category = selectedCategory;
    String? imageUrl;

    // Upload image if selected
    if (_selectedImage != null) {
      imageUrl = await _uploadImage(_selectedImage!);
    }

    await FirebaseFirestore.instance.collection('clubs').add({
      'name': clubName,
      'description': clubDescription,
      'category': category,
      'creator': creator.isEmpty ? 'Anonymous' : creator,
      'members': 0,
      'status': 'pending',
      'image': imageUrl ?? '',
      'createdAt': Timestamp.now(),
    });

    setState(() {
      isSubmitting = false;
    });

    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Club proposal submitted for approval!')));
    Navigator.pop(context);
  }

  @override
  void dispose() {
    _nameController.dispose();
    _descController.dispose();
    _creatorController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Propose a Club')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: isSubmitting
            ? Center(child: CircularProgressIndicator())
            : Form(
          key: _formKey,
          child: ListView(
            children: [
              TextFormField(
                controller: _nameController,
                decoration: InputDecoration(labelText: 'Club Name'),
                validator: (value) {
                  if (value == null || value.trim().isEmpty) {
                    return 'Please enter club name';
                  }
                  return null;
                },
              ),
              SizedBox(height: 16),
              TextFormField(
                controller: _descController,
                decoration: InputDecoration(labelText: 'Description'),
                maxLines: 3,
                validator: (value) {
                  if (value == null || value.trim().isEmpty) {
                    return 'Please enter club description';
                  }
                  return null;
                },
              ),
              SizedBox(height: 16),
              TextFormField(
                controller: _creatorController,
                decoration: InputDecoration(labelText: 'Creator Name'),
                validator: (value) {
                  if (value == null || value.trim().isEmpty) {
                    return 'Please enter creator name';
                  }
                  return null;
                },
              ),
              SizedBox(height: 16),
              Text('Select Category:', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
              DropdownButton<String>(
                hint: Text('Choose Category'),
                value: selectedCategory,
                onChanged: (value) {
                  setState(() {
                    selectedCategory = value!;
                  });
                },
                items: ['Arts', 'Sports', 'Academic', 'Music', 'Coding' , 'Public Speaking' , 'Others']
                    .map((category) => DropdownMenuItem<String>(
                  value: category,
                  child: Text(category),
                ))
                    .toList(),
              ),
              SizedBox(height: 16),
              Text('Club Image (optional):', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
              SizedBox(height: 8),
              _selectedImage != null
                  ? Image.file(_selectedImage!, height: 150)
                  : Container(
                height: 150,
                color: Colors.grey.shade300,
                child: Icon(Icons.image, size: 50, color: Colors.grey),
              ),
              SizedBox(height: 8),
              ElevatedButton.icon(
                onPressed: _pickImage,
                icon: Icon(Icons.upload),
                label: Text('Pick Image'),
                style: ElevatedButton.styleFrom(backgroundColor: Colors.blueGrey),
              ),
              SizedBox(height: 24),
              ElevatedButton(
                onPressed: _submitClubProposal,
                child: Text('Submit Proposal'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Color(0xFF002147),
                  padding: EdgeInsets.symmetric(vertical: 14),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

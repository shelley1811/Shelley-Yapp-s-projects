// db_helper.dart

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'dart:typed_data';

class DBHelper {
  static final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  static final FirebaseStorage _storage = FirebaseStorage.instance;

  // ======== CLUB FUNCTIONS ========
  // Fetch approved clubs from Firestore
  static Future<List<Map<String, dynamic>>> getApprovedClubs() async {
    try {
      final querySnapshot = await _firestore.collection('clubs')
          .where('status', isEqualTo: 'approved')
          .get();
      return querySnapshot.docs.map((doc) => doc.data() as Map<String, dynamic>)
          .toList();
    } catch (e) {
      print("Error fetching approved clubs: $e");
      return [];
    }
  }

  // Fetch proposed clubs from Firestore
  static Future<List<Map<String, dynamic>>> getProposedClubs() async {
    try {
      final querySnapshot = await _firestore.collection('clubs')
          .where('status', isEqualTo: 'pending')
          .get();
      return querySnapshot.docs.map((doc) => doc.data() as Map<String, dynamic>)
          .toList();
    } catch (e) {
      print("Error fetching proposed clubs: $e");
      return [];
    }
  }

  // Add new club proposal to Firestore
  static Future<void> addClubProposal(Map<String, dynamic> clubData) async {
    try {
      await _firestore.collection('clubs').add(clubData);
      print("Club proposal added successfully");
    } catch (e) {
      print("Error adding club proposal: $e");
    }
  }

  // Fetch all clubs (including proposed and approved)
  static Future<List<Map<String, dynamic>>> getClubs() async {
    try {
      final querySnapshot = await _firestore.collection('clubs').get();
      return querySnapshot.docs.map((doc) => doc.data() as Map<String, dynamic>)
          .toList();
    } catch (e) {
      print("Error fetching all clubs: $e");
      return [];
    }
  }

  // Get ALL clubs (approved + proposed)
  static Future<List<Map<String, dynamic>>> getAllClubs() async {
    try {
      final querySnapshot = await _firestore.collection('clubs').get();
      return querySnapshot.docs.map((doc) =>
      {
        ...doc.data(),
        'id': doc.id, // Include document ID
      }).toList();
    } catch (e) {
      print("Error fetching clubs: $e");
      return [];
    }
  }


  // Update the status of a club proposal (approve/reject)
  static Future<void> updateClubStatus(String clubId, String newStatus) async {
    try {
      await _firestore.collection('clubs').doc(clubId).update({
        'status': newStatus,
      });
      print("Club status updated to $newStatus");
    } catch (e) {
      print("Error updating club status: $e");
    }
  }

  // Delete a club from Firestore
  static Future<void> deleteClub(String clubId) async {
    try {
      await _firestore.collection('clubs').doc(clubId).delete();
      print("Club deleted successfully");
    } catch (e) {
      print("Error deleting club: $e");
    }
  }

  // OPTIONAL: Add dummy clubs (run only once for testing)
  static Future<void> addDummyClubsToFirestore() async {
    final snapshot = await _firestore.collection('clubs').get();
    if (snapshot.docs.isEmpty) {
      List<Map<String, dynamic>> dummyClubs = [
        {
          'name': 'Badminton Club',
          'description': 'A club for badminton enthusiasts of all skill levels.',
          'category': 'Sports',
          'creator': 'Admin',
          'image': 'assets/Images/badminton.jpeg',
          'members': 12,
          'status': 'approved',
        },
        {
          'name': 'Photography Club',
          'description': 'Learn and practice photography with peers.',
          'category': 'Arts',
          'creator': 'Admin',
          'image': 'assets/Images/photography.png',
          'members': 20,
          'status': 'approved',
        },
        {
          'name': 'Basketball Club',
          'description': 'Join and play basketball games and tournaments.',
          'category': 'Sports',
          'creator': 'Admin',
          'image': 'assets/Images/basketball.jpeg',
          'members': 18,
          'status': 'approved',
        },
        {
          'name': 'Art Club',
          'description': 'Explore painting, drawing, and crafts together.',
          'category': 'Arts',
          'creator': 'Admin',
          'image': 'assets/Images/art.png',
          'members': 15,
          'status': 'approved',
        },
      ];

      for (var club in dummyClubs) {
        await _firestore.collection('clubs').add(club);
      }
      print("Dummy clubs added to Firestore.");
    } else {
      print("Clubs already exist in Firestore.");
    }
  }

  // ======== ADMIN FUNCTIONS ========

  // Validate admin credentials from Firestore
  static Future<bool> validateAdminCredentials(String username,
      String password) async {
    try {
      final snapshot = await _firestore
          .collection('admins')
          .where('username', isEqualTo: username)
          .where('password', isEqualTo: password)
          .get();

      return snapshot.docs.isNotEmpty;
    } catch (e) {
      print("Error validating admin credentials: $e");
      return false;
    }
  }

  // ======== IMAGE UPLOAD ========

  // Upload an image to Firebase Storage and return download URL
  static Future<String?> uploadImage(Uint8List imageData) async {
    try {
      final fileName = 'club_images/${DateTime.now().millisecondsSinceEpoch}.jpg';
      final storageRef = _storage.ref().child(fileName);

      // Upload file
      UploadTask uploadTask = storageRef.putData(
        imageData,
        SettableMetadata(contentType: 'image/jpeg'),
      );

      // Await upload completion
      TaskSnapshot snapshot = await uploadTask;
      String downloadURL = await snapshot.ref.getDownloadURL();

      return downloadURL;
    } catch (e) {
      print("Error uploading image: $e");
      return null;
    }
  }
}

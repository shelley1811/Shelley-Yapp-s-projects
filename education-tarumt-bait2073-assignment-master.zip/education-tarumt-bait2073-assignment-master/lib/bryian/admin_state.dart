class AdminState {
  static bool isAdmin = false;
}

import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'admin_state.dart';
import 'cocurriculum.dart';
import 'widgets/club_image.dart';


class ExploreClubsPage extends StatefulWidget {
  final bool isAdmin;
  final List<Map<String, dynamic>> approvedClubs;
  final List<Map<String, dynamic>> proposedClubs;
  final Function(List<Map<String, dynamic>>) onUpdateApprovedClubs;

  ExploreClubsPage({
    required this.isAdmin,
    required this.approvedClubs,
    required this.proposedClubs,
    required this.onUpdateApprovedClubs,
  });

  @override
  _ExploreClubsPageState createState() => _ExploreClubsPageState();
}

class _ExploreClubsPageState extends State<ExploreClubsPage> {
  String selectedCategory = "All";
  String searchQuery = "";
  final Set<String> joinedClubs = {};
  List<Map<String, dynamic>> approvedClubs = [];
  List<Map<String, dynamic>> proposedClubs = [];
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    _fetchClubsFromFirestore();
  }

  Future<void> _fetchClubsFromFirestore() async {
    final snapshot = await FirebaseFirestore.instance.collection('clubs').get();
    final clubs = snapshot.docs.map((doc) {
      final data = doc.data();
      data['id'] = doc.id; // Attach document ID
      return data;
    }).toList();

    final approved = clubs.where((club) => club['status'] == 'approved').toList();
    final pending = clubs.where((club) => club['status'] == 'pending').toList();

    setState(() {
      approvedClubs = approved;
      proposedClubs = pending;
      isLoading = false;
    });

    widget.onUpdateApprovedClubs(approvedClubs);
  }

  List<Map<String, dynamic>> get allClubs {
    if (AdminState.isAdmin) {
      return [...approvedClubs, ...proposedClubs];
    } else {
      return approvedClubs.where((club) => club['status'] == 'approved').toList();
    }
  }

  List<Map<String, dynamic>> get filteredClubs {
    return allClubs.where((club) {
      final matchesCategory = (selectedCategory == "All") ||
          (club['category']?.toLowerCase() == selectedCategory.toLowerCase());
      final matchesSearch = club['name'].toLowerCase().contains(searchQuery.toLowerCase());
      return matchesCategory && matchesSearch;
    }).toList();
  }

  Future<void> approveProposal(Map<String, dynamic> club) async {
    await FirebaseFirestore.instance.collection('clubs').doc(club['id']).update({'status': 'approved'});
    await _fetchClubsFromFirestore(); // Refresh list after approval
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Club approved!')));
  }

  Future<void> _toggleJoinClub(String clubId, String clubName) async {
    final club = allClubs.firstWhere((club) => club['id'] == clubId);
    int membersChange = 0;

    setState(() {
      if (joinedClubs.contains(clubId)) {
        joinedClubs.remove(clubId);
        membersChange = -1;
      } else {
        joinedClubs.add(clubId);
        membersChange = 1;
      }
    });

    final newMembersCount = club['members'] + membersChange;

    await FirebaseFirestore.instance.collection('clubs').doc(clubId).update({'members': newMembersCount});
    await _fetchClubsFromFirestore(); // Refresh members count
  }

  Future<void> _removeClub(String clubId) async {
    await FirebaseFirestore.instance.collection('clubs').doc(clubId).delete();
    await _fetchClubsFromFirestore();
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Club deleted')));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Explore Clubs")),
      body: isLoading
          ? Center(child: CircularProgressIndicator())
          : Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          children: [
            TextField(
              decoration: InputDecoration(
                hintText: 'Search clubs...',
                prefixIcon: Icon(Icons.search),
                border: OutlineInputBorder(),
              ),
              onChanged: (value) {
                setState(() {
                  searchQuery = value;
                });
              },
            ),
            SizedBox(height: 12),
            Row(
              children: [
                Expanded(child: Text("Category Filter:")),
                DropdownButton<String>(
                  value: selectedCategory,
                  onChanged: (value) {
                    setState(() {
                      selectedCategory = value!;
                    });
                  },
                  items: ["All", "Arts", "Sports", "Academic", "Music","Coding" , "Public Speaking" , "Others"]
                      .map((category) => DropdownMenuItem<String>(
                    value: category,
                    child: Text(category),
                  ))
                      .toList(),
                ),
              ],
            ),
            SizedBox(height: 16),
            Expanded(
              child: filteredClubs.isEmpty
                  ? Center(child: Text('No clubs found.'))
                  : ListView.builder(
                itemCount: filteredClubs.length,
                itemBuilder: (context, index) {
                  final club = filteredClubs[index];
                  final isProposal = club['status'] == 'pending';
                  final isJoined = joinedClubs.contains(club['id']);

                  return GestureDetector(
                    onTap: () => _showClubDetails(club),
                    child: Card(
                      elevation: 2,
                      margin: EdgeInsets.only(bottom: 12),
                      child: ListTile(
                        leading: club['image'] != null && club['image'].toString().isNotEmpty
                            ? Image.network(
                          club['image'],
                          width: 50,
                          height: 50,
                          fit: BoxFit.cover,
                          errorBuilder: (context, error, stackTrace) {
                            return Icon(Icons.broken_image, size: 40);
                          },
                        )
                            : Icon(Icons.group, size: 40),
                        title: Text(club['name']),
                        subtitle: Text(club['description']),
                        trailing: AdminState.isAdmin
                            ? Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            if (isProposal)
                              IconButton(
                                icon: Icon(Icons.check_circle, color: Colors.green),
                                onPressed: () => approveProposal(club),
                              ),
                            IconButton(
                              icon: Icon(Icons.delete, color: Colors.red),
                              onPressed: () => _removeClub(club['id']),
                            ),
                          ],
                        )
                            : ElevatedButton(
                          onPressed: () => _toggleJoinClub(club['id'], club['name']),
                          child: Text(isJoined ? "Unjoin" : "Join"),
                        ),
                      ),

                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showClubDetails(Map<String, dynamic> club) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: Text(club['name']),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(club['description'] ?? 'No description'),
            SizedBox(height: 8),
            Text('Category: ${club['category'] ?? 'N/A'}'),
            Text('Creator: ${club['creator'] ?? 'N/A'}'),
            Text('Members: ${club['members'] ?? 0}'),
          ],
        ),
        actions: [TextButton(onPressed: () => Navigator.pop(context), child: Text("Close"))],
      ),
    );
  }
}

// lib/widgets/club_image.dart
import 'package:flutter/material.dart';

class ClubImage extends StatelessWidget {
  final String? imageUrl;
  final double height;
  final double width;
  final double borderRadius;

  const ClubImage({
    Key? key,
    required this.imageUrl,
    this.height = 80,
    this.width = 80,
    this.borderRadius = 8,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final placeholder = 'https://via.placeholder.com/150?text=No+Image';

    return ClipRRect(
      borderRadius: BorderRadius.circular(borderRadius),
      child: Image.network(
        (imageUrl != null && imageUrl!.isNotEmpty) ? imageUrl! : placeholder,
        height: height,
        width: width,
        fit: BoxFit.cover,
        errorBuilder: (context, error, stackTrace) {
          return Container(
            height: height,
            width: width,
            color: Colors.grey.shade300,
            child: Icon(Icons.broken_image, size: 40, color: Colors.grey),
          );
        },
        loadingBuilder: (context, child, loadingProgress) {
          if (loadingProgress == null) return child;
          return Container(
            height: height,
            width: width,
            color: Colors.grey.shade200,
            child: Center(child: CircularProgressIndicator(strokeWidth: 2)),
          );
        },
      ),
    );
  }
}

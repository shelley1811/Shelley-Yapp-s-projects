import 'package:flutter/material.dart';
import 'admin_state.dart';

PopupMenuButton<String> buildAdminPopupMenu(BuildContext context, VoidCallback? onRefresh) {
  return PopupMenuButton<String>(
    onSelected: (value) {
      if (value == 'login') {
        _showLoginDialog(context);
      } else if (value == 'refresh') {
        if (onRefresh != null) onRefresh();
      }
    },
    itemBuilder: (context) => [
      PopupMenuItem(value: 'login', child: Text('Login as Admin')),
      PopupMenuItem(value: 'refresh', child: Text('Refresh')),
    ],
  );
}

void _showLoginDialog(BuildContext context) {
  final userController = TextEditingController();
  final passController = TextEditingController();
  bool isLoading = false;

  showDialog(
    context: context,
    builder: (_) => AlertDialog(
      title: Text("Admin Login"),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          TextField(controller: userController, decoration: InputDecoration(labelText: 'Username')),
          TextField(controller: passController, decoration: InputDecoration(labelText: 'Password'), obscureText: true),
          if (isLoading) CircularProgressIndicator(),
        ],
      ),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context), child: Text("Cancel")),
        ElevatedButton(
          onPressed: () async {
            if (userController.text.isEmpty || passController.text.isEmpty) {
              ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Please enter both username and password')));
              return;
            }

            setState(() {
              isLoading = true;
            });

            await Future.delayed(Duration(seconds: 2));

            if (userController.text == 'admin' && passController.text == '1234') {
              AdminState.isAdmin = true;
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Logged in as Admin')));
            } else {
              ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Invalid credentials')));
            }

            setState(() {
              isLoading = false;
            });
          },
          child: Text("Login"),
        ),
      ],
    ),
  );
}

void setState(VoidCallback fn) {
  fn();
}

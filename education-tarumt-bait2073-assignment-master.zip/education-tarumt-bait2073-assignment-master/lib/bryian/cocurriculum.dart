import 'package:flutter/material.dart';
import 'admin_state.dart';
import 'db_helper.dart'; // Make sure DBHelper is imported
import 'package:firebase_core/firebase_core.dart';
import 'exploreclub.dart';
import 'createclub.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Co-Curriculum',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: MainPage(),
    );
  }
}

class MainPage extends StatefulWidget {
  @override
  _MainPageState createState() => _MainPageState();
}

class _MainPageState extends State<MainPage> {
  // Declare the approved and proposed clubs
  List<Map<String, dynamic>> approvedClubs = [];
  List<Map<String, dynamic>> proposedClubs = [];

  @override
  void initState() {
    super.initState();
    _loadClubs(); // Load the clubs when the app starts
  }

  Future<void> _loadClubs() async {
    approvedClubs = await DBHelper.getClubs(); // Fetch approved clubs
    proposedClubs = await DBHelper.getClubs(); // Fetch proposed clubs
    setState(() {}); // Update UI after fetching clubs
  }

  void refreshPage() {
    _loadClubs();
  }

  PopupMenuButton<String> buildAdminPopupMenu(BuildContext context, VoidCallback? onRefresh) {
    return PopupMenuButton<String>(
      onSelected: (value) {
        if (value == 'login') {
          _showLoginDialog(context, onRefresh);
        } else if (value == 'logout') {
          setState(() {
            AdminState.isAdmin = false;
          });
          ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Logged out as Admin')));
          if (onRefresh != null) onRefresh();
        } else if (value == 'refresh') {
          if (onRefresh != null) onRefresh();
        }
      },
      itemBuilder: (context) => [
        if (!AdminState.isAdmin) PopupMenuItem(value: 'login', child: Text('Login as Admin')),
        if (AdminState.isAdmin) PopupMenuItem(value: 'logout', child: Text('Logout as Admin')),
        PopupMenuItem(value: 'refresh', child: Text('Refresh')),
      ],
    );
  }

  void _showLoginDialog(BuildContext context, VoidCallback? onRefresh) {
    final userController = TextEditingController();
    final passController = TextEditingController();

    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: Text("Admin Login"),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(controller: userController, decoration: InputDecoration(labelText: 'Username')),
            TextField(controller: passController, decoration: InputDecoration(labelText: 'Password'), obscureText: true),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: Text("Cancel")),
          ElevatedButton(
            onPressed: () async {
              String username = userController.text;
              String password = passController.text;

              // CHECK CREDENTIALS FROM FIRESTORE
              bool isValid = await DBHelper.validateAdminCredentials(username, password);

              if (isValid) {
                setState(() {
                  AdminState.isAdmin = true;
                });
                Navigator.pop(context);
                ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Logged in as Admin')));
                if (onRefresh != null) onRefresh();
              } else {
                ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Invalid credentials')));
              }
            },
            child: Text("Login"),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Co-Curriculum"),
        actions: [buildAdminPopupMenu(context, refreshPage)],
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ElevatedButton(
              onPressed: () async {
                await Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => ExploreClubsPage(
                      isAdmin: AdminState.isAdmin,
                      approvedClubs: approvedClubs,
                      proposedClubs: proposedClubs,
                      onUpdateApprovedClubs: (updatedList) {
                        setState(() {
                          approvedClubs = updatedList;
                        });
                      },
                    ),
                  ),
                );
                refreshPage();  // Always refresh after coming back
              },
              child: Text("Explore Clubs"),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () async {
                await Navigator.push(context, MaterialPageRoute(builder: (_) => CreateClubPage()));
                refreshPage();  // Refresh clubs after proposing new club
              },
              child: Text("Propose a Club"),
            ),
          ],
        ),
      ),
    );
  }
}

// imports
import 'package:bait2073_assignment/nicholas/models/auth_state.dart';
import 'package:bait2073_assignment/nicholas/pages/login_page.dart';
import 'package:bait2073_assignment/nicholas/pages/register_page.dart';
import 'package:bait2073_assignment/shelley/app_state.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
// modules
import 'package:bait2073_assignment/community_app.dart';
import 'package:bait2073_assignment/event_app.dart';
import 'package:bait2073_assignment/shelley/ratings_and_feedback.dart';
import 'edmund/support_app.dart';
import 'firebase_options.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );
  print("✅ Firebase initialized in main()");

  final connectedRef = FirebaseDatabase.instance.ref(".info/connected");
  connectedRef.onValue.listen((event) {
    final connected = event.snapshot.value as bool? ?? false;
    if (connected) {
      print("✅ Connected to Firebase Realtime Database.");
    } else {
      print("❌ Not connected to Firebase Realtime Database.");
    }
  });

  await AppState.loadServicesFromFirebase();
  await AppState.loadFeedbacksFromFirebase();

  runApp(
    ChangeNotifierProvider(
      create: (_) => AuthState(),
      child: const CareCircleLauncherApp(),
    ),
  );
}

class CareCircleLauncherApp extends StatelessWidget {
  const CareCircleLauncherApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'CareCircle',
      theme: ThemeData(useMaterial3: true, colorSchemeSeed: Colors.indigo),
      home: const _RootGate(),
      routes: {
        '/login':     (c) => const LoginPage(),
        '/register':  (c) => const RegisterPage(),
        '/community': (c) => const CareCircleCommunityApp(),
        '/events':    (c) => const CareCircleEventApp(),
        '/support':   (c) => const CareCircleSupportApp(),
        '/feedback':   (c) => RatingsAndFeedback(),
      },
    );
  }
}

class _RootGate extends StatelessWidget {
  const _RootGate({super.key});

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthState>();
    if (auth.loading) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }
    if (!auth.signedIn) {
      return const LoginPage();
    }
    return const _ModuleSelectorPage();
  }
}

class _ModuleSelectorPage extends StatelessWidget {
  const _ModuleSelectorPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [Colors.indigo.shade200, Colors.indigo.shade600],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              _ModuleCard(
                icon: Icons.people,
                label: 'Community',
                onTap: () => Navigator.pushNamed(context, '/community'),
              ),
              const SizedBox(height: 24),
              _ModuleCard(
                icon: Icons.event,
                label: 'Events',
                onTap: () => Navigator.pushNamed(context, '/events'),
              ),
              const SizedBox(height: 24),
              _ModuleCard(
                icon: Icons.support_agent,
                label: 'Support Services',
                onTap: () => Navigator.pushNamed(context, '/support'),
              ),
              const SizedBox(height: 24),
              _ModuleCard(
                icon: Icons.star_rate,
                label: 'Ratings & Feedback',
                onTap: () => Navigator.pushNamed(context, '/feedback'),
              ),// ← new
            ],
          ),
        ),
      ),
    );
  }
}

class _ModuleCard extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  const _ModuleCard({
    required this.icon,
    required this.label,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 8,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      margin: const EdgeInsets.symmetric(horizontal: 32),
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 24, horizontal: 16),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, size: 32, color: Theme.of(context).colorScheme.primary),
              const SizedBox(width: 12),
              Text(
                label,
                style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                  color: Theme.of(context).colorScheme.primary,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

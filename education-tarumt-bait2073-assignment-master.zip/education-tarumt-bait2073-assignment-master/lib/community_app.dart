import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:bait2073_assignment/nicholas/models/auth_state.dart';
import 'package:bait2073_assignment/nicholas/pages/home_page.dart';
import 'package:bait2073_assignment/nicholas/pages/settings_page.dart';

class CareCircleCommunityApp extends StatelessWidget {
  const CareCircleCommunityApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'CareCircle • Community',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: Colors.teal,
        brightness: Brightness.light,
        inputDecorationTheme: const InputDecorationTheme(
          border: OutlineInputBorder(),
        ),
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
            padding: const EdgeInsets.symmetric(vertical: 16),
          ),
        ),
        cardTheme: CardTheme(
          elevation: 4,
          shape:
          RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          margin: const EdgeInsets.symmetric(vertical: 8, horizontal: 16),
        ),
        navigationBarTheme: NavigationBarThemeData(
          indicatorColor: Colors.teal.shade100,
          labelTextStyle: MaterialStateProperty.all(
              const TextStyle(fontWeight: FontWeight.bold)),
        ),
      ),
      home: const HomePage(),
      routes: {
        '/settings': (c) => const SettingsPage(),
      },
    );
  }
}

import 'package:flutter/material.dart';
import 'admin_login_page.dart';
import 'feedback_form_page.dart';
import 'view_feedback_page.dart';
import 'my_feedback_page.dart';
import 'app_state.dart';

class RatingHomePage extends StatefulWidget {
  @override
  _RatingHomePageState createState() => _RatingHomePageState();
}

class _RatingHomePageState extends State<RatingHomePage> {
  List<Map<String, dynamic>> get services => AppState.services;
  List<Map<String, dynamic>> get allFeedbacks => AppState.allFeedbacks;

  @override
  void initState() {
    super.initState();
    Future.delayed(Duration.zero, () => setState(() {}));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Ratings & Feedback"),
        actions: [
          PopupMenuButton<String>(
            onSelected: (value) {
              if (value == 'admin') {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => AdminLoginPage()),
                ).then((_) => setState(() {}));
              } else if (value == 'manage') {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => MyFeedbackPage()),
                ).then((_) => setState(() {}));
              }
            },
            itemBuilder: (context) => [
              PopupMenuItem(value: 'manage', child: Text("Manage Feedback")),
              PopupMenuItem(value: 'admin', child: Text("Admin Login")),
            ],
          ),
        ],
      ),
      body: services.isEmpty
          ? Center(child: Text("No services available."))
          : ListView.builder(
        itemCount: services.length,
        itemBuilder: (context, index) {
          final service = services[index];
          return _buildServiceCard(context, service);
        },
      ),
    );
  }

  Widget _buildServiceCard(BuildContext context, Map<String, dynamic> service) {
    final serviceId = service['id'];
    final feedbacks = allFeedbacks
        .where((f) => f['serviceId'] == serviceId)
        .toList();

    double averageRating = 0;
    if (feedbacks.isNotEmpty) {
      final ratings = feedbacks
          .map((f) => (f['rating'] as num?)?.toDouble() ?? 0.0)
          .toList();
      averageRating = ratings.reduce((a, b) => a + b) / ratings.length;
    }

    return Card(
      margin: EdgeInsets.symmetric(vertical: 8, horizontal: 16),
      child: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(service['name'],
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
            SizedBox(height: 4),
            Text(
              "${averageRating.toStringAsFixed(1)} ★  •  ${feedbacks.length} reviews",
              style: TextStyle(color: Colors.grey[600]),
            ),
            SizedBox(height: 8),
            Row(
              children: [
                ElevatedButton(
                  onPressed: () async {
                    final result = await Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => FeedbackFormPage(
                          serviceName: service['name'],
                          serviceId: service['id'],
                        ),
                      ),
                    );

                    if (result != null) {
                      final existingIndex = AppState.allFeedbacks.indexWhere((f) => f['id'] == result['id']);
                      setState(() {
                        if (existingIndex != -1) {
                          AppState.allFeedbacks[existingIndex] = result;
                        } else {
                          AppState.allFeedbacks.add(result);
                        }
                      });

                      await AppState.saveFeedbacks();

                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(content: Text("Feedback submitted successfully!")),
                      );
                    }
                  },
                  child: Text("Rate Now"),
                ),
                SizedBox(width: 10),
                TextButton(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => ViewFeedbackPage(
                          serviceId: service['id'],
                          allFeedbacks: AppState.allFeedbacks,
                        ),
                      ),
                    );
                  },
                  child: Text("View Feedback"),
                ),
              ],
            )
          ],
        ),
      ),
    );
  }
}

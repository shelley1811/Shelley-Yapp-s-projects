import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'app_state.dart';
import 'feedback_card.dart';

class ViewFeedbackPage extends StatefulWidget {
  final String serviceId;
  final List<Map<String, dynamic>> allFeedbacks;

  ViewFeedbackPage({required this.serviceId, required this.allFeedbacks});

  @override
  _ViewFeedbackPageState createState() => _ViewFeedbackPageState();
}

class _ViewFeedbackPageState extends State<ViewFeedbackPage> {
  String _selectedSort = "Most Recent";
  Set<String> likedFeedbackIds = {};
  bool _isLoading = true;

  List<Map<String, dynamic>> getFilteredFeedbacks() {
    List<Map<String, dynamic>> filtered = widget.allFeedbacks
        .where((f) => f['serviceId'] == widget.serviceId)
        .toList();

    if (_selectedSort == "Highest Rated") {
      filtered.sort((a, b) => b['rating'].compareTo(a['rating']));
    } else if (_selectedSort == "Lowest Rated") {
      filtered.sort((a, b) => a['rating'].compareTo(b['rating']));
    } else if (_selectedSort == "Most Helpful") {
      filtered.sort((a, b) =>
          (b['helpfulCount'] ?? 0).compareTo(a['helpfulCount'] ?? 0));
    } else {
      filtered.sort((a, b) => b['date'].compareTo(a['date']));
    }

    return filtered;
  }

  String _getServiceName() {
    final match = AppState.services.firstWhere(
          (s) => s['id'] == widget.serviceId,
      orElse: () => {'name': 'Unknown Service'},
    );
    return match['name'];
  }

  @override
  void initState() {
    super.initState();
    loadLikedFeedbacks();
  }

  Future<void> loadLikedFeedbacks() async {
    final prefs = await SharedPreferences.getInstance();
    final ids = prefs.getStringList('likedFeedbackIds') ?? [];
    setState(() {
      likedFeedbackIds = ids.toSet();
      _isLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    if (_isLoading) {
      return Scaffold(
        appBar: AppBar(title: Text("Feedback")),
        body: Center(child: CircularProgressIndicator()),
      );
    }

    List<Map<String, dynamic>> feedbackList = getFilteredFeedbacks();

    return Scaffold(
      appBar: AppBar(title: Text("Feedback")),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.only(bottom: 8.0),
              child: Text(
                _getServiceName(),
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              ),
            ),

            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                Text("Sort by: "),
                SizedBox(width: 8),
                DropdownButton<String>(
                  value: _selectedSort,
                  items: [
                    DropdownMenuItem(value: "Most Recent", child: Text("Most Recent")),
                    DropdownMenuItem(value: "Most Helpful", child: Text("Most Helpful")),
                    DropdownMenuItem(value: "Highest Rated", child: Text("Highest Rated")),
                    DropdownMenuItem(value: "Lowest Rated", child: Text("Lowest Rated")),
                  ],
                  onChanged: (value) {
                    setState(() {
                      _selectedSort = value!;
                    });
                  },
                ),
              ],
            ),
            SizedBox(height: 8),

            Expanded(
              child: feedbackList.isEmpty
                  ? Center(child: Text("No feedback yet."))
                  : ListView.builder(
                itemCount: feedbackList.length,
                itemBuilder: (context, index) {
                  final feedback = feedbackList[index];
                  final liked = likedFeedbackIds.contains(feedback['id']);

                  return FeedbackCard(
                    feedback: feedback,
                    liked: liked,
                    likedFeedbackIds: likedFeedbackIds,
                    onUpdateLikes: (updatedSet) async {
                      setState(() {
                        likedFeedbackIds = updatedSet;
                      });
                      final prefs = await SharedPreferences.getInstance();
                      await prefs.setStringList(
                          'likedFeedbackIds', likedFeedbackIds.toList());
                    },
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

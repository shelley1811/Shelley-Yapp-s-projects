import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:io';

import 'app_state.dart';

class FeedbackCard extends StatefulWidget {
  final Map<String, dynamic> feedback;
  final bool liked;
  final Set<String> likedFeedbackIds;
  final Function(Set<String>) onUpdateLikes;

  FeedbackCard({
    required this.feedback,
    required this.liked,
    required this.likedFeedbackIds,
    required this.onUpdateLikes,
  });

  @override
  _FeedbackCardState createState() => _FeedbackCardState();
}

class _FeedbackCardState extends State<FeedbackCard> {
  late bool liked;

  @override
  void initState() {
    super.initState();
    liked = widget.liked;
  }

  void _toggleLike() async {
    setState(() {
      liked = !liked;

      if (liked) {
        widget.feedback['helpfulCount'] = (widget.feedback['helpfulCount'] ?? 0) + 1;
        widget.likedFeedbackIds.add(widget.feedback['id']);
      } else {
        int currentCount = widget.feedback['helpfulCount'] ?? 1;
        widget.feedback['helpfulCount'] = currentCount > 0 ? currentCount - 1 : 0;
        widget.likedFeedbackIds.remove(widget.feedback['id']);
      }
    });

    // Save updated feedbacks and liked states
    await AppState.saveFeedbacks();
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList('likedFeedbackIds', widget.likedFeedbackIds.toList());

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(liked ? "Marked as helpful!" : "Removed helpful mark."),
        duration: Duration(seconds: 1),
      ),
    );

    // Notify parent widget to update state
    widget.onUpdateLikes(Set<String>.from(widget.likedFeedbackIds));
  }

  @override
  Widget build(BuildContext context) {
    final dateRaw = widget.feedback['date'];
    final formattedDate = dateRaw is DateTime
        ? dateRaw.toLocal().toString().split(' ')[0]
        : DateTime.tryParse(dateRaw.toString())?.toLocal().toString().split(' ')[0] ?? 'Unknown Date';
    return Card(
      margin: EdgeInsets.symmetric(vertical: 8),
      child: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // 🧑 Username + Date
            Text(
              "${widget.feedback['isAnonymous'] ? 'Anonymous' : widget.feedback['name'] ?? 'User'} - $formattedDate",
              style: TextStyle(fontSize: 14, color: Colors.grey),
            ),
            SizedBox(height: 4),

            // ⭐ Rating
            RatingBarIndicator(
              rating: (widget.feedback['rating'] as num?)?.toDouble() ?? 0.0,
              itemBuilder: (context, _) => Icon(Icons.star, color: Colors.amber),
              itemCount: 5,
              itemSize: 20.0,
            ),
            SizedBox(height: 4),

            // 📝 Comment
            Text(widget.feedback['comment']),

            // 🖼️ Image (optional)
            if (widget.feedback['imageUrl'] != null)
              Padding(
                padding: const EdgeInsets.only(top: 8.0),
                child: Image.file(
                  File(widget.feedback['imageUrl']),
                  height: 100,
                  fit: BoxFit.cover,
                ),
              ),

            SizedBox(height: 8),

            // 👍 Helpful Button
            Row(
              children: [
                IconButton(
                  icon: Icon(
                    Icons.thumb_up,
                    color: liked ? Colors.blue : Colors.grey,
                  ),
                  onPressed: _toggleLike,
                ),
                Text(
                  "${widget.feedback['helpfulCount'] ?? 0} found this helpful",
                  style: TextStyle(color: Colors.grey[700]),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

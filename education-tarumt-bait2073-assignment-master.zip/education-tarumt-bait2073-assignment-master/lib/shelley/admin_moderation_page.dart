import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'dart:io';
import 'app_state.dart';
import 'rating_home_page.dart';

class AdminModerationPage extends StatefulWidget {
  @override
  _AdminModerationPageState createState() => _AdminModerationPageState();
}

class _AdminModerationPageState extends State<AdminModerationPage> {
  List<Map<String, dynamic>> get services => AppState.services;
  List<Map<String, dynamic>> get allFeedbacks => AppState.allFeedbacks;

  @override
  void initState() {
    super.initState();
    if (!AppState.isAdmin) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        Navigator.pop(context);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("Access denied. Not an admin.")),
        );
      });
    }
  }

  void _confirmDeleteService(int index) {
    final service = AppState.services[index];
    final hasFeedback = AppState.allFeedbacks.any((f) => f['serviceId'] == service['id']);

    if (hasFeedback) {
      showDialog(
        context: context,
        builder: (context) => AlertDialog(
          title: Text("Cannot Delete"),
          content: Text("This service has existing feedback. Please delete related feedbacks first."),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text("OK"),
            ),
          ],
        ),
      );
      return;
    }

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text("Delete Service"),
        content: Text("Are you sure you want to delete this service?"),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text("Cancel"),
          ),
          ElevatedButton(
            onPressed: () async {
              Navigator.pop(context);

              setState(() {
                AppState.services.removeAt(index);
              });

              await AppState.saveServices();

              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text("Service deleted.")),
              );
            },
            style: ElevatedButton.styleFrom(),
            child: Text("Delete"),
          ),
        ],
      ),
    );
  }

  void _showAddServiceDialog() {
    final TextEditingController _nameController = TextEditingController();

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text("Add New Service"),
        content: TextField(
          controller: _nameController,
          decoration: InputDecoration(labelText: "Service Name"),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text("Cancel"),
          ),
          ElevatedButton(
            onPressed: () async {
              final name = _nameController.text.trim();
              final exists = AppState.services.any((s) => s['name'].toLowerCase() == name.toLowerCase());

              if (name.isEmpty) return;

              if (exists) {
                Navigator.pop(context);
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text("Service name already exists.")),
                );
                return;
              }

              setState(() {
                AppState.services.add({
                  "id": "s${DateTime.now().millisecondsSinceEpoch}",
                  "name": name,
                });
              });

              await AppState.saveServices();

              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text("Service added.")),
              );
            },
            child: Text("Add"),
          )
        ],
      ),
    );
  }

  void _showEditServiceDialog(int index) {
    final TextEditingController _editController =
    TextEditingController(text: services[index]['name']);

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text("Edit Service Name"),
        content: TextField(
          controller: _editController,
          decoration: InputDecoration(labelText: "New Service Name"),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: Text("Cancel")),
          ElevatedButton(
            onPressed: () async {
              final newName = _editController.text.trim();
              final exists = AppState.services.any((s) =>
              s['name'].toLowerCase() == newName.toLowerCase() && s != services[index]);

              if (newName.isEmpty) return;

              if (exists) {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text("Service name already exists.")),
                );
                return;
              }

              setState(() {
                AppState.services[index]['name'] = newName;
              });
              await AppState.saveServices();
              Navigator.pop(context);
            },
            child: Text("Save"),
          ),
        ],
      ),
    );
  }

  void _deleteFeedback(String id) async {
    setState(() {
      allFeedbacks.removeWhere((f) => f['id'] == id);
    });
    await AppState.saveServices();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false,
        title: Text("Admin Control Panel"),
        actions: [
          IconButton(
            icon: Icon(Icons.logout),
            tooltip: "Logout",
            onPressed: () {
              AppState.isAdmin = false;
              Navigator.pushAndRemoveUntil(
                context,
                MaterialPageRoute(builder: (_) => RatingHomePage()),
                    (route) => false,
              );
            },
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            ElevatedButton.icon(
              icon: Icon(Icons.add),
              label: Text("Add Service"),
              onPressed: _showAddServiceDialog,
            ),
            SizedBox(height: 24),
            Text("Services:",
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
            SizedBox(height: 8),
            Expanded(
              child: ListView.builder(
                itemCount: services.length,
                itemBuilder: (context, index) {
                  final service = services[index];
                  return Card(
                    child: ListTile(
                      title: Text(service['name']),
                      trailing: PopupMenuButton<String>(
                        onSelected: (value) {
                          if (value == 'edit') {
                            _showEditServiceDialog(index);
                          } else if (value == 'delete') {
                            _confirmDeleteService(index);
                          }
                        },

                        itemBuilder: (context) => [
                          PopupMenuItem(value: 'edit', child: Text("Edit")),
                          PopupMenuItem(value: 'delete', child: Text("Delete")),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
            SizedBox(height: 16),
            Divider(height: 32),
            Text("Feedbacks:",
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
            SizedBox(height: 8),
            Expanded(
              child: allFeedbacks.isEmpty
                  ? Center(child: Text("No feedback submitted yet."))
                  : ListView.builder(
                itemCount: allFeedbacks.length,
                itemBuilder: (context, index) {
                  final feedback = allFeedbacks[index];

                  final String serviceName = AppState.services.firstWhere(
                        (s) => s['id'] == feedback['serviceId'],
                    orElse: () => {'name': 'Unknown Service'},
                  )['name'];

                  final date = feedback['date'];
                  final formattedDate = date is DateTime
                      ? date.toLocal().toString().split(' ')[0]
                      : DateTime.tryParse(date.toString())?.toLocal().toString().split(' ')[0] ?? 'Unknown Date';
                  return Card(
                    margin: EdgeInsets.symmetric(vertical: 8),
                    child: ListTile(
                      title: Text(
                        serviceName,
                        style: TextStyle(fontWeight: FontWeight.bold),
                      ),

                      subtitle: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          RatingBarIndicator(
                            rating: (feedback['rating'] as num?)?.toDouble() ?? 0.0,
                            itemBuilder: (context, _) =>
                                Icon(Icons.star, color: Colors.amber),
                            itemCount: 5,
                            itemSize: 20.0,
                          ),
                          SizedBox(height: 4),
                          Text(feedback['comment']),
                          if (feedback['imageUrl'] != null)
                            Padding(
                              padding: const EdgeInsets.only(top: 8.0),
                              child: Image.file(
                                File(feedback['imageUrl']),
                                height: 100,
                                fit: BoxFit.cover,
                              ),
                            ),
                          SizedBox(height: 4),
                          Text(
                            "${feedback['isAnonymous'] ? 'Anonymous' : (feedback['name'] ?? 'User')} - $formattedDate",
                            style: TextStyle(color: Colors.grey, fontSize: 12),
                          ),
                        ],
                      ),
                      trailing: IconButton(
                        icon: Icon(Icons.delete, color: Colors.red),
                        onPressed: () {
                          showDialog(
                            context: context,
                            builder: (context) => AlertDialog(
                              title: Text("Confirm Deletion"),
                              content: Text("Are you sure you want to delete this feedback?"),
                              actions: [
                                TextButton(
                                  onPressed: () => Navigator.pop(context), // Cancel
                                  child: Text("Cancel"),
                                ),
                                ElevatedButton(
                                  onPressed: () async {
                                    Navigator.pop(context); // Close dialog
                                    setState(() {
                                      AppState.allFeedbacks.removeWhere((f) => f['id'] == feedback['id']);
                                    });
                                    await AppState.saveFeedbacks();
                                    ScaffoldMessenger.of(context).showSnackBar(
                                      SnackBar(content: Text("Feedback deleted.")),
                                    );
                                  },
                                  style: ElevatedButton.styleFrom(backgroundColor: Colors.white),
                                  child: Text("Delete"),
                                ),
                              ],
                            ),
                          );
                        },
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
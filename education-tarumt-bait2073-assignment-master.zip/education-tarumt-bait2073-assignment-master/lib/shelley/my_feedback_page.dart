import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:provider/provider.dart';
import 'dart:io';
import '../nicholas/models/auth_state.dart';
import 'app_state.dart';
import 'feedback_form_page.dart';

class MyFeedbackPage extends StatefulWidget {
  @override
  _MyFeedbackPageState createState() => _MyFeedbackPageState();
}

class _MyFeedbackPageState extends State<MyFeedbackPage> {
  bool _showAnonymous = false;

  void _deleteFeedback(String id) async {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text("Confirm Deletion"),
        content: Text("Are you sure you want to delete this feedback?"),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text("Cancel"),
          ),
          ElevatedButton(
            onPressed: () async {
              setState(() {
                AppState.allFeedbacks.removeWhere((f) => f['id'] == id);
              });
              await AppState.saveFeedbacks();
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text("Feedback deleted.")),
              );
            },
            child: Text("Delete"),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final uid = Provider.of<AuthState>(context, listen: false).user?.$id;

    List<Map<String, dynamic>> feedbackList = AppState.allFeedbacks.where((f) {
      final isMine = f['userId'] == uid;
      final showAnon = _showAnonymous || f['isAnonymous'] == false;
      return isMine && showAnon;
    }).toList();

    return Scaffold(
      appBar: AppBar(title: Text("My Feedback")),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            SwitchListTile(
              title: Text("Show Anonymous Feedback"),
              value: _showAnonymous,
              onChanged: (value) {
                setState(() {
                  _showAnonymous = value;
                });
              },
            ),
            Expanded(
              child: feedbackList.isEmpty
                  ? Center(child: Text("No feedback submitted yet."))
                  : ListView.builder(
                itemCount: feedbackList.length,
                itemBuilder: (context, index) {
                  final feedback = feedbackList[index];
                  final serviceName = AppState.services.firstWhere(
                        (s) => s['id'] == feedback['serviceId'],
                    orElse: () => {'name': feedback['service'] ?? 'Unknown'},
                  )['name'];

                  final date = feedback['date'];
                  final formattedDate = date is DateTime
                      ? date.toLocal().toString().split(' ')[0]
                      : DateTime.tryParse(date.toString())?.toLocal().toString().split(' ')[0] ?? 'Unknown Date';
                  return Card(
                    margin: EdgeInsets.symmetric(vertical: 8),
                    child: ListTile(
                      title: Text(
                        serviceName,
                        style: TextStyle(fontWeight: FontWeight.bold),
                      ),
                      subtitle: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          RatingBarIndicator(
                            rating: (feedback['rating'] as num?)?.toDouble() ?? 0.0,
                            itemBuilder: (context, _) =>
                                Icon(Icons.star, color: Colors.amber),
                            itemCount: 5,
                            itemSize: 20.0,
                          ),
                          SizedBox(height: 4),
                          Text(feedback['comment']),
                          if (feedback['imageUrl'] != null)
                            Padding(
                              padding: const EdgeInsets.only(top: 8.0),
                              child: Image.file(
                                File(feedback['imageUrl']),
                                height: 100,
                                fit: BoxFit.cover,
                              ),
                            ),
                          SizedBox(height: 4),
                          Text(
                            "${feedback['isAnonymous'] ? 'Anonymous' : (feedback['name'] ?? 'User')} - $formattedDate",
                            style: TextStyle(color: Colors.grey, fontSize: 12),
                          ),
                        ],
                      ),
                      trailing: PopupMenuButton<String>(
                        onSelected: (value) async {
                          if (value == 'edit') {
                            final updated = await Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (_) => FeedbackFormPage(
                                  serviceName: serviceName,
                                  serviceId: feedback['serviceId'],
                                  existingFeedback: feedback,
                                ),
                              ),
                            );

                            if (updated != null) {
                              setState(() {
                                int i = AppState.allFeedbacks.indexWhere(
                                        (f) => f['id'] == updated['id']);
                                if (i != -1) {
                                  AppState.allFeedbacks[i] = updated;
                                }
                              });
                              await AppState.saveFeedbacks();
                              ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(
                                    content: Text(
                                        "Feedback updated successfully!")),
                              );
                            }
                          } else if (value == 'delete') {
                            _deleteFeedback(feedback['id']);
                          }
                        },
                        itemBuilder: (context) => [
                          PopupMenuItem(
                              value: 'edit', child: Text('Edit')),
                          PopupMenuItem(
                              value: 'delete', child: Text('Delete')),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

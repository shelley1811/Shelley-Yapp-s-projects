import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';
import 'package:uuid/uuid.dart';
import 'dart:io';

import '../nicholas/models/auth_state.dart';
import 'app_state.dart';

class FeedbackFormPage extends StatefulWidget {
  final String serviceName;
  final String serviceId;
  final Map<String, dynamic>? existingFeedback;

  FeedbackFormPage({
    required this.serviceName,
    required this.serviceId,
    this.existingFeedback,
  });

  @override
  _FeedbackFormPageState createState() => _FeedbackFormPageState();
}

class _FeedbackFormPageState extends State<FeedbackFormPage> {
  double _rating = 0;
  final TextEditingController _commentController = TextEditingController();
  bool _isAnonymous = false;
  File? _selectedImage;
  final ImagePicker _picker = ImagePicker();

  @override
  void initState() {
    super.initState();
    if (widget.existingFeedback != null) {
      _rating = widget.existingFeedback!['rating'];
      _commentController.text = widget.existingFeedback!['comment'];
      _isAnonymous = widget.existingFeedback!['isAnonymous'];
      if (widget.existingFeedback!['imageUrl'] != null) {
        _selectedImage = File(widget.existingFeedback!['imageUrl']);
      }
    }
  }

  Future<void> _pickImage() async {
    final pickedFile = await _picker.pickImage(source: ImageSource.gallery);
    if (pickedFile != null) {
      setState(() {
        _selectedImage = File(pickedFile.path);
      });
    }
  }

  void _submitFeedback() async {
    final comment = _commentController.text.trim();
    if (_rating == 0 || comment.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Please provide a rating and comment.")),
      );
      return;
    }

    final feedback = {
      'id': widget.existingFeedback?['id'] ?? Uuid().v4(),
      'service': widget.serviceName,
      'serviceId': widget.serviceId,
      'rating': _rating,
      'comment': comment,
      'isAnonymous': _isAnonymous,
      'date': DateTime.now(),
      'imageUrl': _selectedImage?.path,
      "userId": Provider.of<AuthState>(context, listen: false).user?.$id,
      'name': Provider.of<AuthState>(context, listen: false).user?.name,
      'helpfulCount': widget.existingFeedback?['helpfulCount'] ?? 0,
    };

    Navigator.pop(context, feedback);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Rate: ${widget.serviceName}")),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            Text("Rate the service:", style: TextStyle(fontSize: 16)),
            RatingBar.builder(
              initialRating: _rating,
              minRating: 1.0,
              allowHalfRating: true,
              itemCount: 5,
              itemSize: 36.0,
              itemBuilder: (context, _) => Icon(Icons.star, color: Colors.amber),
              onRatingUpdate: (rating) {
                setState(() {
                  _rating = rating;
                });
              },
            ),
            SizedBox(height: 20),
            TextField(
              controller: _commentController,
              maxLines: 5,
              decoration: InputDecoration(
                labelText: "Your Feedback",
                border: OutlineInputBorder(),
              ),
            ),
            CheckboxListTile(
              title: Text("Submit anonymously"),
              value: _isAnonymous,
              onChanged: (value) {
                setState(() {
                  _isAnonymous = value ?? false;
                });
              },
            ),
            if (_selectedImage != null)
              Padding(
                padding: const EdgeInsets.only(bottom: 8.0),
                child: Image.file(_selectedImage!, height: 100),
              ),
            OutlinedButton.icon(
              icon: Icon(Icons.image),
              label: Text("Upload Image"),
              onPressed: _pickImage,
            ),
            SizedBox(height: 16),
            ElevatedButton(
              onPressed: _submitFeedback,
              child: Text("Submit"),
              style: ElevatedButton.styleFrom(
                minimumSize: Size(double.infinity, 48),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

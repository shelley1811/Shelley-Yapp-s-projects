import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:firebase_database/firebase_database.dart';


class AppState {
  static List<Map<String, dynamic>> allFeedbacks = [];
  static List<Map<String, dynamic>> services = [];
  static bool isAdmin = false;
  static String? currentUserId;

  // Firebase Realtime Database reference
  static final DatabaseReference db = FirebaseDatabase.instance.ref();

  /// Save feedbacks to local SharedPreferences
  static Future<void> saveFeedbacks() async {
    final prefs = await SharedPreferences.getInstance();

    final List<Map<String, dynamic>> encodedList = allFeedbacks.map((f) {
      final copy = Map<String, dynamic>.from(f);
      if (copy['date'] is DateTime) {
        copy['date'] = (copy['date'] as DateTime).toIso8601String();
      }
      return copy;
    }).toList();

    final data = jsonEncode(encodedList);
    await prefs.setString('feedbacks', data);

    try {
      await FirebaseDatabase.instance.ref('feedbacks').set(encodedList);
      print("✅ Uploaded feedbacks to Firebase");
    } catch (e) {
      print("❌ Failed to upload feedbacks to Firebase: $e");
    }
  }

  /// Load feedbacks from local SharedPreferences
  static Future<void> loadFeedbacks() async {
    final prefs = await SharedPreferences.getInstance();
    final data = prefs.getString('feedbacks');

    if (data != null) {
      try {
        final List<dynamic> decoded = jsonDecode(data);
        allFeedbacks = decoded.map<Map<String, dynamic>>((f) {
          final copy = Map<String, dynamic>.from(f);
          copy['date'] = DateTime.parse(copy['date']);
          return copy;
        }).toList();
      } catch (e) {
        allFeedbacks = [];
      }
    }
  }

  /// Load feedbacks directly from Firebase
  static Future<void> loadFeedbacksFromFirebase() async {
    try {
      final snapshot = await FirebaseDatabase.instance.ref('feedbacks').get();
      if (snapshot.exists && snapshot.value != null) {
        final List<dynamic> rawList = snapshot.value as List<dynamic>;

        allFeedbacks = rawList.map<Map<String, dynamic>>((item) {
          final map = Map<String, dynamic>.from(item as Map);
          if (map['date'] is String) {
            map['date'] = DateTime.parse(map['date']);
          }
          return map;
        }).toList();

        final prefs = await SharedPreferences.getInstance();
        await prefs.setString('feedbacks', jsonEncode(
          allFeedbacks.map((f) {
            final copy = Map<String, dynamic>.from(f);
            copy['date'] = (copy['date'] as DateTime).toIso8601String();
            return copy;
          }).toList(),
        ));

        print("✅ Feedbacks loaded from Firebase");
      }
    } catch (e) {
      print("❌ Failed to parse feedbacks from Firebase: $e");
      allFeedbacks = [];
    }
  }

  /// Save services to local SharedPreferences
  static Future<void> saveServices() async {
    final prefs = await SharedPreferences.getInstance();
    final data = jsonEncode(services);
    await prefs.setString('services', data);

    // Also upload to Firebase
    await db.child('services').set(services);
  }

  /// Load services from local SharedPreferences
  static Future<void> loadServices() async {
    final prefs = await SharedPreferences.getInstance();
    final data = prefs.getString('services');
    if (data != null) {
      try {
        services = List<Map<String, dynamic>>.from(jsonDecode(data));
      } catch (e) {
        services = [];
      }
    }
  }

  /// Load services directly from Firebase
  static Future<void> loadServicesFromFirebase() async {
    final snapshot = await db.child('services').get();

    if (snapshot.exists && snapshot.value != null) {
      try {
        final List<dynamic> data = List.from(snapshot.value as List);
        services = data.map<Map<String, dynamic>>((item) {
          return Map<String, dynamic>.from(item as Map);
        }).toList();

        final prefs = await SharedPreferences.getInstance();
        await prefs.setString('services', jsonEncode(services));

        print("✅ Services loaded from Firebase (List).");
      } catch (e) {
        print("❌ Failed to parse services from Firebase: $e");
      }
    } else {
      print("⚠️ No services found in Firebase.");
    }
  }
}
import 'package:flutter/material.dart';

/// Renamed from AssignmentApp → CareCircleSupportApp
class CareCircleSupportApp extends StatelessWidget {
  const CareCircleSupportApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Support Services & Assistance',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: const AssignmentHomeScreen(),
    );
  }
}

class AssignmentHomeScreen extends StatefulWidget {
  const AssignmentHomeScreen({super.key});

  @override
  State<AssignmentHomeScreen> createState() => _AssignmentHomeScreenState();
}

class _AssignmentHomeScreenState extends State<AssignmentHomeScreen> {
  int _selectedCategory = 0;
  final List<String> categories = ['Healthcare', 'Food', 'Mental Health'];

  void _showAssignmentForm(BuildContext context, String serviceName) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (ctx) {
        return AssignmentApplicationForm(serviceName: serviceName);
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Support Services & Assistance'),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Search Bar
              Container(
                decoration: BoxDecoration(
                  color: Colors.grey[200],
                  borderRadius: BorderRadius.circular(8),
                ),
                child: const TextField(
                  decoration: InputDecoration(
                    hintText: 'Search services...',
                    prefixIcon: Icon(Icons.search),
                    border: InputBorder.none,
                    contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                  ),
                ),
              ),
              const SizedBox(height: 20),

              // Categories
              SizedBox(
                height: 50,
                child: ListView.builder(
                  scrollDirection: Axis.horizontal,
                  itemCount: categories.length,
                  itemBuilder: (context, index) {
                    return Padding(
                      padding: const EdgeInsets.only(right: 8.0),
                      child: ChoiceChip(
                        label: Text(categories[index]),
                        selected: _selectedCategory == index,
                        onSelected: (selected) {
                          setState(() {
                            _selectedCategory = index;
                          });
                        },
                      ),
                    );
                  },
                ),
              ),

              const SizedBox(height: 20),

              // Services List
              _buildServiceCard(
                title: 'Community Health Center',
                description: 'Free medical services for low-income families',
                phone: '555-0123',
                address: '123 Main St',
                onApply: () => _showAssignmentForm(context, 'Community Health Center'),
              ),

              const SizedBox(height: 16),

              _buildServiceCard(
                title: 'Food Bank Services',
                description: 'Weekly food distribution and emergency supplies',
                phone: '555-0124',
                address: '456 Oak Ave',
                onApply: () => _showAssignmentForm(context, 'Food Bank Services'),
              ),
            ],
          ),
        ),
      ),

      bottomNavigationBar: const AssignmentBottomNavBar(),
    );
  }

  Widget _buildServiceCard({
    required String title,
    required String description,
    required String phone,
    String? address,
    String? website,
    required VoidCallback onApply,
  }) {
    return Card(
      elevation: 3,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            Text(description, style: TextStyle(fontSize: 14, color: Colors.grey[600])),
            const SizedBox(height: 12),
            Row(children: const [
              Icon(Icons.phone, size: 16), SizedBox(width: 8), Text('555-0123'),
            ]),
            if (address != null) ...[
              const SizedBox(height: 8),
              Row(children: [
                const Icon(Icons.location_on, size: 16),
                const SizedBox(width: 8),
                Text(address),
              ]),
            ],
            if (website != null) ...[
              const SizedBox(height: 8),
              Row(children: [
                const Icon(Icons.language, size: 16),
                const SizedBox(width: 8),
                Text(website),
              ]),
            ],
            const SizedBox(height: 12),
            Align(
              alignment: Alignment.centerRight,
              child: ElevatedButton(onPressed: onApply, child: const Text('Apply Now')),
            ),
          ],
        ),
      ),
    );
  }
}

class AssignmentApplicationForm extends StatefulWidget {
  final String serviceName;
  const AssignmentApplicationForm({super.key, required this.serviceName});

  @override
  State<AssignmentApplicationForm> createState() => _AssignmentApplicationFormState();
}

class _AssignmentApplicationFormState extends State<AssignmentApplicationForm> {
  final _formKey = GlobalKey<FormState>();
  final _nameController    = TextEditingController();
  final _emailController   = TextEditingController();
  final _phoneController   = TextEditingController();
  final _addressController = TextEditingController();

  @override
  void dispose() {
    _nameController.dispose();
    _emailController.dispose();
    _phoneController.dispose();
    _addressController.dispose();
    super.dispose();
  }

  void _submitAssignment() {
    if (_formKey.currentState!.validate()) {
      ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Application submitted successfully!'))
      );
      Navigator.of(context).pop();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        bottom: MediaQuery.of(context).viewInsets.bottom,
        left: 16, right: 16, top: 16,
      ),
      child: Form(
        key: _formKey,
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Text('Apply for ${widget.serviceName}',
              style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          const SizedBox(height: 20),
          TextFormField(
            controller: _nameController,
            decoration: const InputDecoration(labelText: 'Full Name', border: OutlineInputBorder()),
            validator: (v) => v!.isEmpty ? 'Please enter your name' : null,
          ),
          const SizedBox(height: 16),
          TextFormField(
            controller: _emailController,
            decoration: const InputDecoration(labelText: 'Email', border: OutlineInputBorder()),
            validator: (v) => !v!.contains('@') ? 'Enter a valid email' : null,
          ),
          const SizedBox(height: 16),
          TextFormField(
            controller: _phoneController,
            decoration: const InputDecoration(labelText: 'Phone Number', border: OutlineInputBorder()),
            validator: (v) => v!.isEmpty ? 'Please enter phone number' : null,
          ),
          const SizedBox(height: 16),
          TextFormField(
            controller: _addressController,
            decoration: const InputDecoration(labelText: 'Address', border: OutlineInputBorder()),
            validator: (v) => v!.isEmpty ? 'Please enter address' : null,
          ),
          const SizedBox(height: 24),
          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
            ElevatedButton(onPressed: _submitAssignment, child: const Text('Submit')),
          ]),
        ]),
      ),
    );
  }
}

class AssignmentBottomNavBar extends StatelessWidget {
  const AssignmentBottomNavBar({super.key});

  @override
  Widget build(BuildContext context) {
    return BottomNavigationBar(
      items: const [
        BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Services'),
        BottomNavigationBarItem(icon: Icon(Icons.people), label: 'Volunteer'),
      ],
    );
  }
}

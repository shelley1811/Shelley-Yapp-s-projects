import 'package:flutter/material.dart';
import 'daniel/pages/main_event_hub.dart';

class CareCircleEventApp extends StatelessWidget {
  const CareCircleEventApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'CareCircle • Events',
      debugShowCheckedModeBanner: false,
      home: const EventHomeScreen(),
    );
  }
}

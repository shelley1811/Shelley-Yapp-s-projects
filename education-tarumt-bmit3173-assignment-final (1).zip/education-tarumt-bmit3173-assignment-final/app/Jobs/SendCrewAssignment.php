<?php

namespace App\Jobs;

use App\Models\CrewAssignment;
use App\Services\WhatsAppService;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;

class SendCrewAssignment implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public function __construct(public int $assignmentId) {}

    public function handle(WhatsAppService $wa): void
    {
        $a = CrewAssignment::find($this->assignmentId);
        if (!$a) return;

        $msg = "Flight {$a->flight_no}\n".
               "Dep: {$a->dep_time?->format('Y-m-d H:i')}\n".
               "Role: {$a->role}";

        $res = $wa->sendText($a->crew_phone, $msg);

        $a->vendor_payload = $res['body'];
        if ($res['ok']) {
            $a->status  = CrewAssignment::STATUS_SENT;
            $a->sent_at = now();
        } else {
            $a->status  = CrewAssignment::STATUS_FAILED;
        }
        $a->save();
    }
}

<?php

namespace App\Adapters;

use App\Models\Route as RouteModel;
use Carbon\Carbon;

class RouteToFlightAdapter
{
    // Adapter pattern

    /**
     * Map a Route row to Flight attributes with updated requirements:
     * - origin: first 3 chars of route_id
     * - destination: chars after hyphen (3 chars)
     * - flight_date: static between 18-19 Sep 2025
     * - departure_time: hardcoded at 12:00 noon
     * - arrival_time: 1 PM (60 min) or 2 PM (120 min) based on duration
     * - duration_minutes: 60 or 120 minutes (standardized)
     * - base_fare_myr: double of duration (60*2=120 or 120*2=240)
     * - flight_no: first 8 chars of route_id (to fit varchar(8) column)
     */
    public static function toFlightAttributes(RouteModel $route): array
    {
        $routeId = (string) $route->route_id;
        $originalMinutes = (int) ($route->estimated_flight_time ?? 60);

        // Extract origin and destination from route_id (format: ABC-DEF123)
        $parts = explode('-', $routeId);
        $origin = substr($parts[0], 0, 3);
        $destination = substr($parts[1], 0, 3);

        // Standardize duration: if <= 90 minutes use 60, else use 120
        $standardizedMinutes = $originalMinutes <= 90 ? 60 : 120;

        // Fixed departure at 12:00 noon
        $departure = '12:00:00';

        // Arrival time: 1 PM for 60 min flights, 2 PM for 120 min flights
        $arrivalHour = $standardizedMinutes === 60 ? '13:00:00' : '14:00:00';

        // Base fare: double of duration minutes
        $baseFare = (double) ($standardizedMinutes * 2);

        // Alternate between Sep 18 and 19, 2025 based on route ID hash
        $dateOptions = ['2025-09-18', '2025-09-19'];
        $dateIndex = crc32($routeId) % 2;
        $flightDate = $dateOptions[$dateIndex];

        return [
            'flight_no'         => substr($routeId, 0, 8),   // truncate to fit varchar(8) column
            'origin'            => $origin,
            'destination'       => $destination,
            'flight_date'       => $flightDate,              // alternates between 18-19 Sep 2025
            'departure_time'    => $departure,               // always 12:00 noon
            'arrival_time'      => $arrivalHour,             // 1 PM or 2 PM
            'duration_minutes'  => $standardizedMinutes,     // 60 or 120 minutes
            'base_fare_myr'     => $baseFare,                // 120 MYR or 240 MYR
        ];
    }
}

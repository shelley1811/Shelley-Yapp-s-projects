<?php

namespace App\Observers;

use App\Models\Route as RouteModel;
use App\Models\Flight;

// Adapter pattern
use App\Adapters\RouteToFlightAdapter;

class RouteObserver
{
    /**
     * Handle the Route "created" event.
     */
    public function created(RouteModel $route): void
    {
        $this->syncFlight($route, true);
    }

    /**
     * Handle the Route "updated" event.
     */
    public function updated(RouteModel $route): void
    {
        $this->syncFlight($route, false);
    }

    // /**
    //  * Handle the Route "deleted" event.
    //  */
    // public function deleted(Route $route): void
    // {
    //     //
    // }

    // /**
    //  * Handle the Route "restored" event.
    //  */
    // public function restored(Route $route): void
    // {
    //     //
    // }

    // /**
    //  * Handle the Route "force deleted" event.
    //  */
    // public function forceDeleted(Route $route): void
    // {
    //     //
    // }

    /**
     * Upsert the Flight row that corresponds to the specified Route
     * Seats are set only on INSERT (200/200) so booking logic can decrement seats safely
     */
    protected function syncFlight(RouteModel $route, bool $isCreate): void
    {
        $attrs = RouteToFlightAdapter::toFlightAttributes($route);

        // Truncated route_id as flight_no to avoid a schema change
        $flight = Flight::firstOrNew(['flight_no' => $attrs['flight_no']]);

        // For new flights, set static seats; for updates
        if (! $flight->exists) {
            $flight->seats_total     = 200;
            $flight->seats_available = 200;
        }

        $flight->fill($attrs);
        $flight->save();
    }
}

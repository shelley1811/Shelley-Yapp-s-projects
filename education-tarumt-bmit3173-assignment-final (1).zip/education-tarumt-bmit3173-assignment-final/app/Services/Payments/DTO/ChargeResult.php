<?php
namespace App\Services\Payments\DTO;

class ChargeResult
{
    public function __construct(
        public bool $ok,
        public ?string $transactionRef = null,
        public ?string $message = null,
    ) {}
}

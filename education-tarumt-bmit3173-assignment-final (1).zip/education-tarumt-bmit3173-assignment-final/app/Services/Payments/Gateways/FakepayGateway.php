<?php

namespace App\Services\Payments\Gateways;

use App\Contracts\PaymentGateway;
use App\Services\Payments\DTO\ChargeResult;
use Illuminate\Support\Str;

class FakepayGateway implements PaymentGateway
{
    public function charge(float $amountMyr, string $token, array $meta = []): ChargeResult
    {
        if (($meta['simulate'] ?? null) === 'timeout') {
            return new ChargeResult(false, null, 'Gateway timeout');
        }
        if ($amountMyr <= 0) {
            return new ChargeResult(false, null, 'Invalid amount');
        }

        if (str_starts_with($token, 'tok_') && ($meta['simulate'] ?? 'success') !== 'fail') {
            return new ChargeResult(true, 'FP-'.Str::upper(Str::random(12)));
        }

        return new ChargeResult(false, null, 'Card declined');
    }
}

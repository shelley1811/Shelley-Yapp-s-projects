<?php

namespace App\Services\Payments;

use App\Contracts\PaymentGateway;
use App\Models\Booking;
use App\Models\Payment;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

class PaymentService
{
    public function __construct(private PaymentGateway $gateway) {}

    public function capture(Booking $booking, float $amountMyr, string $method, array $payload): Payment
    {
        if ($booking->status !== 'PENDING') {
            abort(409, 'Booking not payable (status '.$booking->status.')');
        }
        if ($booking->is_expired) {
            $booking->update(['status' => 'EXPIRED']);
            abort(409, 'Booking expired');
        }

        $balance = max(0, $booking->grand_total_myr - $booking->paid_total_myr);
        if ($amountMyr <= 0 || $amountMyr > $balance) {
            throw ValidationException::withMessages([
                'amount_myr' => ['Amount must be > 0 and <= outstanding balance (MYR '.number_format($balance,2).').']
            ]);
        }

        return DB::transaction(function () use ($booking, $amountMyr, $method, $payload) {
            $payment = Payment::create([
                'booking_id'   => $booking->id,
                'status'       => 'PENDING',
                'amount_myr'   => $amountMyr,     // MYR stored as double per your rule
                'method'       => $method,
                'provider'     => 'fakepay',
                'payload'      => ['request' => $payload],
            ]);

            $result = $this->gateway->charge(
                $amountMyr,
                $payload['token'] ?? 'tok_demo',
                ['simulate' => $payload['simulate'] ?? null, 'booking_id' => $booking->id, 'payment_id' => $payment->id]
            );

            if ($result->ok) {
                $payment->update([
                    'status'          => 'SUCCEEDED',
                    'transaction_ref' => $result->transactionRef,
                    'paid_at'         => now(),
                ]);

                $booking->increment('paid_total_myr', $amountMyr);
                $booking->refresh();
                if ($booking->paid_total_myr + 0.00001 >= $booking->grand_total_myr) {
                    $booking->update(['status' => 'CONFIRMED']);
                }
                return $payment->fresh();
            }

            $payment->update([
                'status'  => 'FAILED',
                'payload' => array_merge($payment->payload ?? [], ['error' => $result->message]),
            ]);
            abort(402, 'Payment failed: '.($result->message ?? 'unknown'));
        });
    }
}

<?php

namespace App\Services;

use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Throwable;

class WhatsAppService
{

    protected function wantReal(): bool
    {
        $hasToken  = (bool) config('services.whatsapp.token');
        $forceReal = (bool) config('services.whatsapp.force_real');

        return $forceReal || (app()->environment('production') && $hasToken);
    }

    public function sendText(string $to, string $text): array
    {
        if ($this->wantReal()) {
            $token   = (string) config('services.whatsapp.token');
            $phoneId = (string) config('services.whatsapp.phone_number_id');
            $ver     = (string) config('services.whatsapp.graph_version', 'v20.0');

            try {
                $resp = Http::timeout(15)
                    ->withToken(config('services.whatsapp.token'))
                    ->acceptJson()
                    ->post("https://graph.facebook.com/{$ver}/{$phoneId}/messages", [
                        'messaging_product' => 'whatsapp',
                        'to'   => $to,
                        'type' => 'text',
                        'text' => ['body' => $text],
                    ]);

                $ok    = $resp->successful();              
                $json  = $resp->json();
                $mid   = data_get($json, 'messages.0.id');  

                if (!$ok) {
                    Log::warning('wa.sendText.fail', [
                        'status' => $resp->status(),
                        'body'   => $json,
                    ]);
                }

                return [
                    'ok'         => $ok,
                    'status'     => $resp->status(),
                    'message_id' => $mid,
                    'body'       => $json,
                ];
            } catch (Throwable $e) {
                Log::error('wa.sendText.exception', ['err' => $e->getMessage()]);
                return [
                    'ok'         => false,
                    'status'     => 0,
                    'message_id' => null,
                    'body'       => null,
                    'error'      => $e->getMessage(),
                ];
            }
        }

        Log::info('[WA:FAKE]', ['to' => $to, 'body' => str_replace("\n", ' | ', $text)]);
        return [
            'ok'         => true,
            'status'     => 200,
            'message_id' => 'fake_'.uniqid(),
            'body'       => ['fake' => true],
        ];
    }
}

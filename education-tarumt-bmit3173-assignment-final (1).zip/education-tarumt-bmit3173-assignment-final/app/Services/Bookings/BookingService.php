<?php

namespace App\Services\Bookings;

use App\Models\Booking;
use App\Models\BookingItem;
use App\Models\Flight;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;

class BookingService
{
    private const TAX_RATE = 0.06;

    public function create(array $payload): Booking
    {
        // Normalize quantities
        $items = collect($payload['items'])
            ->map(fn($i) => ['flight_id' => (int)$i['flight_id'],
                             'passenger_name' => (string)$i['passenger_name'],
                             'quantity' => max(1, (int)($i['quantity'] ?? 1)),
                             'seat_no' => $i['seat_no'] ?? null]);

        // group seats required by flight to lock/decrement safely
        $byFlight = $items->groupBy('flight_id')
                          ->map(fn($rows) => $rows->sum('quantity'));

        return DB::transaction(function () use ($payload, $items, $byFlight) {

            // Lock all flights involved, verify inventory, then decrement
            $flights = Flight::whereIn('id', $byFlight->keys())->lockForUpdate()->get()->keyBy('id');

            foreach ($byFlight as $flightId => $need) {
                $f = $flights[$flightId] ?? null;
                if (!$f || $f->seats_available < $need) {
                    throw ValidationException::withMessages([
                        'items' => ["Not enough seats for flight ID {$flightId}."]
                    ]);
                }
            }
            foreach ($byFlight as $flightId => $need) {
                $flights[$flightId]->decrement('seats_available', $need);
            }

            // Create booking shell
            $booking = Booking::create([
                'booking_ref'     => Str::upper(Str::random(6)),
                'contact_name'    => $payload['contact_name'],
                'contact_email'   => $payload['contact_email'],
                'contact_phone'   => $payload['contact_phone'] ?? null,
                'status'          => 'PENDING',
                'expires_at'      => now()->addMinutes(5), // 5‑minute window
                'grand_total_myr' => 0,
                'paid_total_myr'  => 0,
            ]);

            $grand = 0.0;

            foreach ($items as $i) {
                $flight = $flights[$i['flight_id']];

                // pricing: use base fare from flights + tax (MYR as double)
                $unit = (float) $flight->base_fare_myr;
                $tax  = round($unit * self::TAX_RATE, 2);
                $qty  = (int) $i['quantity'];

                $bi = BookingItem::create([
                    'booking_id'     => $booking->id,
                    'flight_id'      => $flight->id,
                    'passenger_name' => $i['passenger_name'],
                    'seat_no'        => $i['seat_no'],
                    'fare_class'     => 'ECON',
                    'unit_price_myr' => $unit,
                    'tax_myr'        => $tax,
                    'quantity'       => $qty,
                ]);

                $grand += ($bi->unit_price_myr + $bi->tax_myr) * $qty;
            }

            $booking->update(['grand_total_myr' => $grand]);

            return $booking->fresh(['items.flight']);
        });
    }
}

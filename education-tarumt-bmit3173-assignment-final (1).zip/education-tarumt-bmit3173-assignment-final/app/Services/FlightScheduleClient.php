<?php

namespace App\Services;

use GuzzleHttp\Client;
use GuzzleHttp\Exception\ConnectException;
use Illuminate\Support\Facades\Log;

class FlightScheduleClient
{
    public function __construct(private Client $http) {}

    public function existsOnDate(string $flightNo, string $date): bool
    {
        $base = rtrim(config('services.flight.base'), '/');

        if (!$base) {
            Log::warning('flight.api.base_not_set');
            return app()->environment('local') ? true : false;
        }

        $url = "{$base}/api/flights";
        try {
            $resp = $this->http->get($url, [
                'query' => ['flight_no' => $flightNo, 'date' => $date],
                'timeout' => 3.0,
                'connect_timeout' => 1.5,
            ]);

            if ($resp->getStatusCode() !== 200) {
                Log::warning('flight.api.non200', ['code' => $resp->getStatusCode()]);
                return false;
            }

            $json = json_decode((string) $resp->getBody(), true);
            return (bool) data_get($json, 'exists', false);

        } catch (ConnectException $e) {
            Log::warning('flight.api.unreachable', ['url' => $url, 'err' => $e->getMessage()]);
            return app()->environment('local') ? true : false;
        } catch (\Throwable $e) {
            Log::error('flight.api.error', ['url' => $url, 'err' => $e->getMessage()]);
            return false;
        }
    }
}

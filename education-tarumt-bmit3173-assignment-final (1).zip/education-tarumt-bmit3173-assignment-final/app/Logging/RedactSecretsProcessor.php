<?php

namespace App\Logging;

final class RedactSecretsProcessor {
    public function __invoke(array $record): array {
        if (isset($record['context']['request']['headers']['Authorization'])) {
            $record['context']['request']['headers']['Authorization'] = 'Bearer **REDACTED**';
        }
        return $record;
    }
}

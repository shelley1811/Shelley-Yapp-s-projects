<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use App\Contracts\PaymentGateway;
use App\Services\Payments\Gateways\FakepayGateway;

class PaymentServiceProvider extends ServiceProvider
{
    /**
     * Register services.
     */
    public function register(): void
    {
        $this->app->bind(PaymentGateway::class, fn () => new FakepayGateway());
    }

    /**
     * Bootstrap services.
     */
    public function boot(): void
    {
        //
    }
}

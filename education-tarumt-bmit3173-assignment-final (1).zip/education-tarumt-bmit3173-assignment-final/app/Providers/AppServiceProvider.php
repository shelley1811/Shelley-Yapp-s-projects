<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use Illuminate\Database\Eloquent\Model;

// Adapter + Observer pattern
use App\Models\Route as RouteModel;
use App\Observers\RouteObserver;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        //
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        Model::preventSilentlyDiscardingAttributes(! $this->app->isProduction());

        // Add observer to ensure flight and route tables are in-sync
        RouteModel::observe(RouteObserver::class);
    }
}

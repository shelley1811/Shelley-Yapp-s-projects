<?php

namespace App\Contracts;
use App\Services\Payments\DTO\ChargeResult;

interface PaymentGateway
{
    public function charge(float $amountMyr, string $token, array $meta = []): ChargeResult;
}

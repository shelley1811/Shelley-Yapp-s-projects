<?php

namespace App\Domain\Notifications;

use App\Models\CrewAssignment;
use Carbon\Carbon;

class UpdateAssignmentComposer implements AssignmentMessageComposer
{
    public function compose(CrewAssignment $a, ?array $before = null, ?array $after = null): string
    {
        $fmt = fn($ts) => Carbon::parse($ts, 'UTC')
            ->setTimezone('Asia/Kuala_Lumpur')
            ->format('Y-m-d H:i');

        $lines   = [];
        $lines[] = "Assignment Update #{$a->id}";
        $lines[] = "Channel: WhatsApp";

        if (($before['flight_no'] ?? null) !== ($after['flight_no'] ?? null)) {
            $lines[] = "Flight: {$before['flight_no']} → {$after['flight_no']}";
        } else {
            $lines[] = "Flight: {$after['flight_no']}";
        }

        if (($before['dep_time'] ?? null) !== ($after['dep_time'] ?? null)) {
            $lines[] = "Report: ".$fmt($before['dep_time'])." → ".$fmt($after['dep_time'])." MYT";
        } else {
            $lines[] = "Report: ".$fmt($after['dep_time'])." MYT";
        }

        if (($before['role'] ?? null) !== ($after['role'] ?? null)) {
            $lines[] = "Role: ".($before['role'] ?? '-')." → ".($after['role'] ?? '-');
        } else {
            $lines[] = "Role: ".($after['role'] ?? '-');
        }

        if (($before['crew_phone'] ?? null) !== ($after['crew_phone'] ?? null)) {
            $lines[] = "Note: contact updated.";
        }

        return implode("\n", $lines);
    }
}

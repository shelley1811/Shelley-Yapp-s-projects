<?php

namespace App\Domain\Notifications;

use App\Models\CrewAssignment;

interface AssignmentMessageComposer
{
    public function compose(
        CrewAssignment $a,
        ?array $before = null,
        ?array $after = null
    ): string;
}

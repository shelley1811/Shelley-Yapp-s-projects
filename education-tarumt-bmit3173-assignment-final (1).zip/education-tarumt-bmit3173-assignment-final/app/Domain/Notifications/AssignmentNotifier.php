<?php

namespace App\Domain\Notifications;

use App\Models\CrewAssignment;
use App\Services\WhatsAppService;

class AssignmentNotifier
{
    public function __construct(
        private AssignmentMessageComposer $composer,
        private WhatsAppService $wa
    ) {}

    public function notify(CrewAssignment $a, ?array $before = null, ?array $after = null): array
    {
        $msg = $this->composer->compose($a, $before, $after);
        return $this->wa->sendText($a->crew_phone, $msg);
    }
}

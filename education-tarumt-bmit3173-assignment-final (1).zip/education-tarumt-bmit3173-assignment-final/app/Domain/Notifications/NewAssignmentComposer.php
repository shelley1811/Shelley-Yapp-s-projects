<?php

namespace App\Domain\Notifications;

use App\Models\CrewAssignment;
use Carbon\Carbon;

class NewAssignmentComposer implements AssignmentMessageComposer
{
    public function compose(CrewAssignment $a, ?array $before = null, ?array $after = null): string
    {
        return "Assignment\n"
             . "Flight: {$a->flight_no}\n"
             . "Report: {$this->myt($a->dep_time)} MYT\n"
             . "Role: " . ($a->role ?? '-');
    }

    private function myt($ts): string
    {
        return Carbon::parse($ts, 'UTC')
            ->setTimezone('Asia/Kuala_Lumpur')
            ->format('Y-m-d H:i');
    }
}

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Payment extends Model
{
    protected $fillable = [
        'booking_id','status','amount_myr','method','provider','transaction_ref','paid_at','payload'
    ];

    protected $casts = ['paid_at' => 'datetime', 'payload' => 'array'];

    public function booking() { return $this->belongsTo(Booking::class); }
}

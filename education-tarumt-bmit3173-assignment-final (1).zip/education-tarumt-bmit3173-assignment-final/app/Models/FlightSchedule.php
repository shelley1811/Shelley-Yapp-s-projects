<?php

/**
 * FlightSchedule Model
 *
 * Name: Bryian Aldey
 * Module: Flight Schedule Management
 * Task: Handling flight schedule records and database interactions
 */
namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class FlightSchedule extends Model
{
   use HasFactory;
    protected $primaryKey = 'route_id'; // <-- add this line
    public $incrementing = false;            // Since route_id is string
    protected $keyType = 'string';
    public $timestamps = false;

    protected $fillable = [
        'route_id',
        'departure_airport',
        'arrival_airport',
        'departure_date',
        'departure_time',
        'arrival_time',
        'gate',
        'aircraft_registration_number',
    ];

    // Relationships
    public function departureAirport()
    {
        return $this->belongsTo(Airport::class, 'departure_airport', 'iata_code');
    }

    public function arrivalAirport()
    {
        return $this->belongsTo(Airport::class, 'arrival_airport', 'iata_code');
    }

    public function aircraft()
    {
        return $this->belongsTo(Aircraft::class, 'aircraft_registration_number', 'registration_number');
    }
    public function route()
    {
        return $this->belongsTo(Route::class, 'route_id', 'route_id'); // adjust the foreign key and local key column names if different
    }
    
   
    

}

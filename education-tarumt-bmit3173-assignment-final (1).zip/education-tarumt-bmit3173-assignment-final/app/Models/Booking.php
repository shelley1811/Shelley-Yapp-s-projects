<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Booking extends Model
{
    protected $fillable = [
        'booking_ref','user_id','contact_name','contact_email','contact_phone',
        'status','grand_total_myr','paid_total_myr','expires_at'
    ];

    protected $casts = ['expires_at' => 'datetime'];

    public function items()    { return $this->hasMany(BookingItem::class); }
    public function payments() { return $this->hasMany(Payment::class); }

    // Convenient computed values for UI/API
    public function getBalanceMyrAttribute(): float {
        return max(0, ($this->grand_total_myr ?? 0) - ($this->paid_total_myr ?? 0));
    }
    public function getIsExpiredAttribute(): bool {
        return $this->status === 'PENDING' && $this->expires_at && now()->greaterThan($this->expires_at);
    }
}

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Flight extends Model
{
    protected $fillable = [
        'flight_no','origin','destination','flight_date',
        'departure_time','arrival_time','duration_minutes',
        'base_fare_myr','seats_total','seats_available'
    ];

    public function items() { return $this->hasMany(BookingItem::class); }
}

<?php

/**
 * Name: Daniel Aidan Edmund
 * This model represents aircraft registered with SkyReserve, including details such as registration number, model, manufacturer, capacity, range, and associated airline.
 */

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory; 
use Illuminate\Database\Eloquent\Model; 

class Aircraft extends Model
{
    use HasFactory; 

    public $timestamps = false; 

    protected $fillable = [
        'registration_number', // Unique ID like a license plate
        'model', // Aircraft type
        'manufacturer', // Who made it
        'capacity', // Number of passengers it can carry
        'range_km', // Flight range in kilometers
        'airline', // Owning airline
        'base_iata', // Airport code where it's based
    ];

    public function routes()
    {
        return $this->hasMany(Route::class);
    }

    public function baseAirport()
    {
        // Links base_iata in aircraft to iata_code in airports table
        return $this->belongsTo(Airport::class, 'base_iata', 'iata_code');
    }
}

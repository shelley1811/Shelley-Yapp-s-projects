<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class BookingItem extends Model
{
    protected $fillable = [
        'booking_id','flight_id','passenger_name','seat_no','fare_class',
        'unit_price_myr','tax_myr','quantity'
    ];

    public function booking() { return $this->belongsTo(Booking::class); }
    public function flight()  { return $this->belongsTo(Flight::class); }

    public function getLineTotalMyrAttribute(): float {
        return ($this->unit_price_myr + $this->tax_myr) * ($this->quantity ?? 1);
    }
}

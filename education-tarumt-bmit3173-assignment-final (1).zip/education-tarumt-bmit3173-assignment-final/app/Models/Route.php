<?php
/**
 * Name: Daniel Aidan Edmund
 *
 * This model represents a flight route in the SkyReserve system.
 */
namespace App\Models; 

use Illuminate\Database\Eloquent\Factories\HasFactory; 
use Illuminate\Database\Eloquent\Model; 

class Route extends Model
{
    use HasFactory; 

    public $timestamps = false;

    protected $fillable = [
        'route_id', // A unique identifier for this route (like a flight number)
        'aircraft_registration', // Which aircraft will fly this route (links to aircraft table)
        'status', // Current status of the route (active, inactive, cancelled, etc.)
        'weather_condition', // Weather information that might affect the flight
        'has_delay', // Whether this flight is delayed (true or false)
        'delay_in_minutes', // Delay duration in minutes
        'delay_reason', // Why the flight is delayed
    ];

    protected $casts = [
        'has_delay' => 'boolean', // Convert to true/false instead of 1/0
        'delay_in_minutes' => 'integer', // Convert to a number
    ];

    public function flightSchedule()
{
    return $this->hasOne(FlightSchedule::class, 'route_id', 'route_id');
}

}

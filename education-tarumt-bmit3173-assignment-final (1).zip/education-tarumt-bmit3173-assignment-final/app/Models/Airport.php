<?php
/**
 * Name: Daniel Aidan Edmund
 * This model represents airport registered with SkyReserve, including details such as IATA code, name, city, country, latitude, and longitude.
 */
namespace App\Models; 

use Illuminate\Database\Eloquent\Factories\HasFactory; 
use Illuminate\Database\Eloquent\Model; 

class Airport extends Model
{
    use HasFactory; 

    public $timestamps = false;

    protected $fillable = [
        'iata_code', // The 3-letter airport code (like KUL for Kuala Lumpur)
        'name', // The full name of the airport
        'city', // The city where the airport is located
        'country', // The country where the airport is located
        'latitude', // The north-south position on the map (like GPS coordinates)
        'longitude', // The east-west position on the map (like GPS coordinates)
    ];
}

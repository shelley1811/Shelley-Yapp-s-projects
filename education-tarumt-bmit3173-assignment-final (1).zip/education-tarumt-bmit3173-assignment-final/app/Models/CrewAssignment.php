<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CrewAssignment extends Model
{
    use HasFactory;

    public const STATUS_QUEUED = 'queued';
    public const STATUS_SENT   = 'sent';
    public const STATUS_FAILED = 'failed';

    protected $casts = [
    'vendor_payload' => 'array',
    'dep_time'   => 'datetime:Y-m-d H:i:s',
    'sent_at'    => 'datetime:Y-m-d H:i:s',
    'created_at' => 'datetime:Y-m-d H:i:s',
    'updated_at' => 'datetime:Y-m-d H:i:s',
];

protected $fillable = [
    'crew_id','crew_phone','flight_no','dep_time','role','status','channel',
    'sent_at','vendor_message_id','vendor_payload',
];

    public function crew()
    {
        return $this->belongsTo(Crew::class);
    }
}

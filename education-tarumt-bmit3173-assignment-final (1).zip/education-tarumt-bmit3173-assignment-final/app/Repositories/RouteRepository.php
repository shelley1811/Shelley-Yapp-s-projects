<?php
/**
 * Name: Daniel Aidan Edmund
 *
 * This is a Repository class for managing Route data.
 */
namespace App\Repositories; 

use App\Models\Route; 
use Illuminate\Database\Eloquent\Collection; 

class RouteRepository
{
    /**
     * Get all routes from the database.
     *
     * @return Collection A collection of all route records
     */
    public function getAll(): Collection
    {
        return Route::all(); // Get every route from the database
    }

    /**
     * Find a specific route by its ID number.
     *
     * @param int $id The unique ID of the route we want to find
     * @return Route|null The route if found, or null if not found
     */
    public function findById(int $id): ?Route
    {
        return Route::find($id); // Search for a route with this specific ID
    }

    /**
     * Find all routes that use a specific aircraft.
     * This is like asking the librarian for all books written by a certain author.
     *
     * @param string $registration The aircraft registration number
     * @return Collection All routes that use this aircraft
     */
    public function findByAircraftRegistration(string $registration): Collection
    {
        return Route::where('aircraft_registration', $registration)->get(); // Find routes with this aircraft
    }

    /**
     * Create a new route in the database.
     * This is like adding a new book to the library's collection.
     *
     * @param array $data The information for the new route (like title, author, etc.)
     * @return Route The newly created route
     */
    public function create(array $data): Route
    {
        // Add delay_in_minutes based on has_delay flag
        $data['delay_in_minutes'] = !empty($data['has_delay']) && $data['has_delay'] ? 60 : 0;

        return Route::create($data); // Create and save a new route with the provided data
    }

    /**
     * Update an existing route with new information.
     * This is like updating a book's information in the library catalog.
     *
     * @param int $id The ID of the route to update
     * @param array $data The new information to save
     * @return bool True if updated successfully, false if route not found
     */
    public function update(int $id, array $data): bool
    {
        // Add delay_in_minutes based on has_delay flag
        $data['delay_in_minutes'] = !empty($data['has_delay']) && $data['has_delay'] ? 60 : 0;

        $route = $this->findById($id); // First find the route
        if ($route) { // If we found it
            return $route->update($data); // Update it with the new data
        }
        return false; // Return false if we couldn't find the route
    }

    /**
     * Delete a route from the database.
     *
     * @param int $id The ID of the route to delete
     * @return bool True if deleted successfully, false if route not found
     */
    public function delete(int $id): bool
    {
        $route = $this->findById($id); // First find the route
        if ($route) { // If we found it
            return $route->delete(); // Delete it from the database
        }
        return false; // Return false if we couldn't find the route
    }
}

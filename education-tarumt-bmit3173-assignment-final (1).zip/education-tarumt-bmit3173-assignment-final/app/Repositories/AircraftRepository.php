<?php
/**
 * Name: Daniel Aidan Edmund
 *
 * This is a Repository class for managing Aircraft data.
 */
namespace App\Repositories; 

use App\Models\Aircraft; 
use Illuminate\Database\Eloquent\Collection;

class AircraftRepository
{
    /**
     * Get all aircraft from the database, including their base airport information.
     * @return Collection 
     */
    public function getAll(): Collection
    {
        return Aircraft::with('baseAirport')->get(); // Get all aircraft and include their base airport info
    }

    /**
     * Find a specific aircraft by its ID number.     *
     * @param int $id The unique ID of the aircraft we want to find
     * @return Aircraft|null The aircraft if found, or null if not found
     */
    public function findById(int $id): ?Aircraft
    {
        return Aircraft::find($id); // Search for an aircraft with this specific ID
    }

    /**
     * Find an aircraft by its registration number (like a license plate).
     *
     * @param string $registration The aircraft's registration number
     * @return Aircraft|null The aircraft if found, or null if not found
     */
    public function findByRegistration(string $registration): ?Aircraft
    {
        return Aircraft::where('registration_number', $registration)->first(); // Find the first aircraft with this registration
    }

    /**
     * Find all aircraft that are based at a specific airport.
     *      *
     * @param string $iata The 3-letter airport code (like KUL for Kuala Lumpur)
     * @return Collection All aircraft based at this airport
     */
    public function findByBaseIata(string $iata): Collection
    {
        return Aircraft::where('base_iata', $iata)->get(); // Find aircraft based at this airport
    }

    /**
     * Get aircraft that are available for use (not currently assigned to any routes).
     *
     * @return Collection Aircraft that don't have any assigned routes
     */
    public function getAvailable(): Collection
    {
        // This assumes an aircraft is available if it's not assigned to any route
        return Aircraft::whereDoesntHave('routes')->get(); // Find aircraft without any routes
    }

    /**
     * Create a new aircraft in the database.
     *
     * @param array $data The information for the new aircraft (model, registration, etc.)
     * @return Aircraft The newly created aircraft
     */
    public function create(array $data): Aircraft
    {
        return Aircraft::create($data); // Create and save a new aircraft with the provided data
    }

    /**
     * Update an existing aircraft with new information.
     *
     * @param int $id The ID of the aircraft to update
     * @param array $data The new information to save
     * @return bool True if updated successfully, false if aircraft not found
     */
    public function update(int $id, array $data): bool
    {
        $aircraft = $this->findById($id); // First find the aircraft
        if ($aircraft) { // If we found it
            return $aircraft->update($data); // Update it with the new data
        }
        return false; // Return false if we couldn't find the aircraft
    }

    /**
     * Delete an aircraft from the database.
     *
     * @param int $id The ID of the aircraft to delete
     * @return bool True if deleted successfully, false if aircraft not found
     */
    public function delete(int $id): bool
    {
        $aircraft = $this->findById($id); // First find the aircraft
        if ($aircraft) { // If we found it
            return $aircraft->delete(); // Delete it from the database
        }
        return false; // Return false if we couldn't find the aircraft
    }
}

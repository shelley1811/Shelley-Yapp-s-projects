<?php

/**
 * Name: Bryian Aldey
 * Module: Flight Schedule Management
 * Description: Repository for handling database operations related to flight schedules.
 */

namespace App\Repositories;

use App\Models\FlightSchedule;

class FlightScheduleRepository
{
     /**
     * Get all flight schedules with related airport and aircraft data.
     */
    public function getAll()
    {
        return FlightSchedule::with(['departureAirport', 'arrivalAirport', 'aircraft'])->get();
    }

    /**
     * Find schedule by route_id (unique PK).
     */
    public function find($routeId)
    {
        return FlightSchedule::with(['departureAirport', 'arrivalAirport', 'aircraft'])
            ->where('route_id', $routeId)
            ->first();
    }

    /**
     * Create a new flight schedule.
     */
    public function create(array $data)
    {
        return FlightSchedule::create($data);
    }

    /**
     * Update an existing flight schedule.
     */
    public function update($routeId, array $data)
    {
        $schedule = FlightSchedule::where('route_id', $routeId)->first();
        if ($schedule) {
            $schedule->update($data);
            return true;
        }
        return false;
    }

    /**
     * Delete a flight schedule.
     */
    public function delete($routeId)
    {
        $schedule = FlightSchedule::where('route_id', $routeId)->first();
        if ($schedule) {
            $schedule->delete();
            return true;
        }
        return false;
    }
}
<?php
/**
 * Name: Daniel Aidan Edmund
 *
 * This is a Repository class for managing Airport data.
 */
namespace App\Repositories; 

use App\Models\Airport; 
use Illuminate\Database\Eloquent\Collection; 

class AirportRepository
{
    /**
     * Get all airports from the database.
     *
     * @return Collection
     */
    public function getAll(): Collection
    {
        return Airport::all(); // Get every airport from the database
    }

    /**
     * Find a specific airport by its ID number.
     *
     * @param int $id The unique ID of the airport we want to find
     * @return Airport|null The airport if found, or null if not found
     */
    public function findById(int $id): ?Airport
    {
        return Airport::find($id); // Search for an airport with this specific ID
    }

    /**
     * Find an airport by its IATA code (like KUL for Kuala Lumpur).
     *
     * @param string $code The airport's IATA code
     * @return Airport|null The airport if found, or null if not found
     */
    public function findByCode(string $code): ?Airport
    {
        return Airport::where('iata_code', $code)->first(); // Find the first airport with this IATA code
    }

    /**
     * Create a new airport in the database.
     *
     * @param array $data The information for the new airport (name, city, country, etc.)
     * @return Airport The newly created airport
     */
    public function create(array $data): Airport
    {
        return Airport::create($data); // Create and save a new airport with the provided data
    }

    /**
     * Update an existing airport with new information.
     *
     * @param int $id The ID of the airport to update
     * @param array $data The new information to save
     * @return bool True if updated successfully, false if airport not found
     */
    public function update(int $id, array $data): bool
    {
        $airport = $this->findById($id); // First find the airport
        if ($airport) { // If we found it
            return $airport->update($data); // Update it with the new data
        }
        return false; // Return false if we couldn't find the airport
    }

    /**
     * Delete an airport from the database.
     *
     * @param int $id The ID of the airport to delete
     * @return bool True if deleted successfully, false if airport not found
     */
    public function delete(int $id): bool
    {
        $airport = $this->findById($id); // First find the airport
        if ($airport) { // If we found it
            return $airport->delete(); // Delete it from the database
        }
        return false; // Return false if we couldn't find the airport
    }
}

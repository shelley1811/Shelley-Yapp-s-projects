<?php

namespace App\Http\Controllers;

use App\Http\Requests\StoreCrewRequest;
use App\Http\Requests\UpdateCrewRequest;
use App\Models\Crew;
use Illuminate\Http\Request;

class CrewController extends Controller
{
    // GET /api/crews
    public function index(Request $req)
    {
        $q = Crew::query();

        if ($req->get('trashed') === 'with') {
            $q->withTrashed();
        } elseif ($req->get('trashed') === 'only') {
            $q->onlyTrashed();
        }

        if ($kw = trim((string)$req->get('q'))) {
            $q->where(function ($x) use ($kw) {
                $x->where('name', 'like', "%{$kw}%")
                  ->orWhere('phone', 'like', "%{$kw}%")
                  ->orWhere('email', 'like', "%{$kw}%")
                  ->orWhere('base', 'like', "%{$kw}%")    
                  ->orWhere('role', 'like', "%{$kw}%");
            });
        }

        if ($role = $req->get('role')) {
            $q->where('role', $role);
        }
        if ($base = $req->get('base')) {
            $q->where('base', strtoupper($base));
        }
        if ($req->filled('active')) {
            $q->where('is_active', (bool)$req->boolean('active'));
        }

        $sort = (string)($req->get('sort', '-id'));
        $dir = str_starts_with($sort, '-') ? 'desc' : 'asc';
        $col = ltrim($sort, '-');
        if (!in_array($col, ['id','name','phone','role','base','created_at','updated_at'], true)) {
            $col = 'id';
        }
        $q->orderBy($col, $dir);

        $per = max(1, min(100, (int)$req->get('per_page', 6)));
        return response()->json($q->paginate($per));
    }

    // POST /api/crews
    public function store(StoreCrewRequest $req)
    {
        $crew = Crew::create($req->validated());
        return response()->json($crew, 201);
    }

    // GET /api/crews/{crew}
    public function show(Crew $crew)
    {
        return response()->json($crew);
    }

    // PUT/PATCH /api/crews/{crew}
    public function update(UpdateCrewRequest $req, Crew $crew)
    {
        $crew->update($req->validated());
        return response()->json($crew->fresh());
    }

    // DELETE /api/crews/{crew} 
    public function destroy(Crew $crew)
    {
        $crew->delete();
        return response()->noContent();
    }

    // POST /api/crews/{id}/restore  
    public function restore($id)
    {
        $crew = Crew::withTrashed()->findOrFail($id);
        $crew->restore();
        return response()->json($crew);
    }


    public function assignments(Crew $crew, Request $req)
    {
        $perPage = (int) $req->input('per_page', 3);
        $perPage = max(1, min($perPage, 100));
        $q = $crew->assignments()->latest('id');
        if ($status = $req->get('status')) {
        $q->where('status', $status);
    }

    return response()->json($q->paginate($perPage)); 
}
}


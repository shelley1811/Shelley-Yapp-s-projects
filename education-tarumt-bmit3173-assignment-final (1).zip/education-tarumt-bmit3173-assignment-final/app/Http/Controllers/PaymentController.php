<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests\StorePaymentRequest;
use App\Http\Resources\PaymentResource;
use App\Models\Booking;
use App\Services\Payments\PaymentService;
use Resend\Laravel\Facades\Resend;


class PaymentController extends Controller
{
    public function store(StorePaymentRequest $request, Booking $booking, PaymentService $service)
    {
        $payment = $service->capture(
            $booking,
            (float) $request->input('amount_myr'),
            (string) $request->input('method'),
            $request->only('token','simulate')
        );

        $payment->load('booking');
        $b = $payment->booking;

        try {
            $fromName = config('mail.from.name', 'Acme');
            $fromAddr = config('mail.from.address', 'onboarding@resend.dev');
            Resend::emails()->send([
                'from'    => "{$fromName} <{$fromAddr}>",
                'to'      => [$b->contact_email],
                'subject' => 'Booking Confirmation ' . ($b->booking_ref ?? ''),
                'html'    => sprintf(
                    '<p>Hi %s,</p>
                     <p>Thanks for your booking.</p>
                     <p><strong>Reference:</strong> %s<br>
                        <strong>Status:</strong> %s<br>
                        <strong>Grand Total:</strong> MYR %s
                     </p>
                     <p>We will notify you again once everything is finalized.</p>
                     <p>— %s</p>',
                    e($b->contact_name ?? 'Customer'),
                    e($b->booking_ref ?? ''),
                    e($b->status ?? 'PENDING'),
                    number_format((float)($b->grand_total_myr ?? 0), 2),
                    e($fromName)
                ),
            ]);
        } catch (\Throwable $e) {
            // Prototype: swallow errors so the API still returns 201
            // You can add logging later if needed.
        }

        return (new PaymentResource($payment))->response()->setStatusCode(201);
    }
}

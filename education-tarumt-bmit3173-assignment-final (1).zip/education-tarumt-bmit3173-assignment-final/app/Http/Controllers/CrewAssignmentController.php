<?php

namespace App\Http\Controllers;

use App\Http\Requests\StoreCrewAssignmentRequest;
use App\Http\Requests\UpdateCrewAssignmentRequest;
use App\Models\Crew;
use App\Models\CrewAssignment;
use App\Services\WhatsAppService;
use App\Services\FlightScheduleClient;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use App\Domain\Notifications\NewAssignmentComposer;
use App\Domain\Notifications\UpdateAssignmentComposer;

class CrewAssignmentController extends Controller
{
    // GET /api/crew-assignments?status=sent
    public function index(Request $req)
    {
        try {
            $q = CrewAssignment::query()->orderByDesc('id');
            if ($status = $req->get('status')) {
                $q->where('status', $status);
            }
            return response()->json($q->paginate(20));
        } catch (\Throwable $e) {
            Log::error('crew-assignments.index', ['err' => $e->getMessage()]);
            return response()->json(['message' => 'DB error', 'error' => $e->getMessage()], 500);
        }
    }

    // POST /api/crew-assignments
    public function store(StoreCrewAssignmentRequest $req, WhatsAppService $wa, FlightScheduleClient $flights)
    {

        $data = $req->validated();

        $crew    = Crew::where('phone', $data['crewPhone'])->first();
        $depTime = Carbon::parse($data['depTime']);

        $localDate = $depTime->copy()->setTimezone('Asia/Kuala_Lumpur')->toDateString();
        if (!$flights->existsOnDate($data['flightNo'], $localDate)) {
            return response()->json([
                'ok' => false,
                'message' => 'Flight not found for the selected date.',
            ], 422);
        }

        $assignment = CrewAssignment::create([
            'crew_id'    => $crew?->id,
            'crew_phone' => $data['crewPhone'],
            'flight_no'  => $data['flightNo'],
            'dep_time'   => $depTime,
            'role'       => $data['role'] ?? null,
            'status'     => 'queued',
            'channel'    => 'whatsapp',
        ]);

        $msg = app(NewAssignmentComposer::class)->compose($assignment);
        $res = $wa->sendText($assignment->crew_phone, $msg);

        $ok        = (bool) data_get($res, 'ok', false);
        $messageId = data_get($res, 'message_id') ?? data_get($res, 'body.messages.0.id');

        $assignment->update([
            'status'            => $ok ? 'sent' : 'failed',
            'sent_at'           => $ok ? now() : null,
            'vendor_message_id' => $messageId,
            'vendor_payload'    => $res,
        ]);

        return response()->json([
            'ok'      => $ok,
            'message' => $ok ? 'sent' : 'failed',
            'data'    => $assignment->fresh(),
            'vendor'  => $res,
        ], $ok ? 200 : 502);
    }

    // POST /api/crew-assignments/{assignment}/resend
    public function resend(CrewAssignment $assignment, WhatsAppService $wa)
    {
        $msg = "Assignment\nFlight: {$assignment->flight_no}\nReport: {$assignment->dep_time->format('Y-m-d H:i')}\nRole: {$assignment->role}";
        $res = $wa->sendText($assignment->crew_phone, $msg);

        $ok        = (bool) data_get($res, 'ok', false);
        $messageId = data_get($res, 'message_id') ?? data_get($res, 'body.messages.0.id');

        $assignment->update([
            'status'            => $ok ? 'sent' : 'failed',
            'sent_at'           => $ok ? now() : $assignment->sent_at,
            'vendor_message_id' => $messageId ?? $assignment->vendor_message_id,
            'vendor_payload'    => $res,
        ]);

        Log::info('crew-assignments.resend', [
            'id' => $assignment->id,
            'to' => $assignment->crew_phone,
            'ok' => $ok,
            'res'=> $res,
        ]);

        return response()->json([
            'ok'      => $ok,
            'message' => $ok ? 'resent' : 'failed',
            'data'    => $assignment->fresh(),
            'vendor'  => $res,
        ], $ok ? 200 : 502);
    }

    // PATCH /api/crew-assignments/{assignment}
    public function update(UpdateCrewAssignmentRequest $req, CrewAssignment $assignment, WhatsAppService $wa, FlightScheduleClient $flights)
    {
        $data    = $req->validated();
        $notify  = (bool) $req->boolean('notify', false);

        $before = $assignment->only(['crew_phone','flight_no','dep_time','role']);

        $flightChanged = $assignment->flight_no !== $data['flightNo'];
        $timeChanged   = $assignment->dep_time?->format('Y-m-d H:i:s') !== (string)$data['depTime'];
        if ($flightChanged || $timeChanged) {
            $depUtc    = Carbon::parse($data['depTime'], 'UTC');
            $localDate = $depUtc->copy()->setTimezone('Asia/Kuala_Lumpur')->toDateString();
            if (!$flights->existsOnDate($data['flightNo'], $localDate)) {
                return response()->json([
                    'ok' => false,
                    'message' => 'Flight not found for the selected date.',
                ], 422);
            }
        }

        $assignment->update([
            'crew_phone' => $data['crewPhone'],
            'flight_no'  => $data['flightNo'],
            'dep_time'   => $data['depTime'],
            'role'       => $data['role'],
        ]);

        $after  = $assignment->only(['crew_phone','flight_no','dep_time','role']);

        $vendor = null;
        $ok     = true;

        if ($notify) {
            $composer = app(UpdateAssignmentComposer::class);
            $msg = $composer->compose($assignment, $before, $after);
            $res = $wa->sendText($assignment->crew_phone, $msg);

            $ok        = (bool) data_get($res, 'ok', false);
            $messageId = data_get($res, 'body.messages.0.id');

            $assignment->update([
                'status'            => $ok ? 'sent' : 'failed',
                'sent_at'           => $ok ? now() : $assignment->sent_at,
                'vendor_message_id' => $messageId ?? $assignment->vendor_message_id,
                'vendor_payload'    => $res,
            ]);

            $vendor = $res;
        }

        return response()->json([
            'ok'      => $ok,
            'message' => $notify ? ($ok ? 'updated & notified' : 'update saved, notify failed') : 'updated',
            'data'    => $assignment->fresh(),
            'vendor'  => $vendor,
        ], $ok ? 200 : 502);
    }

    protected function buildUpdateMessage(CrewAssignment $a, array $before, array $after): string
    {
        $fmt = fn(string $ts) => Carbon::parse($ts, 'UTC')
            ->format('Y-m-d H:i');

        $lines   = [];
        $lines[] = "Assignment Update #{$a->id}";
        $lines[] = "Channel: WhatsApp";

        if ($before['flight_no'] !== $after['flight_no']) {
            $lines[] = "Flight: {$before['flight_no']} → {$after['flight_no']}";
        } else {
            $lines[] = "Flight: {$after['flight_no']}";
        }

        if ($before['dep_time'] !== $after['dep_time']) {
            $lines[] = "Report: ".$fmt($before['dep_time'])." → ".$fmt($after['dep_time'])." MYT";
        } else {
            $lines[] = "Report: ".$fmt($after['dep_time'])." MYT";
        }

        if (($before['role'] ?? null) !== ($after['role'] ?? null)) {
            $lines[] = "Role: ".($before['role'] ?? '-')." → ".($after['role'] ?? '-');
        } else {
            $lines[] = "Role: ".($after['role'] ?? '-');
        }

        if ($before['crew_phone'] !== $after['crew_phone']) {
            $lines[] = "Note: contact updated.";
        }

        return implode("\n", $lines);
    }

    // DELETE /api/crew-assignments/{assignment}
    public function destroy(CrewAssignment $assignment)
    {
        $assignment->delete();
        return response()->json(['ok' => true]);
    }
    
}

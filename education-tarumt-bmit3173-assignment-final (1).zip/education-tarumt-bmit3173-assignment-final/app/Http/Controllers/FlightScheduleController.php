<?php

namespace App\Http\Controllers;

use App\Models\FlightSchedule;
use Illuminate\Http\Request;

class FlightScheduleController extends Controller
{
    /**
     * GET /api/flight-schedules
     */
    public function index()
    {
        return response()->json(
            FlightSchedule::with(['route', 'aircraft', 'departureAirport', 'arrivalAirport'])->get()
        );
    }

    /**
     * GET /api/flight-schedules/{routeId}
     */
    public function show($routeId)
    {
        $schedule = FlightSchedule::with(['route', 'aircraft', 'departureAirport', 'arrivalAirport'])
            ->where('route_id', $routeId)
            ->first();

        if (!$schedule) {
            return response()->json(['message' => 'Flight schedule not found'], 404);
        }
        return response()->json($schedule);
    }

    /**
     * POST /api/flight-schedules
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'route_id' => 'required|string|unique:flight_schedules,route_id',
            'departure_airport' => 'required|string|max:5',
            'arrival_airport' => 'required|string|max:5',
            'departure_date' => 'required|date',
            'departure_time' => 'required',
            'arrival_time' => 'required',
            'gate' => 'nullable|string|max:10',
            'aircraft_registration_number' => 'required|string'
        ]);

        $schedule = FlightSchedule::create($validated);
        return response()->json(
            $schedule->load(['route', 'aircraft', 'departureAirport', 'arrivalAirport']),
            201
        );
    }

    /**
     * PUT /api/flight-schedules/{routeId}
     */
    public function update(Request $request, $routeId)
    {
        $schedule = FlightSchedule::where('route_id', $routeId)->first();
        if (!$schedule) {
            return response()->json(['message' => 'Flight schedule not found'], 404);
        }

        $validated = $request->validate([
            'departure_airport' => 'sometimes|string|max:5',
            'arrival_airport' => 'sometimes|string|max:5',
            'departure_date' => 'sometimes|date',
            'departure_time' => 'sometimes',
            'arrival_time' => 'sometimes',
            'gate' => 'nullable|string|max:10',
            'aircraft_registration_number' => 'sometimes|string'
        ]);

        $schedule->update($validated);
        return response()->json($schedule->load(['route', 'aircraft', 'departureAirport', 'arrivalAirport']));
    }

    /**
     * DELETE /api/flight-schedules/{routeId}
     */
    public function destroy($routeId)
    {
        $schedule = FlightSchedule::where('route_id', $routeId)->first();
        if (!$schedule) {
            return response()->json(['message' => 'Flight schedule not found'], 404);
        }
        $schedule->delete();
        return response()->json(['message' => 'Flight schedule deleted successfully']);
    }

    /**
     * GET /api/flight-schedules/filter
     */
    public function filter(Request $request)
    {
          $query = FlightSchedule::query();

    if ($request->filled('departure_airport')) {
        $query->where('departure_airport', $request->departure_airport);
    }

    if ($request->filled('arrival_airport')) {
        $query->where('arrival_airport', $request->arrival_airport);
    }

    if ($request->filled('departure_date')) {
        $query->where('departure_date', $request->departure_date);
    }

    $results = $query->get();

    if ($results->isEmpty()) {
        return response()->json(['message' => 'Flight schedule not found'], 404);
    }

        return response()->json($results);
    }

    /**
     * GET /api/flight-schedules/stats/daily
     */
    public function getDailyStats()
    {
        $stats = FlightSchedule::selectRaw('departure_date, COUNT(*) as total')
            ->groupBy('departure_date')
            ->orderBy('departure_date')
            ->get();

        return response()->json($stats);
    }

    /**
     * GET /api/flight-schedules/stats/aircraft
     */
    public function getAircraftUtilization()
    {
        $stats = FlightSchedule::selectRaw('aircraft_registration_number, COUNT(*) as total')
            ->groupBy('aircraft_registration_number')
            ->orderBy('total', 'desc')
            ->get();

        return response()->json($stats);
    }
}
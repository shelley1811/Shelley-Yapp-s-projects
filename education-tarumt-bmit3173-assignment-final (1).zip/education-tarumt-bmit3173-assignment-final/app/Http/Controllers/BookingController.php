<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests\StoreBookingRequest;
use App\Http\Resources\BookingResource;
use App\Models\Booking;
use App\Services\Bookings\BookingService;


class BookingController extends Controller
{
    public function store(StoreBookingRequest $request, BookingService $service)
    {
        $booking = $service->create($request->validated());
        $booking->load('items.flight');

        return (new BookingResource($booking))
                ->response()
                ->setStatusCode(201);
    }

    public function show(Booking $booking)
    {
        $booking->load('items.flight', 'payments');
        return new BookingResource($booking);
    }
}

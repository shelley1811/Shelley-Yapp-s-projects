<?php
/**
 * Name: Daniel Aidan Edmund
 *
 * This is a controller file. Controllers handle requests from users and decide what to do with them.
 * This controller manages airline operations like viewing data, creating routes, and updating information.
 */
namespace App\Http\Controllers; // This tells PHP where this file belongs

use Illuminate\Http\Request; 
use App\Repositories\AirportRepository; 
use App\Repositories\RouteRepository; 
use App\Repositories\AircraftRepository; 

class AirlinesOperationsController extends Controller
{
    protected $airportRepository;
    protected $routeRepository;
    protected $aircraftRepository;

    // This function runs when the controller is created)
    public function __construct(AirportRepository $airportRepository, RouteRepository $routeRepository, AircraftRepository $aircraftRepository)
    {
        $this->airportRepository = $airportRepository; // Store the airport tool
        $this->routeRepository = $routeRepository; // Store the route tool
        $this->aircraftRepository = $aircraftRepository; // Store the aircraft tool
    }

    // This function shows the main page with all airline data
    public function index()
    {
        $airports = $this->airportRepository->getAll(); // Get all airports
        $aircraft = $this->aircraftRepository->getAll(); // Get all aircraft
        $routes = $this->routeRepository->getAll(); // Get all routes

        // Show the web page with all the data
        return view('airline_operations_design', compact('airports', 'aircraft', 'routes'));
    }

    // This function sends data as JSON (for APIs or JavaScript)
    public function retrieveData()
    {
        $airports = $this->airportRepository->getAll(); // Get all airports
        $aircraft = $this->aircraftRepository->getAll(); // Get all aircraft
        $routes = $this->routeRepository->getAll(); // Get all routes

        // Send the data back as a structured response
        return response()->json([
            'airports' => $airports,
            'aircraft' => $aircraft,
            'routes' => $routes,
        ]);
    }

    // This function creates a new flight route
    public function createRoute(Request $request)
    {
        \Log::debug('CreateRoute Request Data:', $request->all()); 

        // Check that the data sent is correct and complete
        $data = $request->validate([
            'route_id' => 'required|string|unique:routes', // Must have a unique route ID
            'aircraft_registration' => [
                'required', // Must be provided
                'string', // Must be text
                function ($attribute, $value, $fail) {
                    // Check if the aircraft exists (not case-sensitive)
                    $exists = \DB::table('aircraft')
                        ->whereRaw('LOWER(registration_number) = LOWER(?)', [$value])
                        ->exists();
                    if (!$exists) {
                        $fail('The selected aircraft registration is invalid.'); // Error if not found
                    }
                },
            ],
            // Removed estimated_flight_time validation
            'status' => 'required|string|in:active,inactive,cancelled', // Must be one of these options
            'weather_condition' => 'nullable|string', // Optional weather info
            'has_delay' => 'boolean', // True/false for delay
            // Removed delay_time_start validation
            // Removed delay_time_end validation
            'delay_reason' => 'nullable|string', // Optional reason for delay
        ]);

        $route = $this->routeRepository->create($data); // Create the new route

        // Send back the new route data with success code
        return response()->json($route, 201);
    }

    // This function updates an existing route
    public function updateRoute(Request $request, $id)
    {
        // Validate the data
        $data = $request->validate([
            'route_id' => 'required|string|unique:routes,route_id,' . $id, // Unique except for current route
            'aircraft_registration' => [
                'required',
                'string',
                function ($attribute, $value, $fail) {
                    // Check aircraft exists
                    $exists = \DB::table('aircraft')
                        ->whereRaw('LOWER(registration_number) = LOWER(?)', [$value])
                        ->exists();
                    if (!$exists) {
                        $fail('The selected aircraft registration is invalid.');
                    }
                },
            ],
            // Removed estimated_flight_time validation
            'status' => 'required|string|in:active,inactive,cancelled',
            'weather_condition' => 'nullable|string',
            'has_delay' => 'boolean',
            // Removed delay_time_start validation
            // Removed delay_time_end validation
            'delay_reason' => 'nullable|string',
        ]);

        $updated = $this->routeRepository->update($id, $data); // Try to update the route

        if ($updated) {
            return response()->json(['message' => 'Route updated successfully']); // Success message
        }

        return response()->json(['message' => 'Route not found'], 404); // Error if route doesn't exist
    }

    // This function checks if data is current
    public function ensureUpToDate()
    {
        return response()->json(['message' => 'Data is up to date']);
    }

    // This function optimizes routes and assigns aircraft(placeholder)
    public function optimizeAndAssign(Request $request)
    {
        return response()->json(['message' => 'Optimization completed']);
    }

    // This function saves a flight schedule
    public function storeSchedule(Request $request)
    {
        return response()->json(['message' => 'Schedule stored']);
    }

    // This function updates flight status
    public function updateStatus(Request $request, $flightNumber)
    {
        return response()->json(['message' => 'Status updated for flight ' . $flightNumber]);
    }
}

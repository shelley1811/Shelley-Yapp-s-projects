<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;

class WhatsAppWebhookController extends Controller
{
    public function verify(Request $r)
    {
        $token = env('WHATSAPP_VERIFY_TOKEN', 'my-verify-token');
        if ($r->get('hub_mode') === 'subscribe' && $r->get('hub_verify_token') === $token) {
            return response($r->get('hub_challenge'), 200);
        }
        return response('Error, wrong token', 403);
    }

    public function receive(Request $r)
    {
        Log::info('WA webhook', $r->all());
        return response('OK', 200);
    }
}

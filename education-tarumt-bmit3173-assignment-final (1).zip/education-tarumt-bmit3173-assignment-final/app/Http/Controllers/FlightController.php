<?php

namespace App\Http\Controllers;

use App\Models\Flight;
use Illuminate\Http\Request;

class FlightController extends Controller
{
    public function index(Request $request)
    {
        $q = Flight::query();

        if ($o = $request->query('origin'))      $q->where('origin', $o);
        if ($d = $request->query('destination')) $q->where('destination', $d);
        if ($dt = $request->query('date'))       $q->whereDate('flight_date', $dt);

        return $q->orderBy('flight_date')->orderBy('departure_time')
                 ->get(['id','flight_no','origin','destination','flight_date',
                        'departure_time','arrival_time','duration_minutes',
                        'base_fare_myr','seats_available']);
    }
}

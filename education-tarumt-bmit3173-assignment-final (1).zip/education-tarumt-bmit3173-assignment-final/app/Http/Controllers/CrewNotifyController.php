<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use App\Services\WhatsAppService;
use App\Models\CrewAssignment;
use Carbon\Carbon;
use Throwable;

class CrewNotifyController extends Controller
{
    public function notify(Request $req, WhatsAppService $wa)
    {
        $data = $req->validate([
            'crewPhone' => ['required','string'],
            'flightNo'  => ['required','string'],
            'depTime'   => ['required','string'],
            'role'      => ['required','string'],
        ]);

        $msg = "Assignment\nFlight: {$data['flightNo']}\nReport: {$data['depTime']}\nRole: {$data['role']}";

        $recordId = null;
        try {
            if (class_exists(\App\Models\CrewAssignment::class)) {
                $dep = $this->safeParseCarbon($data['depTime']);
                $record = \App\Models\CrewAssignment::create([
                    'crew_phone' => $data['crewPhone'],
                    'flight_no'  => $data['flightNo'],
                    'dep_time'   => $dep ?? $data['depTime'],
                    'role'       => $data['role'],
                    'status'     => 'queued',
                    'channel'    => 'whatsapp',
                ]);
                $recordId = $record->id ?? null;
            }
        } catch (Throwable $e) {
            Log::warning('crew-notify.db.insert.failed', [
                'to' => $data['crewPhone'],
                'err'=> $e->getMessage(),
            ]);
        }

        $res = ['ok'=>false];
        try {
            $res = $wa->sendText($data['crewPhone'], $msg);
        } catch (Throwable $e) {
            Log::error('crew-notify.send.exception', [
                'to'  => $data['crewPhone'],
                'err' => $e->getMessage(),
            ]);
            $res = ['ok'=>false, 'error'=>'exception', 'message'=>$e->getMessage()];
        }

        try {
            if (isset($record) && $record) {
                $ok = !empty($res['ok']);
                $record->update([
                    'status'            => $ok ? 'sent' : 'failed',
                    'sent_at'           => $ok ? now() : null,
                    'vendor_message_id' => $res['message_id'] ?? null,
                    'vendor_payload'    => $res ?? null,
                ]);
            }
        } catch (Throwable $e) {
            Log::warning('crew-notify.db.update.failed', [
                'id'  => $recordId,
                'err' => $e->getMessage(),
            ]);
        }

        return response()->json([
            'ok'     => !empty($res['ok']),
            'id'     => $recordId,
            'status' => !empty($res['ok']) ? 'sent' : 'failed',
            'vendor' => $res,
        ], !empty($res['ok']) ? 200 : 500);
    }

    public function bulkNotify(Request $req, WhatsAppService $wa)
    {
        $data = $req->validate([
            'assignments'             => ['required','array','min:1'],
            'assignments.*.crewPhone' => ['required','string'],
            'assignments.*.flightNo'  => ['required','string'],
            'assignments.*.depTime'   => ['required','string'],
            'assignments.*.role'      => ['required','string'],
            'dry'                     => ['sometimes','boolean'],
        ]);

        $dry = (bool)($data['dry'] ?? false);
        $results = [];

        foreach ($data['assignments'] as $i => $row) {
            $msg = "Assignment\nFlight: {$row['flightNo']}\nReport: {$row['depTime']}\nRole: {$row['role']}";

            $recordId = null;
            try {
                if (class_exists(\App\Models\CrewAssignment::class)) {
                    $dep = $this->safeParseCarbon($row['depTime']);
                    $record = \App\Models\CrewAssignment::create([
                        'crew_phone' => $row['crewPhone'],
                        'flight_no'  => $row['flightNo'],
                        'dep_time'   => $dep ?? $row['depTime'],
                        'role'       => $row['role'],
                        'status'     => 'queued',
                        'channel'    => 'whatsapp',
                    ]);
                    $recordId = $record->id ?? null;
                }
            } catch (Throwable $e) {
                Log::warning('crew-notify.bulk.db.insert.failed', [
                    'i'   => $i,
                    'to'  => $row['crewPhone'],
                    'err' => $e->getMessage(),
                ]);
            }

            $res = ['ok'=>false];
            try {
                $res = $dry ? ['ok'=>true, 'dry'=>true] : $wa->sendText($row['crewPhone'], $msg);
            } catch (Throwable $e) {
                Log::error('crew-notify.bulk.send.exception', [
                    'i'   => $i,
                    'to'  => $row['crewPhone'],
                    'err' => $e->getMessage(),
                ]);
                $res = ['ok'=>false, 'error'=>'exception', 'message'=>$e->getMessage()];
            }

            try {
                if (isset($record) && $record) {
                    $ok = !empty($res['ok']);
                    $record->update([
                        'status'            => $ok ? 'sent' : 'failed',
                        'sent_at'           => $ok ? now() : null,
                        'vendor_message_id' => $res['message_id'] ?? null,
                        'vendor_payload'    => $res ?? null,
                    ]);
                }
            } catch (Throwable $e) {
                Log::warning('crew-notify.bulk.db.update.failed', [
                    'i'   => $i,
                    'id'  => $recordId,
                    'err' => $e->getMessage(),
                ]);
            }

            $results[] = [
                'index'  => $i,
                'id'     => $recordId,
                'to'     => $row['crewPhone'],
                'ok'     => !empty($res['ok']),
                'status' => !empty($res['ok']) ? 'sent' : 'failed',
            ] + $res;
        }

        $allOk = collect($results)->every(fn ($r) => (bool)($r['ok'] ?? false));

        return response()->json([
            'ok'      => $allOk,
            'results' => $results,
        ], $allOk ? 200 : 207);
    }

    private function safeParseCarbon(string $value): ?Carbon
    {
        try {
            return Carbon::parse($value);
        } catch (\Throwable $e) {
            Log::warning('crew-notify.depTime.parse.failed', [
                'raw' => $value,
                'err' => $e->getMessage(),
            ]);
            return null;
        }
    }
}
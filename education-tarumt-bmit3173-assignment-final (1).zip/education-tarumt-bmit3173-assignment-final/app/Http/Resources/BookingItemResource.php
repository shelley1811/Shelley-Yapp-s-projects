<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class BookingItemResource extends JsonResource
{
    public function toArray($request)
    {
        return [
            'id'               => $this->id,
            'passenger_name'   => $this->passenger_name,
            'seat_no'          => $this->seat_no,
            'fare_class'       => $this->fare_class,
            'quantity'         => $this->quantity,
            'unit_price_myr'   => $this->unit_price_myr,
            'tax_myr'          => $this->tax_myr,
            'line_total_myr'   => $this->line_total_myr,
            'flight' => [
                'id'              => $this->flight->id,
                'flight_no'       => $this->flight->flight_no,
                'origin'          => $this->flight->origin,
                'destination'     => $this->flight->destination,
                'flight_date'     => $this->flight->flight_date, // YYYY-MM-DD
                'departure_time'  => $this->flight->departure_time,
                'arrival_time'    => $this->flight->arrival_time,
                'duration_minutes'=> $this->flight->duration_minutes,
            ],
        ];
    }
}

<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class CrewAssignmentResource extends JsonResource
{
    public function toArray($request)
    {
        $tz = 'Asia/Kuala_Lumpur'; 
        return [
            'id'                => $this->id,
            'crew_id'           => $this->crew_id,
            'crew_phone'        => $this->crew_phone,
            'flight_no'         => $this->flight_no,
            'dep_time_utc'      => optional($this->dep_time)->utc()?->toIso8601String(),
            'dep_time_local'    => optional($this->dep_time)->timezone($tz)?->format('Y-m-d H:i'),
            'role'              => $this->role,
            'status'            => $this->status,
            'sent_at'           => optional($this->sent_at)->toIso8601String(),
            'vendor_message_id' => $this->vendor_message_id,
            'vendor_payload'    => $this->vendor_payload,
            'created_at'        => optional($this->created_at)->toIso8601String(),
            'updated_at'        => optional($this->updated_at)->toIso8601String(),
        ];
    }
}

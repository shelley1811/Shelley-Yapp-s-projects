<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class BookingResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray($request)
    {
        return [
            'id'              => $this->id,
            'ref'             => $this->booking_ref,
            'status'          => $this->status,
            'expires_at'      => optional($this->expires_at)->toIso8601String(),
            'grand_total_myr' => $this->grand_total_myr,
            'paid_total_myr'  => $this->paid_total_myr,
            'balance_myr'     => $this->balance_myr,
            'contact' => [
                'name'  => $this->contact_name,
                'email' => $this->contact_email,
                'phone' => $this->contact_phone,
            ],
            'items' => BookingItemResource::collection($this->whenLoaded('items')),
        ];
    }
}

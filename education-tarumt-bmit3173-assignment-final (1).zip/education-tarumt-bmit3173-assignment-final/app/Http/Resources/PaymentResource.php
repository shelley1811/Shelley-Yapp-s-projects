<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class PaymentResource extends JsonResource
{
    public function toArray($request)
    {
        $booking = $this->whenLoaded('booking');

        return [
            'id'              => $this->id,
            'status'          => $this->status,
            'amount_myr'      => $this->amount_myr,
            'method'          => $this->method,
            'provider'        => $this->provider,
            'transaction_ref' => $this->transaction_ref,
            'paid_at'         => optional($this->paid_at)->toIso8601String(),
            'booking'         => $booking ? [
                'id'               => $booking->id,
                'ref'              => $booking->booking_ref,
                'status'           => $booking->status,
                'grand_total_myr'  => $booking->grand_total_myr,
                'paid_total_myr'   => $booking->paid_total_myr,
                'balance_myr'      => $booking->balance_myr,
            ] : null,
        ];
    }
}

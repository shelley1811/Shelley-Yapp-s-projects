<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;
use Carbon\Carbon;
use App\Models\CrewAssignment;

class UpdateCrewAssignmentRequest extends FormRequest
{
    public function authorize(): bool { return true; }

    public function rules(): array
    {
        return [
            'crewPhone' => ['bail','required','string','max:20','regex:/^\+?\d{6,15}$/'],
            'flightNo'  => ['bail','required','string','max:20','regex:/^[A-Z]{1,3}\d{1,4}[A-Z]?$/i'],
            'depTime'   => ['bail','required','date_format:Y-m-d H:i:s','after:now'],
            'role'      => ['bail','required', Rule::in(['FA','CPT','FO','PURSER','SO'])],
        ];
    }

    protected function prepareForValidation(): void
    {
        $tz = config('app.timezone', 'UTC');

        $phone = (string) $this->input('crewPhone', '');
        $phone = preg_replace('/(?!^\+)\D+/', '', $phone);

        $flightNo = strtoupper((string) $this->input('flightNo', ''));
        $role     = strtoupper((string) $this->input('role', ''));

        $depIn = (string) $this->input('depTime', '');
        $dep   = $depIn;

        if ($depIn !== '') {
            try {
                if (preg_match('/(Z|[+\-]\d{2}:\d{2})$/', $depIn)) {
                    $dt = Carbon::parse($depIn)->setTimezone($tz);
                } else {
                    $candidate = str_replace('T', ' ', $depIn);
                    $dt = Carbon::createFromFormat('Y-m-d H:i', $candidate, $tz)
                       ?: Carbon::createFromFormat('Y-m-d H:i:s', $candidate, $tz);
                }
                if ($dt) {
                    $dep = $dt->format('Y-m-d H:i:s');
                }
            } catch (\Throwable $e) {

            }
        }

        $this->merge([
            'crewPhone' => $phone,
            'flightNo'  => $flightNo,
            'role'      => $role,
            'depTime'   => $dep,
        ]);
    }

    public function withValidator($validator): void
    {
        $validator->after(function ($v) {
            /** @var \App\Models\CrewAssignment|null $assignment */
            $assignment = $this->route('assignment');

            $exists = CrewAssignment::query()
                ->where('crew_phone', $this->input('crewPhone'))
                ->where('dep_time',   $this->input('depTime'))
                ->when($assignment, fn ($q) => $q->where('id', '<>', $assignment->id))
                ->exists();

            if ($exists) {
                $v->errors()->add('depTime', 'Duplicate: this crew is already assigned at the same time.');
            }
        });
    }

    public function attributes(): array
    {
        return [
            'crewPhone' => 'crew phone',
            'flightNo'  => 'flight number',
            'depTime'   => 'departure time',
            'role'      => 'role',
        ];
    }
}

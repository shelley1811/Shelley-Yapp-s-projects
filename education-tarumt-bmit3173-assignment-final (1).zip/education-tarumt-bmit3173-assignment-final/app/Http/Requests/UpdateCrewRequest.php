<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class UpdateCrewRequest extends FormRequest
{
    public function authorize(): bool { return true; }

    public function rules(): array
    {
        return [
            'name'      => ['nullable','string','max:100'],
            'phone' => ['sometimes','string','max:30','regex:/^\d{6,15}$/', Rule::unique('crews','phone')
        ->ignore($this->route('crew')?->id)
        ->whereNull('deleted_at'),],
            'role'      => ['nullable','string','max:20'],
            'base'      => ['nullable','string','max:10'],
            'email'     => ['nullable','email','max:100'],
            'is_active' => ['boolean'],
            'notes'     => ['nullable','string'],
        ];
    }
}

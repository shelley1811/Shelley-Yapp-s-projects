<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class StoreBookingRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return [
            'contact_name'  => ['required','string','max:100'],
            'contact_email' => ['required','email'],
            'contact_phone' => ['nullable','string','max:30'],
            'items'         => ['required','array','min:1'],
            'items.*.flight_id'       => ['required','integer','exists:flights,id'],
            'items.*.passenger_name'  => ['required','string','max:100'],
            'items.*.quantity'        => ['nullable','integer','min:1'],
        ];
    }
}

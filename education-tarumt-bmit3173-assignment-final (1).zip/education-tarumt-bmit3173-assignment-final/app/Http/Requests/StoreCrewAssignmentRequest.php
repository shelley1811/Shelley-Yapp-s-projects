<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;
use Carbon\Carbon;

class StoreCrewAssignmentRequest extends FormRequest
{
    public function authorize(): bool { return true; }

    public function rules(): array
    {
        return [
            'crewPhone' => [
                'bail','required','string','max:20','regex:/^\+?\d{6,15}$/',
                Rule::unique('crew_assignments', 'crew_phone')
                    ->where(function ($q) {
                        $q->where('dep_time', $this->input('depTime'));
                    }),
            ],
            'flightNo'  => ['bail','required','string','max:20','regex:/^[A-Z]{1,3}\d{1,4}[A-Z]?$/i'],
            'depTime'   => ['bail','required','date_format:Y-m-d H:i:s', 'after:now'],
            'role'      => ['bail','required', Rule::in(['FA','CPT','FO','PURSER','SO'])],
        ];
    }

    protected function prepareForValidation(): void
    {
        $tz = config('app.timezone', 'UTC');

        $phone = (string) $this->input('crewPhone', '');
        $phone = preg_replace('/(?!^\+)\D+/', '', $phone);

        $flightNo = strtoupper((string) $this->input('flightNo', ''));
        $role     = strtoupper((string) $this->input('role', ''));

        $depIn = (string) $this->input('depTime', '');
        $dep   = $depIn;

        if ($depIn !== '') {
            try {
                if (preg_match('/(Z|[+\-]\d{2}:\d{2})$/', $depIn)) {
                    $dt = Carbon::parse($depIn)->setTimezone($tz);
                } else {
                    $candidate = str_replace('T', ' ', $depIn);
                    $dt = Carbon::createFromFormat('Y-m-d H:i', $candidate, $tz)
                       ?: Carbon::createFromFormat('Y-m-d H:i:s', $candidate, $tz);
                }
                if ($dt) {
                    $dep = $dt->format('Y-m-d H:i:s');
                }
            } catch (\Throwable $e) {

            }
        }

        $this->merge([
            'crewPhone' => $phone,
            'flightNo'  => $flightNo,
            'role'      => $role,
            'depTime'   => $dep,
        ]);
    }

    public function attributes(): array
    {
        return [
            'crewPhone' => 'crew phone',
            'flightNo'  => 'flight number',
            'depTime'   => 'departure time',
            'role'      => 'role',
        ];
    }

    public function messages(): array
    {
        return [
            'crewPhone.regex'     => 'crewPhone must be digits (6–15), optionally starting with +.',
            'crewPhone.unique'    => 'This crew is already assigned at that time.',
            'flightNo.regex'      => 'flightNo looks invalid (e.g. AK123 or AK12A).',
            'depTime.date_format' => 'depTime must be like 2025-09-10 14:30:00 (datetime-local is OK).',
            'depTime.after'       => 'depTime must be in the future.',
        ];
    }
}

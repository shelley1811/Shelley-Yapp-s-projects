<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class StoreCrewRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true; 
    }

    public function rules(): array
    {
        return [
            'name'  => ['required','string','max:100'],
            'phone' => [
            'required','string','max:30', Rule::unique('crews','phone')->whereNull('deleted_at'),],
            'role'  => ['required','in:FA,CPT,FO,PURSER,SO'], 
            'base'  => ['nullable','string','max:10'],
        ];
    }

    protected function prepareForValidation(): void
    {
    if ($this->has('phone')) {
        $phone = (string) $this->input('phone', '');
        $phone = preg_replace('/\D+/', '', $phone);   
        $this->merge(['phone' => $phone]);
    }
}
}

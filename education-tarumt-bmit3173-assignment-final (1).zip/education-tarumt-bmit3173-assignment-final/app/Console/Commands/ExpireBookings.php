<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;
use App\Models\{Booking, BookingItem, Flight};

class ExpireBookings extends Command
{
    protected $signature = 'booking:expire';
    protected $description = 'Expire overdue PENDING bookings and release seats';

    public function handle(): int
    {
        $now = now();

        // find pending & overdue
        $overdue = Booking::where('status', 'PENDING')
            ->whereNotNull('expires_at')
            ->where('expires_at', '<=', $now)
            ->with('items')
            ->get();

        foreach ($overdue as $booking) {
            DB::transaction(function () use ($booking) {
                // release seats per flight
                $byFlight = $booking->items->groupBy('flight_id')
                    ->map(fn($rows) => $rows->sum('quantity'));

                $flights = Flight::whereIn('id', $byFlight->keys())->lockForUpdate()->get()->keyBy('id');
                foreach ($byFlight as $flightId => $qty) {
                    if (isset($flights[$flightId])) {
                        $flights[$flightId]->increment('seats_available', $qty);
                    }
                }
                $booking->update(['status' => 'EXPIRED']);
            });
        }

        $this->info("Expired {$overdue->count()} bookings.");
        return self::SUCCESS;
    }
}

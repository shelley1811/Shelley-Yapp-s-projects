<?php

use App\Http\Controllers\FlightScheduleController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Flight Schedule Module Routes
|--------------------------------------------------------------------------
| These routes are loaded by the RouteServiceProvider.
|--------------------------------------------------------------------------
*/

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});

Route::prefix('flight-schedules')->middleware('api')->group(function () {
    // Basic CRUD
    Route::get('/', [FlightScheduleController::class, 'index']);                // GET all
    Route::get('/{routeId}', [FlightScheduleController::class, 'show']);        // GET by route_id
    Route::post('/', [FlightScheduleController::class, 'store']);               // POST create
    Route::put('/{routeId}', [FlightScheduleController::class, 'update']);      // PUT update
    Route::delete('/{routeId}', [FlightScheduleController::class, 'destroy']);  // DELETE

    // Extra filters
    Route::get('/filter', [FlightScheduleController::class, 'filter']);         // GET with filters
    Route::get('/stats/daily', [FlightScheduleController::class, 'getDailyStats']); // Daily schedule stats
    Route::get('/stats/aircraft', [FlightScheduleController::class, 'getAircraftUtilization']); // NEW: aircraft usage stats
});

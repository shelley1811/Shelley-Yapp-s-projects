<?php
/**
 * Airline Operations Web Routes
 * Created by Daniel Aidan Edmund
 *
 * This file defines the web routes for the airline operations section of the SkyReserve application.
 */

use Illuminate\Support\Facades\Route; 

use App\Http\Controllers\AirlinesOperationsController;

// Define a route for the airline operations page
Route::get('/airline-operations', [AirlinesOperationsController::class, 'index']);

<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

use App\Http\Controllers\PaymentController;
use App\Http\Controllers\BookingController;
use App\Http\Controllers\FlightController;

use App\Http\Controllers\CrewNotifyController;
use App\Http\Controllers\CrewAssignmentController;
use App\Http\Controllers\CrewController;
use App\Http\Controllers\WhatsAppWebhookController;

use App\Http\Controllers\FlightScheduleController;


Route::get('/user', function (Request $request) {
    return $request->user();
})->middleware('auth:sanctum');

Route::get('/webhook/whatsapp', [WhatsAppWebhookController::class, 'verify']);
Route::post('/webhook/whatsapp', [WhatsAppWebhookController::class, 'receive']);
Route::patch('/crew-assignments/{assignment}', [CrewAssignmentController::class, 'update']);
Route::delete('/crew-assignments/{assignment}', [CrewAssignmentController::class, 'destroy']);
Route::post('/notify/crew-assignment', [CrewNotifyController::class, 'notify']);
Route::post('/notify/crew-assignment/bulk', [CrewNotifyController::class, 'bulkNotify']);
Route::get('/crew-assignments', [CrewAssignmentController::class, 'index']);
Route::post('/crew-assignments', [CrewAssignmentController::class, 'store']);      
Route::post('/crew-assignments/{assignment}/resend', [CrewAssignmentController::class, 'resend']);
Route::apiResource('crews', CrewController::class)->only(['index','store','show','update','destroy']);
Route::post('crews/{id}/restore', [CrewController::class, 'restore']);
Route::get('crews/{crew}/assignments', [CrewController::class, 'assignments']);
Route::patch('/crew-assignments/{assignment}', [CrewAssignmentController::class, 'update']);

Route::apiResource('bookings', BookingController::class)->only(['store','show']);
Route::post('payments/{booking}', [PaymentController::class, 'store']);
Route::get('flights', [FlightController::class, 'index']);


// Basic CRUD
    Route::get('/', [FlightScheduleController::class, 'index']);                // GET all
    Route::get('/{routeId}', [FlightScheduleController::class, 'show']);        // GET by route_id
    Route::post('/', [FlightScheduleController::class, 'store']);               // POST create
    Route::put('/{routeId}', [FlightScheduleController::class, 'update']);      // PUT update
    Route::delete('/{routeId}', [FlightScheduleController::class, 'destroy']);  // DELETE

    // Extra filters
    Route::get('/filter', [FlightScheduleController::class, 'filter']);         // GET with filters
    Route::get('/stats/daily', [FlightScheduleController::class, 'getDailyStats']); // Daily schedule stats
    Route::get('/stats/aircraft', [FlightScheduleController::class, 'getAircraftUtilization']); // NEW: aircraft usage stats
<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\FlightScheduleController;

Route::get('/flight-schedule', function () {
    return view('flight_schedule_design'); // make sure resources/views/flight_schedule.blade.php exist
});


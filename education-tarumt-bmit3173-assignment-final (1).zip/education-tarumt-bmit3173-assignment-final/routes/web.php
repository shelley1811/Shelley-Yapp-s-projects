<?php

use Illuminate\Support\Facades\Route;
use Inertia\Inertia;
use App\Http\Controllers\WhatsAppWebhookController;
use App\Http\Controllers\FlightScheduleController;

Route::get('/crew-management', fn () => Inertia::render('CrewManagement'))
    ->name('crew.management');
Route::redirect('/', '/crew-management');
Route::get('/webhook/whatsapp', [WhatsAppWebhookController::class, 'verify']);
Route::post('/webhook/whatsapp', [WhatsAppWebhookController::class, 'receive']);

Route::get('/', function () {
    return Inertia::render('Welcome');
})->name('home');

Route::get('dashboard', function () {
    return Inertia::render('Dashboard');
})->middleware(['auth', 'verified'])->name('dashboard');

Route::get('/booking', function () {
    return Inertia::render('Booking');
})->middleware(['auth', 'verified'])->name('booking');

Route::get('/booking-history', function () {
    return Inertia::render('BookingHistory');
})->middleware(['auth', 'verified'])->name('booking-history');

Route::get('/flight-schedule', function () {
    return view('flight_schedule_design'); // make sure resources/views/flight_schedule.blade.php exist
});

require __DIR__.'/settings.php';
require __DIR__.'/auth.php';
require __DIR__ . '/AirlineOperationsWeb.php';
require __DIR__ . '/AirlineOperationAPI.php';
require __DIR__.'/FlightScheduleWeb.php';
require __DIR__.'/FlightScheduleAPI.php';






<?php
/**
 * Airline Operations API Routes
 * Created by Daniel Aidan Edmund
 *
 * This file defines the API routes for the airline operations section of the SkyReserve application.
 */

use Illuminate\Http\Request; 
use Illuminate\Support\Facades\Route; 
use App\Http\Controllers\AirlinesOperationsController; 

/*
|--------------------------------------------------------------------------
| API Routes - These routes are loaded by the RouteServiceProvider.
|--------------------------------------------------------------------------
*/

// Authentication route - Get information about the currently logged-in user
Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user(); // Return the authenticated user's information
});

// Airlines Operations Module routes
Route::middleware('web')->group(function () {
    // Get data for airline operations (aircraft, routes, airports, etc.)
    Route::get('/airlines/retrieve-data', [AirlinesOperationsController::class, 'retrieveData']);

    // Create a new flight route
    Route::post('/airlines/create-route', [AirlinesOperationsController::class, 'createRoute']);

    // Update an existing route (the {id} will be replaced with the actual route ID)
    Route::put('/airlines/update-route/{id}', [AirlinesOperationsController::class, 'updateRoute']);

    // Ensure all data is up to date (refresh from database)
    Route::get('/airlines/ensure-up-to-date', [AirlinesOperationsController::class, 'ensureUpToDate']);

    // Optimize and assign aircraft to routes automatically
    Route::post('/airlines/optimize-assign', [AirlinesOperationsController::class, 'optimizeAndAssign']);

    // Store a flight schedule
    Route::post('/airlines/store-schedule', [AirlinesOperationsController::class, 'storeSchedule']);

    // Update the status of a flight (the {flightNumber} will be replaced with the actual flight number)
    Route::put('/airlines/update-status/{flightNumber}', [AirlinesOperationsController::class, 'updateStatus']);
});

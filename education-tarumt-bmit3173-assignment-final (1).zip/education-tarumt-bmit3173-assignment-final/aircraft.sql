-- Aircraft table definition
-- Created by Daniel Aidan Edmund
--
-- This SQL file creates a table to store information about aircraft in the SkyReserve system.

-- Remove the old aircraft table if it exists (clean slate)
DROP TABLE IF EXISTS aircraft;

-- Create a new aircraft table with all the necessary columns
CREATE TABLE aircraft (
    id INTEGER PRIMARY KEY AUTOINCREMENT, -- Unique number for each aircraft (auto-generated)
    registration_number VARCHAR(255) NOT NULL UNIQUE, -- Aircraft's license plate (must be unique)
    model VARCHAR(255) NOT NULL, -- Aircraft model (like A330-200 or B737-800)
    manufacturer VARCHAR(255) NOT NULL, -- Who built the aircraft (Airbus, Boeing, etc.)
    capacity INT NOT NULL, -- How many passengers it can carry
    range_km INT NOT NULL, -- How far it can fly without refueling (in kilometers)
    airline VARCHAR(255) NOT NULL, -- Which airline owns/operates this aircraft
    base_iata VARCHAR(3) NOT NULL -- 3-letter code of the airport where this aircraft is based
);

-- Sample data - This adds some example aircraft to our table
INSERT OR IGNORE INTO aircraft (registration_number, model, manufacturer, capacity, range_km, airline, base_iata) VALUES
('9M-MAA001', 'A330-200', 'Airbus', 250, 7400, 'Malaysia Airlines', 'LBU'),
('9M-MAA002', 'A330-200', 'Airbus', 250, 7400, 'Malaysia Airlines', 'KCH4'),
('9M-MAA003', 'A330-200', 'Airbus', 250, 7400, 'Malaysia Airlines', 'LMN2'),
('9M-MAA004', 'A330-200', 'Airbus', 250, 7400, 'Malaysia Airlines', 'LMN'),
('9M-MAA005', 'A330-300', 'Airbus', 300, 6400, 'Malaysia Airlines', 'LBU4'),
('9M-MAA006', 'A330-300', 'Airbus', 300, 6400, 'Malaysia Airlines', 'TWU2'),
('9M-MAA007', 'A330-300', 'Airbus', 300, 6400, 'Malaysia Airlines', 'KUA'),
('9M-MAA008', 'A330-300', 'Airbus', 300, 6400, 'Malaysia Airlines', 'SDK2'),
('9M-MAA009', 'A330-900neo', 'Airbus', 300, 7200, 'Malaysia Airlines', 'IPH'),
('9M-MAA010', 'A330-900neo', 'Airbus', 300, 7200, 'Malaysia Airlines', 'SBH3'),
('9M-MAA011', 'A330-900neo', 'Airbus', 300, 7200, 'Malaysia Airlines', 'LDU2'),
('9M-MAA012', 'A330-900neo', 'Airbus', 300, 7200, 'Malaysia Airlines', 'KTE'),
('9M-MAA013', 'A350-900', 'Airbus', 325, 8100, 'Malaysia Airlines', 'SZB'),
('9M-MAA014', 'A350-900', 'Airbus', 325, 8100, 'Malaysia Airlines', 'MKM4'),
('9M-MAA015', 'A350-900', 'Airbus', 325, 8100, 'Malaysia Airlines', 'JHR'),
('9M-MAA016', 'A350-900', 'Airbus', 325, 8100, 'Malaysia Airlines', 'KCH4'),
('9M-MAA017', 'B737-800', 'Boeing', 180, 5400, 'Malaysia Airlines', 'JHR'),
('9M-MAA018', 'B737-800', 'Boeing', 180, 5400, 'Malaysia Airlines', 'SZB'),
('9M-MAA019', 'B737-800', 'Boeing', 180, 5400, 'Malaysia Airlines', 'LBU2'),
('9M-MAA020', 'B737-800', 'Boeing', 180, 5400, 'Malaysia Airlines', 'MYY4'),
('9M-MAA021', 'B737 MAX 8', 'Boeing', 180, 6500, 'Malaysia Airlines', 'SDK3'),
('9M-MAA022', 'B737 MAX 8', 'Boeing', 180, 6500, 'Malaysia Airlines', 'BTU3'),
('9M-MAA023', 'B737 MAX 8', 'Boeing', 180, 6500, 'Malaysia Airlines', 'BKI4'),
('9M-MAA024', 'B737 MAX 8', 'Boeing', 180, 6500, 'Malaysia Airlines', 'MKM'),
('9M-AKA025', 'A320-200', 'Airbus', 180, 6100, 'AirAsia', 'LMN'),
('9M-AKA026', 'A320-200', 'Airbus', 180, 6100, 'AirAsia', 'BKI'),
('9M-AKA027', 'A320-200', 'Airbus', 180, 6100, 'AirAsia', 'KUD'),
('9M-AKA028', 'A320-200', 'Airbus', 180, 6100, 'AirAsia', 'MYY3'),
('9M-AKA029', 'A320neo', 'Airbus', 180, 6300, 'AirAsia', 'KUD'),
('9M-AKA030', 'A320neo', 'Airbus', 180, 6300, 'AirAsia', 'TGG'),
('9M-AKA031', 'A320neo', 'Airbus', 180, 6300, 'AirAsia', 'LBU3'),
('9M-AKA032', 'A320neo', 'Airbus', 180, 6300, 'AirAsia', 'KUA'),
('9M-AKA033', 'A321neo', 'Airbus', 220, 7400, 'AirAsia', 'BKI3'),
('9M-AKA034', 'A321neo', 'Airbus', 220, 7400, 'AirAsia', 'PEN'),
('9M-AKA035', 'A321neo', 'Airbus', 220, 7400, 'AirAsia', 'TGG'),
('9M-AKA036', 'A321neo', 'Airbus', 220, 7400, 'AirAsia', 'LDU'),
('9M-AKA037', 'A321LR', 'Airbus', 220, 7400, 'AirAsia', 'BKI3'),
('9M-AKA038', 'A321LR', 'Airbus', 220, 7400, 'AirAsia', 'KUL2'),
('9M-AKA039', 'A321LR', 'Airbus', 220, 7400, 'AirAsia', 'LMN3'),
('9M-AKA040', 'A321LR', 'Airbus', 220, 7400, 'AirAsia', 'KUA'),
('9M-BKA041', 'A330-300', 'Airbus', 300, 6400, 'Batik Air Malaysia', 'KUD'),
('9M-BKA042', 'A330-300', 'Airbus', 300, 6400, 'Batik Air Malaysia', 'KBA'),
('9M-BKA043', 'A330-300', 'Airbus', 300, 6400, 'Batik Air Malaysia', 'SZB'),
('9M-BKA044', 'A330-300', 'Airbus', 300, 6400, 'Batik Air Malaysia', 'SEP'),
('9M-BKA045', 'B737-800', 'Boeing', 180, 5400, 'Batik Air Malaysia', 'BKI3'),
('9M-BKA046', 'B737-800', 'Boeing', 180, 5400, 'Batik Air Malaysia', 'BTU4'),
('9M-BKA047', 'B737-800', 'Boeing', 180, 5400, 'Batik Air Malaysia', 'MEL'),
('9M-BKA048', 'B737-800', 'Boeing', 180, 5400, 'Batik Air Malaysia', 'TGG'),
('9M-BKA049', 'B737 MAX 8', 'Boeing', 180, 6500, 'Batik Air Malaysia', 'KUA'),
('9M-BKA050', 'B737 MAX 8', 'Boeing', 180, 6500, 'Batik Air Malaysia', 'BKI'),
('9M-BKA051', 'B737 MAX 8', 'Boeing', 180, 6500, 'Batik Air Malaysia', 'KCH4'),
('9M-BKA052', 'B737 MAX 8', 'Boeing', 180, 6500, 'Batik Air Malaysia', 'SBH4'),
('9M-FYA053', 'ATR 72-500', 'ATR', 70, 1500, 'Firefly', 'BTU3'),
('9M-FYA054', 'ATR 72-500', 'ATR', 70, 1500, 'Firefly', 'SEP'),
('9M-FYA055', 'ATR 72-500', 'ATR', 70, 1500, 'Firefly', 'TWU3'),
('9M-FYA056', 'ATR 72-500', 'ATR', 70, 1500, 'Firefly', 'KBA'),
('9M-FYA057', 'B737-800', 'Boeing', 180, 5400, 'Firefly', 'LMN4'),
('9M-FYA058', 'B737-800', 'Boeing', 180, 5400, 'Firefly', 'LMN4'),
('9M-FYA059', 'B737-800', 'Boeing', 180, 5400, 'Firefly', 'LDU'),
('9M-FYA060', 'B737-800', 'Boeing', 180, 5400, 'Firefly', 'GTW'),
('9M-MSA061', 'ATR 72', 'ATR', 70, 1500, 'MASwings', 'MKM'),
('9M-MSA062', 'ATR 72', 'ATR', 70, 1500, 'MASwings', 'SDK'),
('9M-MSA063', 'ATR 72', 'ATR', 70, 1500, 'MASwings', 'MYY2'),
('9M-MSA064', 'ATR 72', 'ATR', 70, 1500, 'MASwings', 'KCH3'),
('9M-MSA065', 'DHC-6 Twin Otter', 'De Havilland', 20, 1000, 'MASwings', 'KCH3'),
('9M-MSA066', 'DHC-6 Twin Otter', 'De Havilland', 20, 1000, 'MASwings', 'LDU'),
('9M-MSA067', 'DHC-6 Twin Otter', 'De Havilland', 20, 1000, 'MASwings', 'TGG'),
('9M-MSA068', 'DHC-6 Twin Otter', 'De Havilland', 20, 1000, 'MASwings', 'MYY4');

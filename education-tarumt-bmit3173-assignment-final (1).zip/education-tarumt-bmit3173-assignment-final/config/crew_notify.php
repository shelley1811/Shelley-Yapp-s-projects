<?php

return [
    'template'     => "Assignment\nFlight: :flight\nReport: :report\nRole: :role",
    'default_role' => '-',
    'log_channel'  => 'crew-notify',
];

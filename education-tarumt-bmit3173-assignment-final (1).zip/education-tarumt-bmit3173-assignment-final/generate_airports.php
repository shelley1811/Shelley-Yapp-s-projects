<?php
/**
 * Name: Daniel Aidan Edmund
 */

echo "-- Airports table definition\n";
echo "DROP TABLE IF EXISTS airports;\n"; 
echo "CREATE TABLE airports (\n"; 
echo "    id INTEGER PRIMARY KEY AUTOINCREMENT,\n";
echo "    iata_code VARCHAR(3) NOT NULL UNIQUE,\n"; 
echo "    name VARCHAR(255) NOT NULL,\n"; 
echo "    city VARCHAR(255) NOT NULL,\n"; 
echo "    country VARCHAR(255) NOT NULL,\n"; 
echo "    latitude DECIMAL(10,7) NOT NULL,\n"; 
echo "    longitude DECIMAL(10,7) NOT NULL\n"; 
echo ");\n\n"; 

echo "-- Sample data\n"; 
echo "INSERT OR IGNORE INTO airports (iata_code, name, city, country, latitude, longitude) VALUES\n"; 


$cities = [
    ['KUL', 'Kuala Lumpur International Airport', 'Kuala Lumpur', 3.1390, 101.6869],
    ['PEN', 'Penang International Airport', 'Penang', 5.2971, 100.2768],
    ['LGK', 'Langkawi International Airport', 'Langkawi', 6.3297, 99.7287],
    ['JHB', 'Senai International Airport', 'Johor Bahru', 1.6413, 103.6696],
    ['KBR', 'Sultan Ismail Petra Airport', 'Kota Bharu', 6.1668, 102.2930],
    ['TGG', 'Sultan Mahmud Airport', 'Kuala Terengganu', 5.3826, 103.1034],
    ['IPH', 'Sultan Azlan Shah Airport', 'Ipoh', 4.5674, 101.0920],
    ['AOR', 'Sultan Abdul Halim Airport', 'Alor Setar', 6.1897, 100.3982],
    ['MKZ', 'Malacca International Airport', 'Malacca', 2.2634, 102.2515],
    ['KUA', 'Sultan Haji Ahmad Shah Airport', 'Kuantan', 3.7754, 103.2090],
    ['SZB', 'Sultan Abdul Aziz Shah Airport', 'Subang', 3.1306, 101.5490],
    ['BTH', 'Tioman Airport', 'Tioman', 2.8185, 104.1600],
    ['TLP', 'Telemung Airport', 'Telemung', 4.0000, 102.0000],
    ['KTE', 'Kerteh Airport', 'Kerteh', 4.5372, 103.4265],
    ['PKU', 'Pekan Airport', 'Pekan', 3.4833, 103.3833],
    ['ZJR', 'Johor Bahru Airport', 'Johor Bahru', 1.6413, 103.6696],
    ['MEL', 'Melaka Airport', 'Melaka', 2.2634, 102.2515],
    ['SEP', 'KLIA2', 'Sepang', 2.7456, 101.7072],
    ['GTW', 'Penang Airport', 'Georgetown', 5.4141, 100.3288],
    ['KUH', 'Langkawi Airport', 'Kuah', 6.3297, 99.7287],
    ['JHR', 'Johor Airport', 'Johor Bahru', 1.6413, 103.6696],
    ['KBA', 'Kota Bharu Airport', 'Kota Bharu', 6.1668, 102.2930],
    ['IPH2', 'Ipoh Airport', 'Ipoh', 4.5674, 101.0920],
    ['KUL2', 'KLIA', 'Kuala Lumpur', 3.1390, 101.6869],
    ['BKI', 'Kota Kinabalu International Airport', 'Kota Kinabalu', 5.9372, 116.0515],
    ['SDK', 'Sandakan Airport', 'Sandakan', 5.9009, 118.0590],
    ['TWU', 'Tawau Airport', 'Tawau', 4.3202, 118.1277],
    ['LDU', 'Lahad Datu Airport', 'Lahad Datu', 5.0320, 118.3240],
    ['KUD', 'Kudat Airport', 'Kudat', 6.9225, 116.8360],
    ['LBU', 'Labuan Airport', 'Labuan', 5.3007, 115.2500],
    ['KCH', 'Kuching International Airport', 'Kuching', 1.4847, 110.3469],
    ['MYY', 'Miri Airport', 'Miri', 4.3220, 113.9868],
    ['SBH', 'Sibu Airport', 'Sibu', 2.2616, 111.9853],
    ['BTU', 'Bintulu Airport', 'Bintulu', 3.1238, 113.0203],
    ['LMN', 'Limbang Airport', 'Limbang', 4.8083, 115.0100],
    ['MKM', 'Mukah Airport', 'Mukah', 2.9064, 112.0800],
    ['BKI2', 'KK Airport', 'Kota Kinabalu', 5.9372, 116.0515],
    ['SDK2', 'Sandakan Airport', 'Sandakan', 5.9009, 118.0590],
    ['TWU2', 'Tawau Airport', 'Tawau', 4.3202, 118.1277],
    ['LDU2', 'Lahad Datu Airport', 'Lahad Datu', 5.0320, 118.3240],
    ['KUD2', 'Kudat Airport', 'Kudat', 6.9225, 116.8360],
    ['LBU2', 'Labuan Airport', 'Labuan', 5.3007, 115.2500],
    ['KCH2', 'Kuching Airport', 'Kuching', 1.4847, 110.3469],
    ['MYY2', 'Miri Airport', 'Miri', 4.3220, 113.9868],
    ['SBH2', 'Sibu Airport', 'Sibu', 2.2616, 111.9853],
    ['BTU2', 'Bintulu Airport', 'Bintulu', 3.1238, 113.0203],
    ['LMN2', 'Limbang Airport', 'Limbang', 4.8083, 115.0100],
    ['MKM2', 'Mukah Airport', 'Mukah', 2.9064, 112.0800],
    ['BKI3', 'Kota Kinabalu', 'Kota Kinabalu', 5.9372, 116.0515],
    ['SDK3', 'Sandakan', 'Sandakan', 5.9009, 118.0590],
    ['TWU3', 'Tawau', 'Tawau', 4.3202, 118.1277],
    ['LDU3', 'Lahad Datu', 'Lahad Datu', 5.0320, 118.3240],
    ['KUD3', 'Kudat', 'Kudat', 6.9225, 116.8360],
    ['LBU3', 'Labuan', 'Labuan', 5.3007, 115.2500],
    ['KCH3', 'Kuching', 'Kuching', 1.4847, 110.3469],
    ['MYY3', 'Miri', 'Miri', 4.3220, 113.9868],
    ['SBH3', 'Sibu', 'Sibu', 2.2616, 111.9853],
    ['BTU3', 'Bintulu', 'Bintulu', 3.1238, 113.0203],
    ['LMN3', 'Limbang', 'Limbang', 4.8083, 115.0100],
    ['MKM3', 'Mukah', 'Mukah', 2.9064, 112.0800],
    ['BKI4', 'KKIA', 'Kota Kinabalu', 5.9372, 116.0515],
    ['SDK4', 'Sandakan Int', 'Sandakan', 5.9009, 118.0590],
    ['TWU4', 'Tawau Int', 'Tawau', 4.3202, 118.1277],
    ['LDU4', 'Lahad Datu Int', 'Lahad Datu', 5.0320, 118.3240],
    ['KUD4', 'Kudat Int', 'Kudat', 6.9225, 116.8360],
    ['LBU4', 'Labuan Int', 'Labuan', 5.3007, 115.2500],
    ['KCH4', 'Kuching Int', 'Kuching', 1.4847, 110.3469],
    ['MYY4', 'Miri Int', 'Miri', 4.3220, 113.9868],
    ['SBH4', 'Sibu Int', 'Sibu', 2.2616, 111.9853],
    ['BTU4', 'Bintulu Int', 'Bintulu', 3.1238, 113.0203],
    ['LMN4', 'Limbang Int', 'Limbang', 4.8083, 115.0100],
    ['MKM4', 'Mukah Int', 'Mukah', 2.9064, 112.0800],
];

foreach ($cities as $index => $city) {
    $code = $city[0]; 
    $name = $city[1]; 
    $cityName = $city[2]; 
    $lat = $city[3]; 
    $lon = $city[4]; 
    echo "('$code', '$name', '$cityName', 'Malaysia', $lat, $lon)";


    if ($index < count($cities) - 1) echo ",\n";
    else echo ";\n";
}

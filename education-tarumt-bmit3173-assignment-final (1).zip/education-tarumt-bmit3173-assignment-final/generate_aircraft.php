<?php
/**
 * Name: Daniel Aidan Edmund
 */

$malaysian_airlines = [
    'Malaysia Airlines' => [
        ['model' => 'A330-200', 'manufacturer' => 'Airbus', 'capacity' => 250, 'range' => 7400],
        ['model' => 'A330-300', 'manufacturer' => 'Airbus', 'capacity' => 300, 'range' => 6400],
        ['model' => 'A330-900neo', 'manufacturer' => 'Airbus', 'capacity' => 300, 'range' => 7200],
        ['model' => 'A350-900', 'manufacturer' => 'Airbus', 'capacity' => 325, 'range' => 8100],
        ['model' => 'B737-800', 'manufacturer' => 'Boeing', 'capacity' => 180, 'range' => 5400],
        ['model' => 'B737 MAX 8', 'manufacturer' => 'Boeing', 'capacity' => 180, 'range' => 6500],
    ],
    'AirAsia' => [
        ['model' => 'A320-200', 'manufacturer' => 'Airbus', 'capacity' => 180, 'range' => 6100],
        ['model' => 'A320neo', 'manufacturer' => 'Airbus', 'capacity' => 180, 'range' => 6300],
        ['model' => 'A321neo', 'manufacturer' => 'Airbus', 'capacity' => 220, 'range' => 7400],
        ['model' => 'A321LR', 'manufacturer' => 'Airbus', 'capacity' => 220, 'range' => 7400],
    ],
    'Batik Air Malaysia' => [
        ['model' => 'A330-300', 'manufacturer' => 'Airbus', 'capacity' => 300, 'range' => 6400],
        ['model' => 'B737-800', 'manufacturer' => 'Boeing', 'capacity' => 180, 'range' => 5400],
        ['model' => 'B737 MAX 8', 'manufacturer' => 'Boeing', 'capacity' => 180, 'range' => 6500],
    ],
    'Firefly' => [
        ['model' => 'ATR 72-500', 'manufacturer' => 'ATR', 'capacity' => 70, 'range' => 1500],
        ['model' => 'B737-800', 'manufacturer' => 'Boeing', 'capacity' => 180, 'range' => 5400],
    ],
    'MASwings' => [
        ['model' => 'ATR 72', 'manufacturer' => 'ATR', 'capacity' => 70, 'range' => 1500],
        ['model' => 'DHC-6 Twin Otter', 'manufacturer' => 'De Havilland', 'capacity' => 20, 'range' => 1000],
    ],
];

$international_airlines = [
    'Singapore Airlines' => [
        ['model' => 'A350-900', 'manufacturer' => 'Airbus', 'capacity' => 325, 'range' => 8100],
        ['model' => 'B777-300ER', 'manufacturer' => 'Boeing', 'capacity' => 350, 'range' => 11100],
        ['model' => 'A380-800', 'manufacturer' => 'Airbus', 'capacity' => 500, 'range' => 8000],
    ],
    'Emirates' => [
        ['model' => 'A380-800', 'manufacturer' => 'Airbus', 'capacity' => 500, 'range' => 8000],
        ['model' => 'B777-300ER', 'manufacturer' => 'Boeing', 'capacity' => 350, 'range' => 11100],
        ['model' => 'A350-900', 'manufacturer' => 'Airbus', 'capacity' => 325, 'range' => 8100],
    ],
    'Qatar Airways' => [
        ['model' => 'A350-900', 'manufacturer' => 'Airbus', 'capacity' => 325, 'range' => 8100],
        ['model' => 'B777-300ER', 'manufacturer' => 'Boeing', 'capacity' => 350, 'range' => 11100],
        ['model' => 'A330-300', 'manufacturer' => 'Airbus', 'capacity' => 300, 'range' => 6400],
    ],
    'Cathay Pacific' => [
        ['model' => 'A350-900', 'manufacturer' => 'Airbus', 'capacity' => 325, 'range' => 8100],
        ['model' => 'B777-300ER', 'manufacturer' => 'Boeing', 'capacity' => 350, 'range' => 11100],
        ['model' => 'A330-300', 'manufacturer' => 'Airbus', 'capacity' => 300, 'range' => 6400],
    ],
    'ANA' => [
        ['model' => 'B777-300ER', 'manufacturer' => 'Boeing', 'capacity' => 350, 'range' => 11100],
        ['model' => 'A350-900', 'manufacturer' => 'Airbus', 'capacity' => 325, 'range' => 8100],
        ['model' => 'B787-9', 'manufacturer' => 'Boeing', 'capacity' => 290, 'range' => 7600],
    ],
    'Japan Airlines' => [
        ['model' => 'B777-300ER', 'manufacturer' => 'Boeing', 'capacity' => 350, 'range' => 11100],
        ['model' => 'A350-900', 'manufacturer' => 'Airbus', 'capacity' => 325, 'range' => 8100],
        ['model' => 'B787-9', 'manufacturer' => 'Boeing', 'capacity' => 290, 'range' => 7600],
    ],
    'Korean Air' => [
        ['model' => 'B777-300ER', 'manufacturer' => 'Boeing', 'capacity' => 350, 'range' => 11100],
        ['model' => 'A350-900', 'manufacturer' => 'Airbus', 'capacity' => 325, 'range' => 8100],
        ['model' => 'B787-9', 'manufacturer' => 'Boeing', 'capacity' => 290, 'range' => 7600],
    ],
    'Thai Airways' => [
        ['model' => 'A350-900', 'manufacturer' => 'Airbus', 'capacity' => 325, 'range' => 8100],
        ['model' => 'B777-300ER', 'manufacturer' => 'Boeing', 'capacity' => 350, 'range' => 11100],
        ['model' => 'A330-300', 'manufacturer' => 'Airbus', 'capacity' => 300, 'range' => 6400],
    ],
    'Garuda Indonesia' => [
        ['model' => 'B777-300ER', 'manufacturer' => 'Boeing', 'capacity' => 350, 'range' => 11100],
        ['model' => 'A350-900', 'manufacturer' => 'Airbus', 'capacity' => 325, 'range' => 8100],
        ['model' => 'B737-800', 'manufacturer' => 'Boeing', 'capacity' => 180, 'range' => 5400],
    ],
    'Vietnam Airlines' => [
        ['model' => 'A350-900', 'manufacturer' => 'Airbus', 'capacity' => 325, 'range' => 8100],
        ['model' => 'B777-300ER', 'manufacturer' => 'Boeing', 'capacity' => 350, 'range' => 11100],
        ['model' => 'A330-300', 'manufacturer' => 'Airbus', 'capacity' => 300, 'range' => 6400],
    ],
];

$prefixes = [
    'Malaysia Airlines' => '9M-MAA',
    'AirAsia' => '9M-AKA',
    'Batik Air Malaysia' => '9M-BKA',
    'Firefly' => '9M-FYA',
    'MASwings' => '9M-MSA',
    'Singapore Airlines' => '9V-SQA',
    'Emirates' => 'A6-EAA',
    'Qatar Airways' => 'A7-BAA',
    'Cathay Pacific' => 'B-HXA',
    'ANA' => 'JA-ANA',
    'Japan Airlines' => 'JA-JAL',
    'Korean Air' => 'HL-KAL',
    'Thai Airways' => 'HS-TGA',
    'Garuda Indonesia' => 'PK-GIA',
    'Vietnam Airlines' => 'VN-VNA',
];

$iata_codes = ['KUL', 'PEN', 'LGK', 'JHB', 'KBR', 'TGG', 'IPH', 'AOR', 'MKZ', 'KUA', 'SZB', 'BTH', 'TLP', 'KTE', 'PKU', 'ZJR', 'MEL', 'SEP', 'GTW', 'KUH', 'JHR', 'KBA', 'IPH2', 'KUL2', 'BKI', 'SDK', 'TWU', 'LDU', 'KUD', 'LBU', 'KCH', 'MYY', 'SBH', 'BTU', 'LMN', 'MKM', 'BKI2', 'SDK2', 'TWU2', 'LDU2', 'KUD2', 'LBU2', 'KCH2', 'MYY2', 'SBH2', 'BTU2', 'LMN2', 'MKM2', 'BKI3', 'SDK3', 'TWU3', 'LDU3', 'KUD3', 'LBU3', 'KCH3', 'MYY3', 'SBH3', 'BTU3', 'LMN3', 'MKM3', 'BKI4', 'SDK4', 'TWU4', 'LDU4', 'KUD4', 'LBU4', 'KCH4', 'MYY4', 'SBH4', 'BTU4', 'LMN4', 'MKM4'];

$counter = 1;
$values = [];

function generateAircraft($airlines, &$counter, &$values, $prefixes, $iata_codes, $max) {
    foreach ($airlines as $airline => $models) {
        foreach ($models as $modelData) {
            for ($i = 0; $i < 4; $i++) {
                if ($counter > $max) return;
                $reg = $prefixes[$airline] . str_pad($counter++, 3, '0', STR_PAD_LEFT);
                $iata = $iata_codes[array_rand($iata_codes)];
                $values[] = "('$reg', '{$modelData['model']}', '{$modelData['manufacturer']}', {$modelData['capacity']}, {$modelData['range']}, '$airline', '$iata')";
            }
        }
    }
}

generateAircraft($malaysian_airlines, $counter, $values, $prefixes, $iata_codes, 100);

echo "-- Aircraft table definition\n";
echo "DROP TABLE IF EXISTS aircraft;\n";
echo "CREATE TABLE aircraft (\n";
echo "    id INTEGER PRIMARY KEY AUTOINCREMENT,\n";
echo "    registration_number VARCHAR(255) NOT NULL UNIQUE,\n";
echo "    model VARCHAR(255) NOT NULL,\n";
echo "    manufacturer VARCHAR(255) NOT NULL,\n";
echo "    capacity INT NOT NULL,\n";
echo "    range_km INT NOT NULL,\n";
echo "    airline VARCHAR(255) NOT NULL,\n";
echo "    base_iata VARCHAR(3) NOT NULL\n";
echo ");\n\n";
echo "-- Sample data\n";
echo "INSERT OR IGNORE INTO aircraft (registration_number, model, manufacturer, capacity, range_km, airline, base_iata) VALUES\n";
echo implode(",\n", $values) . ";\n";

?>

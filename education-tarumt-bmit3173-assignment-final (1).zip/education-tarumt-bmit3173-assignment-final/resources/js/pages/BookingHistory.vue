<script setup lang="ts">
import AppLayout from '@/layouts/AppLayout.vue';
import type { BreadcrumbItem } from '@/types';
import { Head, usePage } from '@inertiajs/vue3';
import { computed, onMounted, ref } from 'vue';

const breadcrumbs: BreadcrumbItem[] = [
    { title: 'Dashboard', href: '/dashboard' },
    { title: 'Booking History', href: '/booking-history' },
];

type BookingDto = {
    id: number;
    ref?: string;
    booking_ref?: string;
    status: 'PENDING' | 'CONFIRMED' | 'CANCELLED' | 'EXPIRED';
    grand_total_myr: number;
    paid_total_myr: number;
    balance_myr: number;
    expires_at: string | null;
    contact?: { name?: string; email?: string };
    contact_email?: string;
};

function fmtMYR(n: number | null | undefined) {
    try {
        return new Intl.NumberFormat('ms-MY', { style: 'currency', currency: 'MYR' }).format(n ?? 0);
    } catch {
        return `MYR ${Number(n ?? 0).toFixed(2)}`;
    }
}
async function apiGet<T = any>(url: string): Promise<T> {
    const r = await fetch(url);
    if (!r.ok) throw new Error(await r.text());
    return await r.json();
}

const page = usePage<{ auth?: { user?: { name?: string; email?: string } } }>();
const currentUserEmail = computed(() => page.props?.auth?.user?.email ?? '');

async function ensureUserFromProfileIfMissing() {
    if (currentUserEmail.value) return;
    try {
        const res = await fetch('/settings/profile', { headers: { 'X-Inertia': 'true', Accept: 'application/json' } });
        if (res.ok) {
            const json = await res.json();
            // @ts-ignore
            const u = json?.props?.auth?.user;
            if (u?.email) {
                // @ts-ignore
                page.props.auth = { user: { name: u.name, email: u.email } };
            }
        }
    } catch {
        /* ignore */
    }
}

const STORAGE_KEY = 'sr_my_bookings';
function getEmail(b: any): string | undefined {
    return b?.contact?.email ?? b?.contact_email;
}
function loadLocalHistory(email: string) {
    try {
        const arr = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
        return (arr as BookingDto[]).filter((b: any) => getEmail(b) === email);
    } catch {
        return [];
    }
}

const myBookings = ref<BookingDto[]>([]);
const myBookingsLoading = ref(false);
const myBookingsNote = ref<string>('');

async function loadMyBookings() {
    const email = currentUserEmail.value;
    if (!email) return;
    myBookingsLoading.value = true;
    myBookingsNote.value = '';
    try {
        const res: any = await apiGet('/api/bookings'); // server index (if available)
        const list: any[] = (res.data ?? res) as any[];
        const filtered = list.filter((b: any) => getEmail(b) === email);
        if (filtered.length) {
            myBookings.value = filtered;
        } else {
            myBookings.value = loadLocalHistory(email);
            myBookingsNote.value = 'Showing local session history (no matching server records found).';
        }
    } catch {
        myBookings.value = loadLocalHistory(email);
        myBookingsNote.value = 'Server list not available. Showing local session history.';
    } finally {
        myBookingsLoading.value = false;
    }
}

onMounted(async () => {
    await ensureUserFromProfileIfMissing();
    await loadMyBookings();
});
</script>

<template>
    <Head title="Booking History" />

    <AppLayout :breadcrumbs="breadcrumbs">
        <div class="flex h-full flex-1 flex-col gap-4 rounded-xl p-4">
            <section class="space-y-4 rounded-xl border border-sidebar-border/70 p-6 dark:border-sidebar-border">
                <div class="flex items-center justify-between">
                    <h1 class="text-lg font-medium">My Bookings</h1>
                    <button @click="loadMyBookings" class="rounded bg-black px-4 py-2 text-white disabled:opacity-50" :disabled="myBookingsLoading">
                        <span v-if="!myBookingsLoading">Refresh</span>
                        <span v-else>Loading…</span>
                    </button>
                </div>

                <p class="text-xs text-gray-500" v-if="myBookingsNote">{{ myBookingsNote }}</p>

                <div v-if="!myBookingsLoading && myBookings.length" class="overflow-x-auto">
                    <table class="min-w-full text-sm">
                        <thead>
                            <tr class="border-b text-left">
                                <th class="py-2 pr-4">Ref</th>
                                <th class="py-2 pr-4">Status</th>
                                <th class="py-2 pr-4">Total</th>
                                <th class="py-2 pr-4">Paid</th>
                                <th class="py-2 pr-4">Balance</th>
                                <th class="py-2 pr-4">Expires</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr v-for="b in myBookings" :key="b.id" class="border-b">
                                <td class="py-2 pr-4 font-mono">{{ b.ref ?? b.booking_ref }}</td>
                                <td class="py-2 pr-4">{{ b.status }}</td>
                                <td class="py-2 pr-4">{{ fmtMYR(b.grand_total_myr) }}</td>
                                <td class="py-2 pr-4">{{ fmtMYR(b.paid_total_myr) }}</td>
                                <td class="py-2 pr-4">{{ fmtMYR(b.balance_myr) }}</td>
                                <td class="py-2 pr-4 text-xs text-gray-500">{{ b.expires_at }}</td>
                            </tr>
                        </tbody>
                    </table>
                </div>

                <div v-if="!myBookingsLoading && !myBookings.length" class="text-sm text-gray-600">
                    No bookings found for {{ currentUserEmail || 'your account' }}.
                </div>
            </section>
        </div>
    </AppLayout>
</template>

<script setup lang="ts">
import axios from 'axios';
import { onMounted, reactive, ref, watch } from 'vue';

type Crew = {
    id: number;
    name: string | null;
    phone: string;
    role: string | null;
    base: string | null;
    email?: string | null;
    is_active?: boolean;
    notes?: string | null;
    created_at?: string;
    updated_at?: string;
};

type Assignment = {
    id: number;
    crew_id?: number | null;
    crew_phone: string;
    flight_no: string;
    dep_time: string;
    role?: string | null;
    status: 'queued' | 'sent' | 'failed';
    sent_at?: string | null;
    vendor_message_id?: string | null;
    vendor_payload?: any;
    created_at?: string;
    updated_at?: string;
};

type Paginate<T> = {
    data: T[];
    current_page: number;
    last_page: number;
    per_page: number;
    total: number;
};

const base = (window as any).APP_BASE || '';
axios.defaults.headers.common['X-Requested-With'] = 'XMLHttpRequest';

const assignMode = ref<'create' | 'edit'>('create');
const editingAssignmentId = ref<number | null>(null);

function toInputLocal(ts?: string | null): string {
    if (!ts) return '';
    const s = ts.includes('T') ? ts : ts.replace(' ', 'T');
    const d = new Date(s);
    if (Number.isNaN(d.getTime())) return '';
    const pad = (n: number) => String(n).padStart(2, '0');
    return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

function apiMessage(e: any, fallback = 'Operation failed') {
    return e?.response?.data?.message || e?.message || fallback;
}

function fmt(ts?: string | null) {
    if (!ts) return '-';

    if (/(Z|[+\-]\d{2}:\d{2})$/.test(ts)) {
        const d = new Date(ts);
        return Number.isNaN(d.getTime()) ? ts : d.toLocaleString();
    }

    return ts.replace('T', ' ');
}

const loading = ref(false);
const crews = ref<Crew[]>([]);
const page = ref(1);
const q = ref('');
const sort = ref('-created_at');
const pager = reactive({ current_page: 1, last_page: 1, total: 0 });
const listErr = ref('');
const CREWS_PER_PAGE = 6;
const ASSIGN_PER_PAGE = 3;

async function fetchCrews() {
    loading.value = true;
    listErr.value = '';
    try {
        const { data } = await axios.get<Paginate<Crew>>(`${base}/api/crews`, {
            params: { q: q.value || undefined, sort: sort.value, page: page.value, per_page: CREWS_PER_PAGE },
        });
        crews.value = data.data;
        pager.current_page = data.current_page;
        pager.last_page = data.last_page;
        pager.total = data.total;
    } catch (e: any) {
        listErr.value = apiMessage(e, 'Load crews failed');
        crews.value = [];
        pager.current_page = 1;
        pager.last_page = 1;
        pager.total = 0;
    } finally {
        loading.value = false;
    }
}

const formMode = ref<'create' | 'edit'>('create');
const showForm = ref(false);
const form = reactive<Partial<Crew>>({
    name: '',
    phone: '',
    role: 'FA',
    base: 'KUL',
    email: '',
    is_active: true,
    notes: '',
});
const editingId = ref<number | null>(null);
const formErr = ref<string>('');
const saving = ref(false);

function openCreate() {
    formMode.value = 'create';
    editingId.value = null;
    Object.assign(form, { name: '', phone: '', role: 'FA', base: 'KUL', email: '', is_active: true, notes: '' });
    formErr.value = '';
    showForm.value = true;
}

function openEdit(row: Crew) {
    formMode.value = 'edit';
    editingId.value = row.id;
    Object.assign(form, row);
    formErr.value = '';
    showForm.value = true;
}

async function saveForm() {
    if (saving.value) return;
    formErr.value = '';
    saving.value = true;
    try {
        if (formMode.value === 'create') {
            const { data } = await axios.post(
                `${base}/api/crews`,
                {
                    name: form.name,
                    phone: String(form.phone || ''),
                    role: form.role,
                    base: (form.base || '').toString().toUpperCase(),
                    email: form.email,
                    is_active: !!form.is_active,
                    notes: form.notes,
                },
                { headers: { Accept: 'application/json' } },
            );
            crews.value.unshift(data);
        } else if (editingId.value) {
            await axios.patch(
                `${base}/api/crews/${editingId.value}`,
                {
                    name: form.name,
                    phone: form.phone,
                    role: form.role,
                    base: form.base?.toString().toUpperCase(),
                    email: form.email,
                    is_active: !!form.is_active,
                    notes: form.notes,
                },
                { headers: { Accept: 'application/json' } },
            );
            await fetchCrews();
        }
        showForm.value = false;
    } catch (e: any) {
        formErr.value = apiMessage(e, 'Save failed');
    } finally {
        saving.value = false;
    }
}

async function removeCrew(row: Crew) {
    if (!confirm(`Delete crew "${row.name ?? row.phone}" ?`)) return;
    try {
        await axios.delete(`${base}/api/crews/${row.id}`);

        if (selectedCrew.value?.id === row.id) {
            selectedCrew.value = null;
            assignments.value = [];
        }
        await fetchCrews();
    } catch (e: any) {
        alert(apiMessage(e, 'Delete failed'));
    }
}

const selectedCrew = ref<Crew | null>(null);
const assignLoading = ref(false);
const assignments = ref<Assignment[]>([]);
const assignPage = ref(1);
const assignStatus = ref<string>(''); // '', 'sent', 'failed', 'queued'
const assignPager = reactive({ current_page: 1, last_page: 1, total: 0 });
const assignListErr = ref('');

async function loadAssignments(row: Crew) {
    if (!selectedCrew.value || selectedCrew.value.id !== row.id) {
        assignPage.value = 1;
    }
    selectedCrew.value = row;

    assignLoading.value = true;
    assignListErr.value = '';
    try {
        const { data } = await axios.get<Paginate<Assignment>>(`${base}/api/crews/${row.id}/assignments`, {
            params: { page: assignPage.value, per_page: ASSIGN_PER_PAGE, status: assignStatus.value || undefined },
        });
        assignments.value = data.data;
        assignPager.current_page = data.current_page;
        assignPager.last_page = data.last_page;
        assignPager.total = data.total;
    } catch (e: any) {
        assignments.value = [];
        assignPager.current_page = 1;
        assignPager.last_page = 1;
        assignPager.total = 0;
        assignListErr.value = apiMessage(e, 'Load assignments failed');
    } finally {
        assignLoading.value = false;
    }
}

async function resend(assignmentId: number) {
    if (!confirm(`Resend message for assignment #${assignmentId}?`)) return;

    try {
        const resp = await axios.post(`${base}/api/crew-assignments/${assignmentId}/resend`, null, {
            headers: { Accept: 'application/json' },
        });

        if (selectedCrew.value) await loadAssignments(selectedCrew.value);
        alert('Resent ✅');
    } catch (e: any) {
        const idx = assignments.value.findIndex((a) => a.id === assignmentId);
        if (idx > -1) {
            assignments.value[idx] = { ...assignments.value[idx], status: 'failed' };
        }
        if (selectedCrew.value) await loadAssignments(selectedCrew.value);
        alert(apiMessage(e, 'Failed to resend'));
    }
}

const showAssignForm = ref(false);
const assignForm = reactive({
    flightNo: '',
    depTime: '',
    role: 'FA',
});
const assignErr = ref('');
const assignSaving = ref(false);
const notifyCrew = ref(true);

function openAssign(row?: Crew) {
    if (row) {
        if (!selectedCrew.value || selectedCrew.value.id !== row.id) assignPage.value = 1;
        selectedCrew.value = row;
    }
    if (!selectedCrew.value) {
        alert('Please select a crew first.');
        return;
    }
    assignMode.value = 'create';
    editingAssignmentId.value = null;
    Object.assign(assignForm, { flightNo: '', depTime: '', role: selectedCrew.value.role ?? 'FA' });
    notifyCrew.value = false;
    assignErr.value = '';
    showAssignForm.value = true;
}

function openAssignEdit(a: Assignment) {
    if (!selectedCrew.value) {
        alert('Please select a crew first.');
        return;
    }
    assignMode.value = 'edit';
    editingAssignmentId.value = a.id;
    Object.assign(assignForm, {
        flightNo: a.flight_no,
        depTime: toInputLocal(a.dep_time),
        role: a.role ?? 'FA',
    });
    notifyCrew.value = true;
    assignErr.value = '';
    showAssignForm.value = true;
}

async function submitAssign() {
    if (assignSaving.value) return;
    assignErr.value = '';

    const crew = selectedCrew.value;
    if (!crew) {
        assignErr.value = 'No crew selected';
        return;
    }
    if (!assignForm.flightNo.trim()) {
        assignErr.value = 'Flight No is required';
        return;
    }
    if (!assignForm.depTime) {
        assignErr.value = 'Dep Time is required';
        return;
    }

    assignSaving.value = true;
    try {
        const payload: any = {
            crewPhone: String(crew.phone),
            flightNo: assignForm.flightNo.trim(),
            depTime: assignForm.depTime,
            role: assignForm.role,
        };
        if (assignMode.value === 'edit') payload.notify = notifyCrew.value;

        const resp =
            assignMode.value === 'create'
                ? await axios.post(`${base}/api/crew-assignments`, payload, { headers: { Accept: 'application/json' } })
                : await axios.patch(`${base}/api/crew-assignments/${editingAssignmentId.value}`, payload, {
                      headers: { Accept: 'application/json' },
                  });

        showAssignForm.value = false;
        await loadAssignments(crew);
        alert(
            assignMode.value === 'create' ? 'Assignment created ✅' : notifyCrew.value ? 'Assignment updated & notified ✅' : 'Assignment updated ✅',
        );
    } catch (e: any) {
        showAssignForm.value = false;
        if (crew) await loadAssignments(crew);
        alert(apiMessage(e, 'Send failed'));
    } finally {
        assignSaving.value = false;
    }
}

async function deleteAssignment(a: Assignment) {
    if (!confirm(`Delete assignment #${a.id}?`)) return;
    try {
        await axios.delete(`${base}/api/crew-assignments/${a.id}`, {
            headers: { Accept: 'application/json' },
        });
        if (selectedCrew.value) await loadAssignments(selectedCrew.value);
    } catch (e: any) {
        alert(apiMessage(e, 'Delete failed'));
    }
}

watch([q, sort], () => {
    page.value = 1;
    fetchCrews();
});
watch([page], fetchCrews);

watch([assignStatus], () => {
    assignPage.value = 1;
    if (selectedCrew.value) loadAssignments(selectedCrew.value);
});
watch([assignPage], () => {
    if (selectedCrew.value) loadAssignments(selectedCrew.value);
});

onMounted(fetchCrews);
</script>

<template>
    <div class="mx-auto max-w-7xl p-6">
        <h1 class="mb-4 text-2xl font-semibold">Crew Management</h1>

        <div class="mb-4 flex flex-wrap items-center gap-3">
            <input v-model="q" type="text" placeholder="Search phone/name/base…" class="w-64 rounded border px-3 py-2" />
            <select v-model="sort" class="rounded border px-3 py-2">
                <option value="-created_at">Newest</option>
                <option value="created_at">Oldest</option>
                <option value="name">Name A-Z</option>
                <option value="-name">Name Z-A</option>
            </select>
            <button @click="openCreate" class="rounded bg-blue-600 px-4 py-2 text-white">+ New Crew</button>
        </div>

        <p v-if="listErr" class="mb-3 text-sm text-red-600">{{ listErr }}</p>

        <div class="grid grid-cols-1 gap-6 lg:grid-cols-2">
            <div class="rounded bg-white p-4 shadow">
                <div class="overflow-x-auto">
                    <table class="min-w-full text-sm">
                        <thead>
                            <tr class="border-b text-left text-gray-500">
                                <th class="py-2">Name</th>
                                <th class="py-2">Phone</th>
                                <th class="py-2">Role</th>
                                <th class="py-2">Base</th>
                                <th class="w-60 py-2">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr v-if="loading">
                                <td colspan="5" class="py-4 text-center text-gray-500">Loading…</td>
                            </tr>
                            <tr v-for="c in crews" :key="c.id" class="border-b hover:bg-gray-50">
                                <td class="py-2">{{ c.name || '-' }}</td>
                                <td class="py-2">{{ c.phone }}</td>
                                <td class="py-2">{{ c.role || '-' }}</td>
                                <td class="py-2">{{ c.base || '-' }}</td>
                                <td class="flex flex-wrap gap-2 py-2">
                                    <button class="rounded border px-3 py-1" @click="loadAssignments(c)">Assignments</button>
                                    <button class="rounded border px-3 py-1" @click="openAssign(c)">Assign</button>
                                    <button class="rounded border px-3 py-1" @click="openEdit(c)">Edit</button>
                                    <button class="rounded border px-3 py-1 text-red-600" @click="removeCrew(c)">Delete</button>
                                </td>
                            </tr>
                            <tr v-if="!loading && crews.length === 0">
                                <td colspan="5" class="py-4 text-center text-gray-500">No data</td>
                            </tr>
                        </tbody>
                    </table>
                </div>

                <div class="mt-3 flex items-center gap-3">
                    <button class="rounded border px-3 py-1" :disabled="page <= 1" @click="page = Math.max(1, page - 1)">Prev</button>
                    <div>Page {{ pager.current_page }} / {{ pager.last_page }} ({{ pager.total }})</div>
                    <button class="rounded border px-3 py-1" :disabled="page >= pager.last_page" @click="page = Math.min(pager.last_page, page + 1)">
                        Next
                    </button>
                </div>
            </div>

            <div class="min-h-[300px] rounded bg-white p-4 shadow">
                <div class="flex items-center justify-between">
                    <h2 class="text-lg font-semibold">Assignments</h2>
                    <div v-if="selectedCrew" class="text-sm text-gray-500">
                        For: <strong>{{ selectedCrew.name || selectedCrew.phone }}</strong>
                    </div>
                </div>

                <div v-if="selectedCrew" class="mt-3 flex items-center gap-2">
                    <label class="text-sm text-gray-600">Status:</label>
                    <select v-model="assignStatus" class="rounded border px-3 py-1">
                        <option value="">All</option>
                        <option value="queued">queued</option>
                        <option value="sent">sent</option>
                        <option value="failed">failed</option>
                    </select>
                </div>

                <p v-if="assignListErr" class="mt-3 text-sm text-red-600">{{ assignListErr }}</p>
                <div v-if="assignLoading" class="mt-4 text-gray-500">Loading…</div>

                <div v-if="!assignLoading && selectedCrew" class="mt-3 overflow-x-auto">
                    <table class="min-w-full text-sm">
                        <thead>
                            <tr class="border-b text-left text-gray-500">
                                <th class="py-2">Flight</th>
                                <th class="py-2">Dep Time</th>
                                <th class="py-2">Role</th>
                                <th class="py-2">Status</th>
                                <th class="w-28 py-2">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr v-for="a in assignments" :key="a.id" class="border-b">
                                <td class="py-2">{{ a.flight_no }}</td>
                                <td class="py-2">{{ fmt(a.dep_time) }}</td>
                                <td class="py-2">{{ a.role || '-' }}</td>
                                <td class="py-2">
                                    <span
                                        class="rounded border px-2 py-0.5"
                                        :class="{
                                            'border-yellow-400 text-yellow-700': a.status === 'queued',
                                            'border-green-400 text-green-700': a.status === 'sent',
                                            'border-red-400 text-red-700': a.status === 'failed',
                                        }"
                                        >{{ a.status }}</span
                                    >
                                </td>
                                <td class="flex flex-wrap gap-2 py-2">
                                    <button class="rounded border px-3 py-1" @click="resend(a.id)">Resend</button>
                                    <button class="rounded border px-3 py-1" @click="openAssignEdit(a)">Edit</button>
                                    <button class="rounded border px-3 py-1 text-red-600" @click="deleteAssignment(a)">Delete</button>
                                </td>
                            </tr>
                            <tr v-if="assignments.length === 0">
                                <td colspan="5" class="py-4 text-center text-gray-500">No assignments</td>
                            </tr>
                        </tbody>
                    </table>

                    <div class="mt-3 flex items-center gap-3">
                        <button class="rounded border px-3 py-1" :disabled="assignPage <= 1" @click="assignPage = Math.max(1, assignPage - 1)">
                            Prev
                        </button>
                        <div>Page {{ assignPager.current_page }} / {{ assignPager.last_page }} ({{ assignPager.total }})</div>
                        <button
                            class="rounded border px-3 py-1"
                            :disabled="assignPage >= assignPager.last_page"
                            @click="assignPage = Math.min(assignPager.last_page, assignPage + 1)"
                        >
                            Next
                        </button>
                    </div>
                </div>

                <div v-else-if="!selectedCrew" class="mt-4 text-gray-500">Select a crew to view assignments.</div>
            </div>
        </div>

        <div v-if="showForm" class="fixed inset-0 flex items-center justify-center bg-black/30">
            <div class="w-[520px] rounded-lg bg-white p-5 shadow">
                <h3 class="mb-3 text-lg font-semibold">{{ formMode === 'create' ? 'New Crew' : 'Edit Crew' }}</h3>

                <div class="grid grid-cols-2 gap-3">
                    <label class="flex flex-col">
                        <span class="mb-1 text-sm text-gray-600">Name</span>
                        <input v-model="form.name" class="rounded border px-3 py-2" />
                    </label>
                    <label class="flex flex-col">
                        <span class="mb-1 text-sm text-gray-600">Phone</span>
                        <input v-model="form.phone" class="rounded border px-3 py-2" />
                    </label>
                    <label class="flex flex-col">
                        <span class="mb-1 text-sm text-gray-600">Role</span>
                        <select v-model="form.role" class="rounded border px-3 py-2">
                            <option value="FA">FA</option>
                            <option value="CPT">CPT</option>
                            <option value="FO">FO</option>
                            <option value="PURSER">PURSER</option>
                            <option value="SO">SO</option>
                        </select>
                    </label>
                    <label class="flex flex-col">
                        <span class="mb-1 text-sm text-gray-600">Base</span>
                        <input v-model="form.base" class="rounded border px-3 py-2" />
                    </label>
                    <label class="col-span-2 mt-1 flex items-center gap-2">
                        <input type="checkbox" v-model="form.is_active" />
                        <span class="text-sm">Active</span>
                    </label>
                    <label class="col-span-2 flex flex-col">
                        <span class="mb-1 text-sm text-gray-600">Notes</span>
                        <textarea v-model="form.notes" rows="3" class="rounded border px-3 py-2"></textarea>
                    </label>
                </div>

                <p v-if="formErr" class="mt-2 text-sm text-red-600">{{ formErr }}</p>

                <div class="mt-4 flex justify-end gap-2">
                    <button class="rounded border px-3 py-2" @click="showForm = false">Cancel</button>
                    <button class="rounded bg-blue-600 px-3 py-2 text-white" :disabled="saving" @click="saveForm">
                        {{ saving ? 'Saving…' : 'Save' }}
                    </button>
                </div>
            </div>
        </div>

        <div v-if="showAssignForm" class="fixed inset-0 flex items-center justify-center bg-black/30">
            <div class="w-[520px] rounded-lg bg-white p-5 shadow">
                <h3 class="mb-3 text-lg font-semibold">
                    {{ assignMode === 'create' ? 'New Assignment' : 'Edit Assignment' }}
                </h3>

                <div class="grid grid-cols-2 gap-3">
                    <label class="flex flex-col">
                        <span class="mb-1 text-sm text-gray-600">Crew</span>
                        <input :value="selectedCrew?.name || selectedCrew?.phone" disabled class="rounded border bg-gray-50 px-3 py-2" />
                    </label>
                    <label class="flex flex-col">
                        <span class="mb-1 text-sm text-gray-600">Role</span>
                        <select v-model="assignForm.role" class="rounded border px-3 py-2">
                            <option value="FA">FA</option>
                            <option value="CPT">CPT</option>
                            <option value="FO">FO</option>
                            <option value="PURSER">PURSER</option>
                            <option value="SO">SO</option>
                        </select>
                    </label>
                    <label class="col-span-2 flex flex-col">
                        <span class="mb-1 text-sm text-gray-600">Flight No</span>
                        <input v-model="assignForm.flightNo" placeholder="AK123" class="rounded border px-3 py-2" />
                    </label>
                    <label class="col-span-2 flex flex-col">
                        <span class="mb-1 text-sm text-gray-600">Report / Dep Time</span>
                        <input v-model="assignForm.depTime" type="datetime-local" class="rounded border px-3 py-2" />
                    </label>
                    <label v-if="assignMode === 'edit'" class="col-span-2 flex items-center gap-2">
                        <input type="checkbox" v-model="notifyCrew" />
                        <span class="text-sm">Notify crew on save</span>
                    </label>
                </div>

                <p v-if="assignErr" class="mt-2 text-sm text-red-600">{{ assignErr }}</p>

                <div class="mt-4 flex justify-end gap-2">
                    <button class="rounded border px-3 py-2" @click="showAssignForm = false">Cancel</button>
                    <button class="rounded bg-green-600 px-3 py-2 text-white" :disabled="assignSaving" @click="submitAssign">
                        {{ assignSaving ? (assignMode === 'create' ? 'Sending…' : 'Saving…') : assignMode === 'create' ? 'Send' : 'Save' }}
                    </button>
                </div>
            </div>
        </div>
    </div>
</template>

<style scoped>
.min-h-\[300px\] {
    min-height: 300px;
}
</style>

<script setup lang="ts">
import AppLayout from '@/layouts/AppLayout.vue';
import { type BreadcrumbItem } from '@/types';
import { Head, Link } from '@inertiajs/vue3';
import PlaceholderPattern from '../components/PlaceholderPattern.vue';

const breadcrumbs: BreadcrumbItem[] = [{ title: 'Dashboard', href: '/dashboard' }];
</script>

<template>
    <Head title="Dashboard" />

    <AppLayout :breadcrumbs="breadcrumbs">
        <div class="flex h-full flex-1 flex-col gap-4 rounded-xl p-4">
            <div class="grid auto-rows-min gap-4 md:grid-cols-3">
                <!-- Booking -->
                <Link
                    href="/booking"
                    class="group relative block aspect-video overflow-hidden rounded-xl border border-sidebar-border/70 dark:border-sidebar-border"
                >
                    <PlaceholderPattern />
                    <div class="absolute inset-0 flex flex-col justify-end p-4">
                        <h3 class="text-lg font-medium">Create Booking (Nicholas)</h3>
                        <p class="text-sm text-gray-600 dark:text-gray-300">Search/Book/Pay flights. Receive email confirmation (Customer).</p>
                    </div>
                </Link>

                <!-- Booking History -->
                <Link
                    href="/booking-history"
                    class="group relative block aspect-video overflow-hidden rounded-xl border border-sidebar-border/70 dark:border-sidebar-border"
                >
                    <PlaceholderPattern />
                    <div class="absolute inset-0 flex flex-col justify-end p-4">
                        <h3 class="text-lg font-medium">My Booking History (Nicholas)</h3>
                        <p class="text-sm text-gray-600 dark:text-gray-300">View past and current bookings (Customer).</p>
                    </div>
                </Link>

                <!-- Airline Operations -->
                <Link
                    href="/airline-operations"
                    class="group relative block aspect-video overflow-hidden rounded-xl border border-sidebar-border/70 dark:border-sidebar-border"
                >
                    <PlaceholderPattern />
                    <div class="absolute inset-0 flex flex-col justify-end p-4">
                        <h3 class="text-lg font-medium">Manage Airline Operations (Daniel)</h3>
                        <p class="text-sm text-gray-600 dark:text-gray-300">View and edit flight routes (Admin).</p>
                    </div>
                </Link>

                <!-- Keep one placeholder for future reference
                <div class="relative aspect-video overflow-hidden rounded-xl border border-sidebar-border/70 dark:border-sidebar-border">
                    <PlaceholderPattern />
                </div> -->
            </div>

            <div class="grid auto-rows-min gap-4 md:grid-cols-3">
                <!-- Crew Management -->
                <Link
                    href="/crew-management"
                    class="group relative block aspect-video overflow-hidden rounded-xl border border-sidebar-border/70 dark:border-sidebar-border"
                >
                    <PlaceholderPattern />
                    <div class="absolute inset-0 flex flex-col justify-end p-4">
                        <h3 class="text-lg font-medium">Manage Crew (Shelley)</h3>
                        <p class="text-sm text-gray-600 dark:text-gray-300">Add/Edit/Delete · Assign & notify via WhatsApp (Admin).</p>
                    </div>
                </Link>

                <div class="relative aspect-video overflow-hidden rounded-xl border border-sidebar-border/70 dark:border-sidebar-border">
                    <PlaceholderPattern />
                </div>

                <div class="relative aspect-video overflow-hidden rounded-xl border border-sidebar-border/70 dark:border-sidebar-border">
                    <PlaceholderPattern />
                </div>
            </div>

            <div class="grid auto-rows-min gap-4 md:grid-cols-3">
                <div class="relative aspect-video overflow-hidden rounded-xl border border-sidebar-border/70 dark:border-sidebar-border">
                    <PlaceholderPattern />
                </div>

                <div class="relative aspect-video overflow-hidden rounded-xl border border-sidebar-border/70 dark:border-sidebar-border">
                    <PlaceholderPattern />
                </div>

                <div class="relative aspect-video overflow-hidden rounded-xl border border-sidebar-border/70 dark:border-sidebar-border">
                    <PlaceholderPattern />
                </div>
            </div>

            <!-- Booking
            <Link href="/booking" class="group relative block overflow-hidden rounded-xl border border-sidebar-border/70 dark:border-sidebar-border">
                <div class="relative min-h-[100vh] rounded-xl">
                    <h3 class="text-lg font-medium">Create Booking (Nicholas)</h3>
                    <p class="text-sm text-gray-600 dark:text-gray-300">Search/Book/Pay flights. Receive email confirmation (Customer).</p>
                </div>
            </Link> -->

            <!-- </div>

            <div class="relative min-h-[100vh] flex-1 rounded-xl border border-sidebar-border/70 dark:border-sidebar-border md:min-h-min">
                <PlaceholderPattern />
            </div> -->
        </div>
    </AppLayout>
</template>

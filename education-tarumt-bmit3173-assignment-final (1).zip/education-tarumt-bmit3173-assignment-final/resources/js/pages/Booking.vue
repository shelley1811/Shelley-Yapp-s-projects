<script setup lang="ts">
import AppLayout from '@/layouts/AppLayout.vue';
import type { BreadcrumbItem } from '@/types';
import { Head, usePage } from '@inertiajs/vue3';
import { computed, onMounted, reactive, ref } from 'vue';

/** -----------------------------
 * Breadcrumbs (dashboard style)
 * ------------------------------*/
const breadcrumbs: BreadcrumbItem[] = [
    { title: 'Dashboard', href: '/dashboard' },
    { title: 'Booking', href: '/booking' },
];

/** -----------------------------
 * Types (lightweight)
 * ------------------------------*/
type Flight = {
    id: number;
    flight_no: string;
    origin: string;
    destination: string;
    flight_date: string;
    departure_time: string;
    arrival_time: string;
    duration_minutes: number;
    base_fare_myr: number;
    seats_available: number;
};
type BookingDto = {
    id: number;
    ref: string;
    status: 'PENDING' | 'CONFIRMED' | 'CANCELLED' | 'EXPIRED';
    grand_total_myr: number;
    paid_total_myr: number;
    balance_myr: number;
    expires_at: string | null;
    contact?: { name?: string; email?: string };
    contact_email?: string;
};
type PaymentDto = {
    id?: number;
    status: 'PENDING' | 'SUCCEEDED' | 'FAILED' | 'REFUNDED';
    amount_myr: number;
    provider: string;
    transaction_ref?: string;
    booking?: BookingDto;
};

/** -----------------------------
 * Helpers
 * ------------------------------*/
function fmtMYR(n: number | null | undefined) {
    try {
        return new Intl.NumberFormat('ms-MY', { style: 'currency', currency: 'MYR' }).format(n ?? 0);
    } catch {
        return `MYR ${Number(n ?? 0).toFixed(2)}`;
    }
}
function minutesToHM(m: number | null | undefined) {
    const mins = m ?? 0;
    const h = Math.floor(mins / 60);
    const mm = mins % 60;
    return `${h}h ${mm}m`;
}
async function apiGet<T = any>(url: string): Promise<T> {
    const r = await fetch(url);
    if (!r.ok) throw new Error(await r.text());
    return await r.json();
}
async function apiPost<T = any>(url: string, body: any): Promise<T> {
    const r = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
    });
    const txt = await r.text();
    let json: any;
    try {
        json = txt ? JSON.parse(txt) : {};
    } catch {
        throw new Error(txt || 'Invalid JSON');
    }
    if (!r.ok) throw new Error(json?.message ?? 'Request failed');
    return json;
}

/** -----------------------------
 * Auth (contact name/email)
 * ------------------------------*/
const page = usePage<{ auth?: { user?: { name?: string; email?: string } } }>();
const currentUserName = computed(() => page.props?.auth?.user?.name ?? '');
const currentUserEmail = computed(() => page.props?.auth?.user?.email ?? '');

async function ensureUserFromProfileIfMissing() {
    if (currentUserEmail.value) return;
    try {
        const res = await fetch('/settings/profile', { headers: { 'X-Inertia': 'true', Accept: 'application/json' } });
        if (res.ok) {
            const json = await res.json();
            // @ts-ignore
            const u = json?.props?.auth?.user;
            if (u?.email) {
                // @ts-ignore
                page.props.auth = { user: { name: u.name, email: u.email } };
            }
        }
    } catch {
        /* ignore */
    }
}

/** -----------------------------
 * Flights
 * ------------------------------*/
const flights = ref<Flight[]>([]);
const loadingFlights = ref(false);
const error = ref<string>('');

async function loadFlights() {
    error.value = '';
    loadingFlights.value = true;
    selectedFlight.value = null;
    try {
        flights.value = await apiGet<Flight[]>('/api/flights');
        if (!flights.value.length) error.value = 'No flights available.';
    } catch (e: any) {
        error.value = e.message || 'Failed to load flights.';
    } finally {
        loadingFlights.value = false;
    }
}

/** -----------------------------
 * Booking
 * ------------------------------*/
const selectedFlight = ref<Flight | null>(null);
const booking = ref<BookingDto | null>(null);
const passengerName = ref<string>('');

async function createBooking() {
    if (!selectedFlight.value) return;
    error.value = '';
    try {
        const payload = {
            contact_name: currentUserName.value,
            contact_email: currentUserEmail.value,
            contact_phone: null,
            items: [
                {
                    flight_id: selectedFlight.value.id,
                    passenger_name: passengerName.value,
                    quantity: 1,
                },
            ],
        };
        const res: any = await apiPost('/api/bookings', payload);
        booking.value = (res.data ?? res) as BookingDto;

        // keep local history for the new /booking-history page
        saveLocalBooking(booking.value);

        payForm.amount_myr = Number(booking.value?.balance_myr ?? 0);
    } catch (e: any) {
        error.value = e.message || 'Failed to create booking.';
    }
}
const bookingConfirmed = computed(() => booking.value?.status === 'CONFIRMED');

/** -----------------------------
 * Payment (client-side checks)
 * ------------------------------*/
const paying = ref(false);
const payment = ref<PaymentDto | null>(null);
const paymentError = ref<string>('');

const payForm = reactive({
    amount_myr: null as number | null,
    card_number: '',
    card_expiry: '',
    card_cvc: '',
});

function luhnPass(num: string) {
    const s = (num || '').replace(/\s+/g, '');
    if (!/^\d{12,19}$/.test(s)) return false;
    let sum = 0,
        dbl = false;
    for (let i = s.length - 1; i >= 0; i--) {
        let d = parseInt(s[i], 10);
        if (dbl) {
            d *= 2;
            if (d > 9) d -= 9;
        }
        sum += d;
        dbl = !dbl;
    }
    return sum % 10 === 0;
}
function expiryValid(mmYY: string) {
    const m = mmYY.match(/^\s*(0[1-9]|1[0-2])\s*\/\s*(\d{2})\s*$/);
    if (!m) return false;
    const month = parseInt(m[1], 10);
    const year = 2000 + parseInt(m[2], 10);
    const lastDay = new Date(year, month, 0);
    lastDay.setHours(23, 59, 59, 999);
    return lastDay >= new Date();
}
function cvcValid(cvc: string) {
    return /^\d{3,4}$/.test((cvc || '').trim());
}

async function payNow() {
    if (!booking.value?.id) return;
    paymentError.value = '';
    error.value = '';
    payment.value = null;

    if (!luhnPass(payForm.card_number) || !expiryValid(payForm.card_expiry) || !cvcValid(payForm.card_cvc)) {
        payment.value = { status: 'FAILED', amount_myr: Number(payForm.amount_myr ?? 0), provider: 'gateway' };
        paymentError.value = 'Payment failed — please check your credit card details.';
        return;
    }

    const fullAmount = Number(booking.value.balance_myr ?? 0);
    paying.value = true;
    try {
        const res: any = await apiPost(`/api/payments/${booking.value.id}`, {
            amount_myr: fullAmount,
            method: 'CARD',
            token: 'tok_card_ok',
        });
        payment.value = (res.data ?? res) as PaymentDto;
        if (payment.value?.booking) {
            booking.value.status = payment.value.booking.status;
            booking.value.paid_total_myr = payment.value.booking.paid_total_myr;
            booking.value.balance_myr = payment.value.booking.balance_myr;
        }
        // update local snapshot so /booking-history sees latest status
        saveLocalBooking(booking.value!);
    } catch (e: any) {
        paymentError.value = e.message || 'Payment failed.';
    } finally {
        paying.value = false;
    }
}

/** -----------------------------
 * Local history writer (kept)
 * ------------------------------*/
const STORAGE_KEY = 'sr_my_bookings';
function saveLocalBooking(b: BookingDto) {
    try {
        const entry = { ...b, saved_at: new Date().toISOString() };
        const arr = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
        const idx = arr.findIndex((x: any) => x?.id === b.id);
        if (idx >= 0) arr[idx] = entry;
        else arr.push(entry);
        localStorage.setItem(STORAGE_KEY, JSON.stringify(arr));
    } catch {
        /* ignore */
    }
}

/** -----------------------------
 * Boot
 * ------------------------------*/
onMounted(async () => {
    await ensureUserFromProfileIfMissing();
    if (!passengerName.value && currentUserName.value) {
        passengerName.value = currentUserName.value;
    }

    await loadFlights();
});
</script>

<template>
    <Head title="Booking" />

    <AppLayout :breadcrumbs="breadcrumbs">
        <div class="flex h-full flex-1 flex-col gap-4 rounded-xl p-4">
            <div class="space-y-6">
                <!-- Step 1 -->
                <section class="space-y-4 rounded-xl border border-sidebar-border/70 p-6 dark:border-sidebar-border">
                    <div class="flex items-center justify-between">
                        <h2 class="text-lg font-medium">1) Select a Flight</h2>
                        <button @click="loadFlights" class="rounded bg-black px-4 py-2 text-white disabled:opacity-50" :disabled="loadingFlights">
                            <span v-if="!loadingFlights">Refresh</span>
                            <span v-else>Loading…</span>
                        </button>
                    </div>

                    <div v-if="!loadingFlights && flights.length" class="grid gap-3">
                        <div v-for="f in flights" :key="f.id" class="flex items-center justify-between rounded border p-4">
                            <div>
                                <div class="font-medium">{{ f.flight_no }} · {{ f.origin }} → {{ f.destination }}</div>
                                <div class="text-sm text-gray-600">
                                    {{ f.flight_date }} • {{ f.departure_time }} → {{ f.arrival_time }} ({{ minutesToHM(f.duration_minutes) }})
                                </div>
                                <div class="text-sm">
                                    Fare: <span class="font-medium">{{ fmtMYR(f.base_fare_myr) }}</span>
                                </div>
                                <div class="text-xs text-gray-500">Seats available: {{ f.seats_available }}</div>
                            </div>
                            <button @click="selectedFlight = f" class="rounded bg-gray-900 px-3 py-2 text-white">Select</button>
                        </div>
                    </div>

                    <div v-if="loadingFlights" class="text-sm text-gray-600">Loading flights…</div>
                    <div v-if="error" class="rounded-md bg-red-50 p-3 text-sm text-red-700">{{ error }}</div>
                </section>

                <!-- Step 2 -->
                <section class="space-y-4 rounded-xl border border-sidebar-border/70 p-6 dark:border-sidebar-border">
                    <h2 class="text-lg font-medium">2) Create Booking</h2>

                    <div v-if="!selectedFlight" class="text-sm text-gray-600">Select a flight from step 1 to continue.</div>

                    <div v-else class="space-y-4">
                        <div class="rounded bg-gray-50 p-3 text-sm">
                            <div class="font-medium">
                                Selected: {{ selectedFlight.flight_no }} ({{ selectedFlight.origin }} → {{ selectedFlight.destination }})
                            </div>
                            <div>{{ selectedFlight.flight_date }} • {{ selectedFlight.departure_time }} → {{ selectedFlight.arrival_time }}</div>
                        </div>

                        <div class="text-sm text-gray-700">
                            <div><span class="font-medium">Contact:</span> {{ currentUserName || '—' }} ({{ currentUserEmail || '—' }})</div>
                        </div>

                        <div class="grid grid-cols-1 gap-3 md:grid-cols-3">
                            <div>
                                <label class="block text-sm text-gray-600">Passenger Name</label>
                                <input v-model.trim="passengerName" class="sr-input mt-1 w-full rounded border px-3 py-2" />
                            </div>
                        </div>

                        <button @click="createBooking" class="rounded bg-emerald-600 px-4 py-2 text-white">Create Booking</button>

                        <div v-if="booking" class="mt-4 rounded border p-4">
                            <div class="mb-1 font-medium">Booking Created</div>
                            <div class="text-sm">
                                Ref: <span class="font-mono">{{ booking.ref }}</span>
                            </div>
                            <div class="text-sm">
                                Status:
                                <span :class="bookingConfirmed ? 'text-emerald-700' : 'text-amber-700'">{{ booking.status }}</span>
                            </div>
                            <div class="text-sm">
                                Total: {{ fmtMYR(booking.grand_total_myr) }} • Paid: {{ fmtMYR(booking.paid_total_myr) }} • Balance:
                                <span class="font-medium">{{ fmtMYR(booking.balance_myr) }}</span>
                            </div>
                            <div class="text-xs text-gray-500">Expires at: {{ booking.expires_at }}</div>
                        </div>
                    </div>
                </section>

                <!-- Step 3 -->
                <section class="space-y-4 rounded-xl border border-sidebar-border/70 p-6 dark:border-sidebar-border">
                    <h2 class="text-lg font-medium">3) Payment</h2>
                    <div v-if="!booking" class="text-sm text-gray-600">Create a booking first.</div>

                    <div v-else class="grid grid-cols-1 items-end gap-3 md:grid-cols-4">
                        <div>
                            <label class="block text-sm text-gray-600">Amount (MYR)</label>
                            <input :value="booking.balance_myr" readonly disabled class="sr-input mt-1 w-full rounded border px-3 py-2" />
                            <p class="mt-1 text-xs text-gray-500">Full payment only.</p>
                        </div>
                        <div>
                            <label class="block text-sm text-gray-600">Card Number</label>
                            <input
                                v-model.trim="payForm.card_number"
                                inputmode="numeric"
                                autocomplete="cc-number"
                                class="sr-input mt-1 w-full rounded border px-3 py-2"
                                placeholder="4111 1111 1111 1111"
                            />
                        </div>
                        <div>
                            <label class="block text-sm text-gray-600">Expiry (MM/YY)</label>
                            <input
                                v-model.trim="payForm.card_expiry"
                                inputmode="numeric"
                                autocomplete="cc-exp"
                                class="sr-input mt-1 w-full rounded border px-3 py-2"
                                placeholder="MM/YY"
                            />
                        </div>
                        <div>
                            <label class="block text-sm text-gray-600">CVC</label>
                            <input
                                v-model.trim="payForm.card_cvc"
                                inputmode="numeric"
                                autocomplete="cc-csc"
                                class="sr-input mt-1 w-full rounded border px-3 py-2"
                                placeholder="CVC"
                            />
                        </div>
                        <div class="md:col-span-4">
                            <button @click="payNow" :disabled="paying" class="rounded bg-indigo-600 px-4 py-2 text-white disabled:opacity-50">
                                <span v-if="!paying">Pay Now</span>
                                <span v-else>Processing…</span>
                            </button>
                        </div>
                    </div>

                    <div v-if="paymentError" class="rounded-md bg-red-50 p-3 text-sm text-red-700">{{ paymentError }}</div>

                    <div v-if="payment" class="mt-4 rounded border p-4">
                        <div class="mb-1 font-medium">Payment Result</div>
                        <div class="text-sm">
                            Status:
                            <span :class="payment.status === 'SUCCEEDED' ? 'text-emerald-700' : 'text-red-700'">{{ payment.status }}</span>
                        </div>
                        <div class="text-sm" v-if="payment.transaction_ref">
                            Txn Ref: <span class="font-mono">{{ payment.transaction_ref }}</span>
                        </div>
                        <div class="text-sm">Amount: {{ fmtMYR(payment.amount_myr) }}</div>
                        <div class="text-sm">Provider: {{ payment.provider }}</div>
                        <div class="mt-2 text-sm">
                            Booking Status:
                            <span :class="bookingConfirmed ? 'text-emerald-700' : 'text-amber-700'">{{ booking?.status }}</span>
                        </div>
                    </div>
                </section>
            </div>
        </div>
    </AppLayout>
</template>

<style scoped>
code {
    @apply rounded bg-gray-100 px-1 py-0.5;
}
</style>

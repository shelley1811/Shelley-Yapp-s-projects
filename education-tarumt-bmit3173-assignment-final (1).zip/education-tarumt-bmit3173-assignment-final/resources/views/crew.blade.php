<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Crew Management</title>
  @vite('resources/js/app.ts')
  <script>
    window.APP_BASE = '{{ url('/') }}';
  </script>
</head>
<body class="bg-gray-50">
  <div id="app"></div>
</body>
</html>

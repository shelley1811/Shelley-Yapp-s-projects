<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Flight Schedule Module</title>
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <style>
        body { background-color: #000; color: #fff; font-family: Arial, sans-serif; margin: 0; padding: 20px; }
        h1, h2 { color: #fff; }
        .container { max-width: 1200px; margin: auto; }
        nav { margin-bottom: 20px; }
        nav button { background-color: #222; border: 1px solid #444; color: #fff; padding: 10px 20px; margin-right: 10px; cursor: pointer; }
        nav button.active { background-color: #555; }
        table { width: 100%; border-collapse: collapse; margin-bottom: 30px; }
        th, td { border: 1px solid #444; padding: 8px; text-align: left; }
        th { background-color: #111; }
        input, select { background-color: #222; border: 1px solid #444; color: #fff; padding: 6px; margin: 5px 0; width: 100%; }
        label { display: block; margin-top: 10px; }
        form { max-width: 600px; margin-bottom: 40px; }
        button.submit-btn { background-color: #444; border: none; color: white; padding: 10px 15px; cursor: pointer; margin-top: 10px; }
        button.submit-btn:hover { background-color: #666; }
        .hidden { display: none; }
        .message { margin-bottom: 20px; padding: 10px; border: 1px solid #444; background-color: #111; }
    </style>
</head>
<body>
<div class="container">
    <h1>Flight Schedule Module</h1>
    <nav>
        <button id="btnTable" class="active">Schedules</button>
        <button id="btnCreate">Create</button>
        <button id="btnFilter">Filter</button>
        <button id="btnDailyStats">Daily Stats</button>
        <button id="btnAircraftStats">Aircraft Utilization</button>
    </nav>

    <section id="sectionTable">
        <h2>All Flight Schedules</h2>
        <table id="tableSchedules">
            <thead>
                <tr>
                    <th>Route ID</th>
                    <th>Departure</th>
                    <th>Arrival</th>
                    <th>Departure Date</th>
                    <th>Departure Time</th>
                    <th>Arrival Time</th>
                    <th>Gate</th>
                    <th>Aircraft</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody></tbody>
        </table>
    </section>

    <section id="sectionCreate" class="hidden">
        <h2>Create Flight Schedule</h2>
        <form id="createForm">
            <label>Route ID</label><input type="text" name="route_id" required />
            <label>Departure Airport</label><input type="text" name="departure_airport" maxlength="3" required />
            <label>Arrival Airport</label><input type="text" name="arrival_airport" maxlength="3" required />
            <label>Departure Date</label><input type="date" name="departure_date" required />
            <label>Departure Time</label><input type="time" name="departure_time" required />
            <label>Arrival Time</label><input type="time" name="arrival_time" required />
            <label>Gate</label><input type="text" name="gate" maxlength="10" />
            <label>Aircraft Registration Number</label><input type="text" name="aircraft_registration_number" required />
            <button type="submit" class="submit-btn">Create</button>
        </form>
    </section>

    <section id="sectionFilter" class="hidden">
        <h2>Filter Flight Schedules</h2>
        <form id="filterForm">
            <label>Departure Airport</label><input type="text" name="departure_airport" maxlength="3" />
            <label>Arrival Airport</label><input type="text" name="arrival_airport" maxlength="3" />
            <label>Aircraft Registration Number</label><input type="text" name="aircraft_registration_number" />
            <label>Departure Date</label><input type="date" name="departure_date" />
            <button type="submit" class="submit-btn">Filter</button>
            <button type="button" id="resetFilter" class="submit-btn">Reset</button>
        </form>
    </section>

    <section id="sectionEdit" class="hidden">
        <h2>Edit Flight Schedule</h2>
        <form id="editForm">
            <input type="hidden" name="route_id" />
            <label>Departure Airport</label><input type="text" name="departure_airport" maxlength="3" required />
            <label>Arrival Airport</label><input type="text" name="arrival_airport" maxlength="3" required />
            <label>Departure Date</label><input type="date" name="departure_date" required />
            <label>Departure Time</label><input type="time" name="departure_time" required />
            <label>Arrival Time</label><input type="time" name="arrival_time" required />
            <label>Gate</label><input type="text" name="gate" maxlength="10" />
            <label>Aircraft Registration Number</label><input type="text" name="aircraft_registration_number" required />
            <button type="submit" class="submit-btn">Update</button>
        </form>
    </section>

    <section id="sectionDailyStats" class="hidden">
        <h2>Daily Flight Stats</h2>
        <table id="tableDailyStats">
            <thead>
                <tr><th>Departure Date</th><th>Total Flights</th></tr>
            </thead>
            <tbody></tbody>
        </table>
    </section>

    <section id="sectionAircraftStats" class="hidden">
        <h2>Aircraft Utilization</h2>
        <table id="tableAircraftStats">
            <thead>
                <tr><th>Aircraft</th><th>Total Flights</th></tr>
            </thead>
            <tbody></tbody>
        </table>
    </section>

    <div id="message" class="message"></div>
</div>

<script>
const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');

// Navigation
const btnTable = document.getElementById('btnTable');
const btnCreate = document.getElementById('btnCreate');
const btnFilter = document.getElementById('btnFilter');
const btnDailyStats = document.getElementById('btnDailyStats');
const btnAircraftStats = document.getElementById('btnAircraftStats');

const sectionTable = document.getElementById('sectionTable');
const sectionCreate = document.getElementById('sectionCreate');
const sectionFilter = document.getElementById('sectionFilter');
const sectionEdit = document.getElementById('sectionEdit');
const sectionDailyStats = document.getElementById('sectionDailyStats');
const sectionAircraftStats = document.getElementById('sectionAircraftStats');

btnTable.addEventListener('click', () => showSection('table'));
btnCreate.addEventListener('click', () => showSection('create'));
btnFilter.addEventListener('click', () => showSection('filter'));
btnDailyStats.addEventListener('click', () => { fetchDailyStats(); showSection('dailyStats'); });
btnAircraftStats.addEventListener('click', () => { fetchAircraftStats(); showSection('aircraftStats'); });

function showSection(section) {
    sectionTable.classList.add('hidden');
    sectionCreate.classList.add('hidden');
    sectionFilter.classList.add('hidden');
    sectionEdit.classList.add('hidden');
    sectionDailyStats.classList.add('hidden');
    sectionAircraftStats.classList.add('hidden');

    btnTable.classList.remove('active');
    btnCreate.classList.remove('active');
    btnFilter.classList.remove('active');
    btnDailyStats.classList.remove('active');
    btnAircraftStats.classList.remove('active');

    if(section==='table'){ sectionTable.classList.remove('hidden'); btnTable.classList.add('active'); }
    if(section==='create'){ sectionCreate.classList.remove('hidden'); btnCreate.classList.add('active'); }
    if(section==='filter'){ sectionFilter.classList.remove('hidden'); btnFilter.classList.add('active'); }
    if(section==='edit'){ sectionEdit.classList.remove('hidden'); }
    if(section==='dailyStats'){ sectionDailyStats.classList.remove('hidden'); btnDailyStats.classList.add('active'); }
    if(section==='aircraftStats'){ sectionAircraftStats.classList.remove('hidden'); btnAircraftStats.classList.add('active'); }
}

// Fetch all schedules
async function fetchSchedules() {
    try {
        const response = await fetch('/flight-schedules', {
            headers: { 'Accept': 'application/json' }
        });

        if (!response.ok) {
            const txt = await response.text();
            showMessage('Failed to fetch schedules: ' + response.status + ' ' + txt);
            return;
        }

        const data = await response.json();
        populateTable(data);
    } catch (err) {
        showMessage('Error fetching schedules: ' + err.message);
    }
}
function populateTable(data){
    const tbody = document.querySelector('#tableSchedules tbody');
    tbody.innerHTML = '';
    if(!data || data.length === 0){
        const tr = document.createElement('tr');
        tr.innerHTML = `<td colspan="9">No schedules found</td>`;
        tbody.appendChild(tr);
        return;
    }
    data.forEach(schedule=>{
        const departureName = schedule.departure_airport?.name || schedule.departure_airport?.iata_code || schedule.departure_airport;
        const arrivalName = schedule.arrival_airport?.name || schedule.arrival_airport?.iata_code || schedule.arrival_airport;
        const tr = document.createElement('tr');
        tr.innerHTML = `
            <td>${schedule.route_id}</td>
            <td>${departureName}</td>
            <td>${arrivalName}</td>
            <td>${schedule.departure_date}</td>
            <td>${schedule.departure_time}</td>
            <td>${schedule.arrival_time}</td>
            <td>${schedule.gate||''}</td>
            <td>${schedule.aircraft?.registration_number || schedule.aircraft_registration_number}</td>
            <td>
                <button onclick="editSchedule('${schedule.route_id}')">Edit</button>
                <button onclick="deleteSchedule('${schedule.route_id}')">Delete</button>
            </td>
        `;
        tbody.appendChild(tr);
    });
}

// Create
document.getElementById('createForm').addEventListener('submit', async e=>{
    e.preventDefault();
    const formData = Object.fromEntries(new FormData(e.target).entries());
    try {
        const response = await fetch('/flight-schedules', {
            method:'POST',
            headers:{ 'Content-Type':'application/json','Accept':'application/json','X-CSRF-TOKEN':csrfToken},
            body:JSON.stringify(formData)
        });
        if(response.ok){ 
            await response.json();
            showMessage('Flight schedule created'); 
            e.target.reset();
            fetchSchedules();
            showSection('table');
        }
        else{ const txt = await response.text(); showMessage('Error: '+txt); }
    } catch(err){ showMessage('Error: '+err.message); }
});

// Delete
async function deleteSchedule(route_id){
    if(!confirm('Delete this schedule?')) return;
    try{
        const response = await fetch('/flight-schedules/'+route_id, { method:'DELETE', headers:{'Accept':'application/json','X-CSRF-TOKEN':csrfToken} });
        if(response.ok){ showMessage('Deleted successfully'); fetchSchedules(); }
        else{ const txt = await response.text(); showMessage('Error: '+txt); }
    } catch(err){ showMessage('Error: '+err.message); }
}

// Edit (form-based)
function editSchedule(route_id){
    fetch('/flight-schedules/'+route_id, { headers:{'Accept':'application/json'} })
        .then(res=>res.json())
        .then(schedule=>{
            const form = document.getElementById('editForm');
            form.route_id.value = schedule.route_id;
            form.departure_airport.value = schedule.departure_airport?.iata_code || schedule.departure_airport;
            form.arrival_airport.value = schedule.arrival_airport?.iata_code || schedule.arrival_airport;
            form.departure_date.value = schedule.departure_date;
            form.departure_time.value = schedule.departure_time;
            form.arrival_time.value = schedule.arrival_time;
            form.gate.value = schedule.gate || '';
            form.aircraft_registration_number.value = schedule.aircraft?.registration_number || schedule.aircraft_registration_number;
            showSection('edit');
        });
}

document.getElementById('editForm').addEventListener('submit', async e=>{
    e.preventDefault();
    const formData = Object.fromEntries(new FormData(e.target).entries());
    const route_id = formData.route_id;
    try {
        const response = await fetch('/flight-schedules/'+route_id, {
            method:'PUT',
            headers:{ 'Content-Type':'application/json','Accept':'application/json','X-CSRF-TOKEN':csrfToken },
            body: JSON.stringify(formData)
        });
        if(response.ok){
            showMessage('Updated successfully');
            fetchSchedules();
            showSection('table');
        } else {
            const txt = await response.text();
            showMessage('Error: '+txt);
        }
    } catch(err){ showMessage('Error: '+err.message); }
});

// Filter
document.getElementById('filterForm').addEventListener('submit', async e=>{
    e.preventDefault();
    const formData = Object.fromEntries(new FormData(e.target).entries());
    let url = '/flight-schedules/filter?';
    const params = new URLSearchParams(formData);
    url += params.toString();
    try{
        const response = await fetch(url, { headers:{'Accept':'application/json'} });
        if(!response.ok){ const txt = await response.text(); showMessage('Error: '+txt); return; }
        const data = await response.json();
        populateTable(data);
        showSection('table');
    } catch(err){ showMessage('Error: '+err.message); }
});

document.getElementById('resetFilter').addEventListener('click', ()=>{
    document.getElementById('filterForm').reset();
    fetchSchedules();
    showSection('table');
});

// Daily Stats
async function fetchDailyStats(){
    try{
        const res = await fetch('/api/flight-schedules/stats/daily', { headers:{'Accept':'application/json'} });
        if(!res.ok){ showMessage('Error fetching daily stats'); return; }
        const data = await res.json();
        const tbody = document.querySelector('#tableDailyStats tbody');
        tbody.innerHTML='';
        data.forEach(row=>{
            const tr = document.createElement('tr');
            tr.innerHTML = `<td>${row.departure_date}</td><td>${row.total}</td>`;
            tbody.appendChild(tr);
        });
    } catch(err){ showMessage('Error: '+err.message); }
}

// Aircraft Stats
async function fetchAircraftStats(){
    try{
        const res = await fetch('/api/flight-schedules/stats/aircraft', { headers:{'Accept':'application/json'} });
        if(!res.ok){ showMessage('Error fetching aircraft stats'); return; }
        const data = await res.json();
        const tbody = document.querySelector('#tableAircraftStats tbody');
        tbody.innerHTML='';
        data.forEach(row=>{
            const tr = document.createElement('tr');
            tr.innerHTML = `<td>${row.aircraft_registration_number}</td><td>${row.total}</td>`;
            tbody.appendChild(tr);
        });
    } catch(err){ showMessage('Error: '+err.message); }
}

function showMessage(msg){
    const div = document.getElementById('message');
    div.textContent = msg;
    setTimeout(()=>{ div.textContent=''; }, 5000);
}

fetchSchedules();
</script>
</body>
</html>




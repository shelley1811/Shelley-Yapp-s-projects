<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>Airline Operations Module</title>
    <style>
        body {
            background-color: #ffffff;
            color: #000000;
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
        }
        h1, h2 {
            color: #000000;
        }
        .container {
            max-width: 1200px;
            margin: auto;
        }
        nav {
            margin-bottom: 20px;
        }
        nav button {
            background-color: #000000;
            border: 1px solid #444;
            color: #ffffff;
            padding: 10px 20px;
            margin-right: 10px;
            cursor: pointer;
        }
        nav button.active {
            background-color: #555555;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 30px;
        }
        th, td {
            border: 1px solid #444444;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #eeeeee;
        }
        input, select {
            background-color: #ffffff;
            border: 1px solid #444444;
            color: #000000;
            padding: 6px;
            margin: 5px 0;
            width: 100%;
            box-sizing: border-box;
        }
        label {
            display: block;
            margin-top: 10px;
        }
        form {
            max-width: 600px;
            margin-bottom: 40px;
        }
        button.submit-btn {
            background-color: #000000;
            border: none;
            color: white;
            padding: 10px 15px;
            cursor: pointer;
            margin-top: 10px;
        }
        button.submit-btn:hover {
            background-color: #333333;
        }
        .hidden {
            display: none;
        }
        .message {
            margin-bottom: 20px;
            padding: 10px;
            border: 1px solid #444444;
            background-color: #eeeeee;
            color: #000000;
        }
    </style>
    <style>
        .routes-container {
            display: flex;
            gap: 20px;
            width: 100%;
        }
        .routes-left {
            flex: 3;
            overflow-x: auto;
            min-width: 0; /* Prevent overflow issues */
        }
        .routes-right {
            flex: 1;
            max-width: 350px;
            min-width: 300px;
        }
        @media (max-width: 768px) {
            .routes-container {
                flex-direction: column;
            }
            .routes-right {
                max-width: 100%;
                min-width: auto;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Airline Operations Module</h1>
        <nav>
            <button id="btnAirports" class="active">Airports</button>
            <button id="btnAircraft">Aircraft</button>
            <button id="btnRoutes">Routes</button>
        </nav>

        <section id="sectionAirports">
            <h2>Airports</h2>
            <table id="tableAirports">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>IATA Code</th>
                        <th>Airport Name</th>
                        <th>City</th>
                        <th>Country</th>
                        <th>Latitude</th>
                        <th>Longitude</th>
                </tr>
            </thead>
            <tbody></tbody>
        </table>
    </section>

        <section id="sectionAircraft" class="hidden">
            <h2>Aircraft</h2>
            <table id="tableAircraft">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Registration Number</th>
                        <th>Model</th>
                        <th>Manufacturer</th>
                        <th>Capacity</th>
                        <th>Range (km)</th>
                        <th>Airline</th>
                        <th>Base IATA</th>
                    </tr>
                </thead>
                <tbody></tbody>
            </table>
        </section>

        <section id="sectionRoutes" class="hidden">
            <h2>Routes</h2>
            <div class="routes-container">
                <div class="routes-left">
                    <table id="tableRoutes">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Route ID</th>
                                <th>Registered Aircraft</th>
                        <th>Flight Status</th>
                        <th>Weather Condition</th>
                        <th>Has Delay</th>
                        <th>Delay in Minutes</th>
                        <th>Delay Reason</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody></tbody>
                    </table>
                </div>
                <div class="routes-right" style="border: 2px solid black; padding: 10px;">
                    <h3>Create New Route</h3>
                    <form id="createRouteForm">
                        <label for="route_id">Route ID</label>
                        <input type="text" id="route_id" name="route_id" required />

                        <label for="aircraft_registration">Registered Aircraft</label>
                        <input type="text" id="aircraft_registration" name="aircraft_registration" required />

                        <!-- Removed Estimated Flight Time -->
                        <!-- Removed Delay Time Start -->
                        <!-- Removed Delay Time End -->

                        <label for="status">Status</label>
                        <select id="status" name="status" required>
                            <option value="active">Active</option>
                            <option value="inactive">Inactive</option>
                            <option value="cancelled">Cancelled</option>
                        </select>

                        <label for="weather_condition">Weather Condition</label>
                        <input type="text" id="weather_condition" name="weather_condition" />

                        <label for="has_delay">Has Delay</label>
                        <select id="has_delay" name="has_delay">
                            <option value="0">No</option>
                            <option value="1">Yes</option>
                        </select>

                        <label for="delay_reason">Delay Reason</label>
                        <input type="text" id="delay_reason" name="delay_reason" />

                    <button type="submit" class="submit-btn" style="background-color: #22c55e;">Create Route</button>
                    </form>

                    <h3>Update Route</h3>
                    <form id="updateRouteForm" class="hidden">
                        <input type="hidden" id="update_route_id_hidden" name="id" />

                        <label for="update_route_id">Route ID</label>
                        <input type="text" id="update_route_id" name="route_id" required />

                        <label for="update_aircraft_registration">Registered Aircraft</label>
                        <input type="text" id="update_aircraft_registration" name="aircraft_registration" required />

                        <!-- Removed Estimated Flight Time -->
                        <!-- Removed Delay Time Start -->
                        <!-- Removed Delay Time End -->

                        <label for="update_status">Status</label>
                        <select id="update_status" name="status" required>
                            <option value="active">Active</option>
                            <option value="inactive">Inactive</option>
                            <option value="cancelled">Cancelled</option>
                        </select>

                        <label for="update_weather_condition">Weather Condition</label>
                        <input type="text" id="update_weather_condition" name="weather_condition" />

                        <label for="update_has_delay">Has Delay</label>
                        <select id="update_has_delay" name="has_delay">
                            <option value="0">No</option>
                            <option value="1">Yes</option>
                        </select>

                        <label for="update_delay_reason">Delay Reason</label>
                        <input type="text" id="update_delay_reason" name="delay_reason" />

                        <button type="submit" class="submit-btn" style="background-color: #3b82f6;">Update Route</button>
                        <button type="button" id="cancelUpdate" class="submit-btn" style="background-color:#800000; margin-left:10px;">Cancel</button>
                    </form>
                </div>
            </div>
            <div id="message" class="message"></div>
        </section>
    </div>

    <script>
        // Navigation buttons
        const btnAirports = document.getElementById('btnAirports');
        const btnAircraft = document.getElementById('btnAircraft');
        const btnRoutes = document.getElementById('btnRoutes');

        const sectionAirports = document.getElementById('sectionAirports');
        const sectionAircraft = document.getElementById('sectionAircraft');
        const sectionRoutes = document.getElementById('sectionRoutes');

        btnAirports.addEventListener('click', () => {
            showSection('airports');
        });
        btnAircraft.addEventListener('click', () => {
            showSection('aircraft');
        });
        btnRoutes.addEventListener('click', () => {
            showSection('routes');
        });

        function showSection(section) {
            sectionAirports.classList.add('hidden');
            sectionAircraft.classList.add('hidden');
            sectionRoutes.classList.add('hidden');
            btnAirports.classList.remove('active');
            btnAircraft.classList.remove('active');
            btnRoutes.classList.remove('active');

            if (section === 'airports') {
                sectionAirports.classList.remove('hidden');
                btnAirports.classList.add('active');
            } else if (section === 'aircraft') {
                sectionAircraft.classList.remove('hidden');
                btnAircraft.classList.add('active');
            } else if (section === 'routes') {
                sectionRoutes.classList.remove('hidden');
                btnRoutes.classList.add('active');
            }
        }

        // Fetch and display data
        async function fetchData() {
            try {
                const response = await fetch('/airlines/retrieve-data');
                const data = await response.json();

                populateTable('tableAirports', data.airports);
                populateTable('tableAircraft', data.aircraft);
                populateRoutesTable(data.routes);
            } catch (error) {
                showMessage('Error fetching data: ' + error.message);
            }
        }

function populateTable(tableId, items) {
    const tbody = document.getElementById(tableId).querySelector('tbody');
    tbody.innerHTML = '';
    items.forEach((item, index) => {
        const tr = document.createElement('tr');
        if (tableId === 'tableAircraft') {
            tr.innerHTML = `
                <td>${index + 1}</td>
                <td>${item.registration_number || ''}</td>
                <td>${item.model || ''}</td>
                <td>${item.manufacturer || ''}</td>
                <td>${item.capacity || ''}</td>
                <td>${item.range_km || ''}</td>
                <td>${item.airline || ''}</td>
                <td>${item.baseAirport ? item.baseAirport.iata_code : item.base_iata || ''}</td>
            `;
        } else {
            for (const key in item) {
                const td = document.createElement('td');
                td.textContent = item[key];
                tr.appendChild(td);
            }
        }
        tbody.appendChild(tr);
    });
}

        function populateRoutesTable(routes) {
            const tbody = document.getElementById('tableRoutes').querySelector('tbody');
            tbody.innerHTML = '';
            routes.forEach(route => {
                const tr = document.createElement('tr');
                tr.innerHTML = `
                    <td>${route.id}</td>
                    <td>${route.route_id}</td>
                    <td>${route.aircraft_registration}</td>
                    <td>${route.status}</td>
                    <td>${route.weather_condition || ''}</td>
                    <td>${route.has_delay ? 'Yes' : 'No'}</td>
                    <td>${route.has_delay ? 60 : 0}</td>
                    <td>${route.delay_reason || ''}</td>
                    <td>
                        <button onclick="editRoute(${route.id})">Edit</button>
                    </td>
                `;
                tbody.appendChild(tr);
            });
        }

        // Show message
        function showMessage(msg) {
            const messageDiv = document.getElementById('message');
            messageDiv.textContent = msg;
            setTimeout(() => {
                messageDiv.textContent = '';
            }, 5000);
        }

        // Create route form submission
        document.getElementById('createRouteForm').addEventListener('submit', async (e) => {
            e.preventDefault();
            const form = e.target;
            const formData = new FormData(form);
            const data = Object.fromEntries(formData.entries());
            data.has_delay = data.has_delay === '1';

            try {
                const response = await fetch('/airlines/create-route', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Accept': 'application/json',
                        'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
                    },
                    body: JSON.stringify(data)
                });
                if (response.ok) {
                    showMessage('Route created successfully.');
                    form.reset();
                    fetchData();
                    // Scroll to the bottom where the message is displayed
                    window.scrollTo({ top: document.body.scrollHeight, behavior: 'smooth' });
                } else {
                    const errorData = await response.json();
                    showMessage('Error creating route: ' + JSON.stringify(errorData));
                }
            } catch (error) {
                showMessage('Error creating route: ' + error.message);
            }
        });

        // Edit route
        function editRoute(id) {
            const route = window.routesData.find(r => r.id === id);
            if (!route) return;

            document.getElementById('update_route_id_hidden').value = route.id;
            document.getElementById('update_route_id').value = route.route_id;
            document.getElementById('update_aircraft_registration').value = route.aircraft_registration;
            // Removed update_estimated_flight_time since field was removed
            document.getElementById('update_status').value = route.status;
            document.getElementById('update_weather_condition').value = route.weather_condition || '';
            document.getElementById('update_has_delay').value = route.has_delay ? '1' : '0';
            // Removed update_delay_time_start since field was removed
            // Removed update_delay_time_end since field was removed
            document.getElementById('update_delay_reason').value = route.delay_reason || '';

            document.getElementById('updateRouteForm').classList.remove('hidden');
            // Scroll to the update form but not all the way to the bottom
            document.getElementById('updateRouteForm').scrollIntoView({ behavior: 'smooth', block: 'start' });
        }

        // Cancel update
        document.getElementById('cancelUpdate').addEventListener('click', () => {
            document.getElementById('updateRouteForm').classList.add('hidden');
        });

        // Update route form submission
        document.getElementById('updateRouteForm').addEventListener('submit', async (e) => {
            e.preventDefault();
            const form = e.target;
            const id = document.getElementById('update_route_id_hidden').value;
            const formData = new FormData(form);
            const data = Object.fromEntries(formData.entries());
            data.has_delay = data.has_delay === '1';

            try {
                const response = await fetch('/airlines/update-route/' + id, {
                    method: 'PUT',
                    headers: {
                        'Content-Type': 'application/json',
                        'Accept': 'application/json',
                        'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
                    },
                    body: JSON.stringify(data)
                });
                if (response.ok) {
                    showMessage('Route updated successfully.');
                    form.reset();
                    form.classList.add('hidden');
                    fetchData();
                } else {
                    const errorData = await response.json();
                    showMessage('Error updating route: ' + JSON.stringify(errorData));
                }
            } catch (error) {
                showMessage('Error updating route: ' + error.message);
            }
        });

        // Store routes data globally for editing
        window.routesData = [];

        // Fetch data initially and store routes globally
        async function init() {
            try {
                const response = await fetch('/airlines/retrieve-data');
                const data = await response.json();
                window.routesData = data.routes;
                populateTable('tableAirports', data.airports);
                populateTable('tableAircraft', data.aircraft);
                populateRoutesTable(data.routes);
            } catch (error) {
                showMessage('Error fetching data: ' + error.message);
            }
        }

        init();
    </script>
</body>
</html>

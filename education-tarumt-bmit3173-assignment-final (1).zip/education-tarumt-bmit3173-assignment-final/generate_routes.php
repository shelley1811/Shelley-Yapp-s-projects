<?php
/**
 * Name: Daniel Aidan Edmund
 */
echo "-- Routes table definition\n";
echo "DROP TABLE IF EXISTS routes;\n";
echo "CREATE TABLE routes (\n";
echo "    id INTEGER PRIMARY KEY AUTOINCREMENT,\n";
echo "    route_id VARCHAR(255) NOT NULL UNIQUE,\n";
echo "    aircraft_registration VARCHAR(255) NOT NULL,\n";
echo "    status VARCHAR(20) DEFAULT 'active',\n";
echo "    weather_condition VARCHAR(255),\n";
echo "    has_delay INTEGER DEFAULT 0,\n";
echo "    delay_in_minutes INTEGER DEFAULT 0,\n";
echo "    delay_reason VARCHAR(255)\n";
echo ");\n\n";

$aircraft_regs = [];

$aircraft_file = 'aircraft.sql';
if (file_exists($aircraft_file)) {
    $content = file_get_contents($aircraft_file);
    // Remove BOM or non-ASCII characters at the start
    $content = preg_replace('/^\xEF\xBB\xBF/', '', $content);
    // Extract all registration_number values from INSERT statements
    preg_match_all("/INSERT OR IGNORE INTO aircraft .*?VALUES\\s*(\\(.+?\\))/s", $content, $insertMatches);
    $aircraft_regs = [];
    if (!empty($insertMatches[1])) {
        foreach ($insertMatches[1] as $valuesGroup) {
            preg_match_all("/\\('([^']+)'/", $valuesGroup, $valueMatches);
            if (!empty($valueMatches[1])) {
                // The first value in each tuple is registration_number
                $aircraft_regs[] = $valueMatches[1][0];
            }
        }
    }
}

echo "-- Sample data\n";
echo "INSERT OR IGNORE INTO routes (route_id, aircraft_registration, status, weather_condition, has_delay, delay_in_minutes, delay_reason) VALUES\n";

$route_ids = [
    'KUL-SBH458', 'SBH-KUL732', 'SBH-KUL194', 'PEN-LBU865', 'LGK-MYY309', 'JHB-TWU671', 'BKI-KUL128', 'MYY-JHB547', 'KCH-PEN803', 'TWU-LGK256',
    'LBU-BKI984', 'KUL-MYY413', 'SBH-JHB790', 'PEN-KCH602', 'LGK-SBH375', 'JHB-LBU149', 'BKI-TWU928', 'MYY-KUL284', 'KCH-LGK671', 'TWU-PEN503',
    'LBU-SBH317', 'KUL-LGK846', 'SBH-BKI190', 'PEN-JHB728', 'LGK-KCH659', 'JHB-MYY402', 'BKI-PEN577', 'MYY-TWU831', 'KCH-JHB265', 'TWU-KUL994',
    'LBU-MYY312', 'KUL-KCH759', 'SBH-LGK186', 'PEN-TWU640', 'LGK-JHB501', 'JHB-KUL823', 'BKI-MYY278', 'MYY-LBU690', 'KCH-SBH347', 'TWU-JHB105',
    'LBU-KCH921', 'KUL-TWU134', 'SBH-MYY788', 'PEN-BKI219', 'LGK-LBU466', 'JHB-SBH553', 'BKI-JHB382', 'MYY-KCH607', 'KCH-LBU845', 'TWU-SBH341'
];

$statuses = ['active', 'inactive', 'cancelled'];
$weather_conditions = ['Sunny', 'Cloudy', 'Rainy', 'Stormy', null];

for ($i = 0; $i < 50; $i++) {
    $route_id = $route_ids[$i];
    // Assign aircraft registration numbers from a fixed list of known registrations
    $fixed_aircraft_regs = [
        '9M-MAA001', '9M-MAA002', '9M-MAA003', '9M-MAA004', '9M-MAA005', '9M-MAA006', '9M-MAA007', '9M-MAA008', '9M-MAA009', '9M-MAA010',
        '9M-MAA011', '9M-MAA012', '9M-MAA013', '9M-MAA014', '9M-MAA015', '9M-MAA016', '9M-MAA017', '9M-MAA018', '9M-MAA019', '9M-MAA020',
        '9M-MAA021', '9M-MAA022', '9M-MAA023', '9M-MAA024', '9M-AKA001', '9M-AKA002', '9M-AKA003', '9M-AKA004', '9M-AKA005', '9M-AKA006',
        '9M-AKA007', '9M-AKA008', '9M-AKA009', '9M-AKA010', '9M-AKA011', '9M-AKA012', '9M-AKA013', '9M-AKA014', '9M-AKA015', '9M-AKA016',
        '9M-AKA017', '9M-AKA018', '9M-AKA019', '9M-AKA020', '9M-BKA001', '9M-BKA002', '9M-BKA003', '9M-BKA004', '9M-BKA005', '9M-BKA006',
        '9M-BKA007', '9M-BKA008', '9M-BKA009', '9M-BKA010', '9M-BKA011', '9M-BKA012', '9M-FYA001', '9M-FYA002', '9M-FYA003', '9M-FYA004',
        '9M-FYA005', '9M-FYA006', '9M-FYA007', '9M-FYA008', '9M-MSA001', '9M-MSA002', '9M-MSA003', '9M-MSA004', '9M-MSA005', '9M-MSA006',
        '9M-MSA007', '9M-MSA008'
    ];
    $aircraft_reg = $fixed_aircraft_regs[$i % count($fixed_aircraft_regs)];
    $status = $statuses[array_rand($statuses)];
    $weather_condition = $weather_conditions[array_rand($weather_conditions)];
    $has_delay = rand(0, 1);
    $delay_in_minutes = $has_delay ? 60 : 0;
    $delay_reason = $has_delay ? 'Weather delay' : null;

    echo "('$route_id', '$aircraft_reg', '$status', " . ($weather_condition ? "'$weather_condition'" : 'NULL') . ", $has_delay, $delay_in_minutes, " . ($delay_reason ? "'$delay_reason'" : 'NULL') . ")";
    if ($i < 49) echo ",\n";
    else echo ";\n";
}

<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class FlightScheduleSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // ✅ Get all existing route_ids from routes table to avoid foreign key errors
        $route_ids = DB::table('routes')->pluck('route_id')->toArray();

        // ✅ Get aircraft registration numbers from DB
        $aircrafts = DB::table('aircraft')->pluck('registration_number')->toArray();
        $aircrafts = array_values($aircrafts); // Reindex for random selection

        foreach ($route_ids as $route_id) {
            // Parse e.g. KUL-SBH458 into KUL and SBH (IATA codes)
            if (!preg_match('/^([A-Z]{3})-([A-Z]{3})\\d{3}$/', $route_id, $m)) {
                continue; // Skip malformed IDs safely
            }

            $departure_airport = $m[1];
            $arrival_airport = $m[2];

            // Generate random departure date within next 30 days
            $departure_date = Carbon::now()->addDays(rand(1, 30))->toDateString();

            // Generate random departure time and arrival time based on duration
            $departure_time = Carbon::createFromTime(rand(0, 23), rand(0, 59), 0);
            $duration_minutes = rand(60, 240);
            $arrival_time = (clone $departure_time)->addMinutes($duration_minutes);

            // Random gate between A-D and 1-10
            $gate = chr(rand(65, 68)) . rand(1, 10);

            // Safe aircraft selection (may be null if no aircraft exists)
            $aircraft = count($aircrafts) ? $aircrafts[array_rand($aircrafts)] : null;

            // ✅ Insert schedule linked to valid route_id and aircraft
            DB::table('flight_schedules')->insert([
                'route_id'                        => $route_id,
                'departure_airport'               => $departure_airport,
                'arrival_airport'                 => $arrival_airport,
                'departure_date'                  => $departure_date,
                'departure_time'                  => $departure_time->format('H:i:s'),
                'arrival_time'                    => $arrival_time->format('H:i:s'),
                'gate'                            => $gate,
                'aircraft_registration_number'    => $aircraft,
            ]);
        }
    }
}
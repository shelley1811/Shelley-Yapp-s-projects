<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class CrewAssignmentsSeeder extends Seeder
{
    public function run(): void
    {
        \App\Models\CrewAssignment::factory()->count(3)->create();
        \App\Models\CrewAssignment::factory()->sent()->count(2)->create();
    }
}

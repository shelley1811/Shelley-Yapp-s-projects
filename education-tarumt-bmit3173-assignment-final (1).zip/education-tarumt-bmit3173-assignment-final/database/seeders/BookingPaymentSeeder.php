<?php

namespace Database\Seeders;

// use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use App\Models\{Flight, Booking, BookingItem, Payment};

class BookingPaymentSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // ------------------------------------------------------------
        // Flights (6 examples) — duration in MINUTES, MYR as double, date as YYYY-MM-DD
        // ------------------------------------------------------------
        $f1 = Flight::create([
            'flight_no' => 'SR101', 'origin' => 'KUL', 'destination' => 'KCH',
            'flight_date' => '2025-10-01', 'departure_time' => '08:30:00', 'arrival_time' => '10:10:00',
            'duration_minutes' => 100, 'base_fare_myr' => 199.00, 'seats_total' => 180, 'seats_available' => 180,
        ]);

        $f2 = Flight::create([
            'flight_no' => 'SR202', 'origin' => 'PEN', 'destination' => 'LGK',
            'flight_date' => '2025-10-02', 'departure_time' => '14:15:00', 'arrival_time' => '14:50:00',
            'duration_minutes' => 35, 'base_fare_myr' => 89.00, 'seats_total' => 180, 'seats_available' => 180,
        ]);

        $f3 = Flight::create([
            'flight_no' => 'SR303', 'origin' => 'KUL', 'destination' => 'PEN',
            'flight_date' => '2025-10-03', 'departure_time' => '07:00:00', 'arrival_time' => '08:05:00',
            'duration_minutes' => 65, 'base_fare_myr' => 120.00, 'seats_total' => 180, 'seats_available' => 180,
        ]);

        $f4 = Flight::create([
            'flight_no' => 'SR404', 'origin' => 'KCH', 'destination' => 'KUL',
            'flight_date' => '2025-10-04', 'departure_time' => '12:00:00', 'arrival_time' => '13:40:00',
            'duration_minutes' => 100, 'base_fare_myr' => 199.00, 'seats_total' => 180, 'seats_available' => 180,
        ]);

        $f5 = Flight::create([
            'flight_no' => 'SR505', 'origin' => 'JHB', 'destination' => 'KUL',
            'flight_date' => '2025-10-05', 'departure_time' => '09:30:00', 'arrival_time' => '10:25:00',
            'duration_minutes' => 55, 'base_fare_myr' => 99.00, 'seats_total' => 180, 'seats_available' => 180,
        ]);

        $f6 = Flight::create([
            'flight_no' => 'SR606', 'origin' => 'KUL', 'destination' => 'BKI',
            'flight_date' => '2025-10-06', 'departure_time' => '11:00:00', 'arrival_time' => '13:35:00',
            'duration_minutes' => 155, 'base_fare_myr' => 259.00, 'seats_total' => 180, 'seats_available' => 180,
        ]);

        // Convenience closure to add one passenger to a booking and compute totals
        $addItem = function (Booking $booking, Flight $flight, string $passenger, ?string $seat, float $fare, float $tax) {
            $item = BookingItem::create([
                'booking_id' => $booking->id,
                'flight_id'  => $flight->id,
                'passenger_name' => $passenger,
                'seat_no' => $seat,
                'fare_class' => 'ECON',
                'unit_price_myr' => $fare,    // MYR as double
                'tax_myr' => $tax,
                'quantity' => 1,
            ]);

            $booking->update([
                'grand_total_myr' => ($booking->grand_total_myr ?? 0) + $item->line_total_myr,
            ]);

            $flight->decrement('seats_available', 1);

            return $item;
        };

        // ------------------------------------------------------------
        // Bookings (10 total) with payments to cover several scenarios
        // ------------------------------------------------------------

        // 1) PENDING (awaiting payment; 5-min hold)
        $b1 = Booking::create([
            'booking_ref' => Str::upper(Str::random(6)),
            'contact_name' => 'Ali Bin Salleh', 'contact_email' => 'ali@example.com',
            'status' => 'PENDING', 'expires_at' => now()->addMinutes(5),
        ]);
        $addItem($b1, $f1, 'Ali Bin Salleh', null, 199.00, 20.00);
        $b1->update(['paid_total_myr' => 0]);

        // 2) CONFIRMED (fully paid)
        $b2 = Booking::create([
            'booking_ref' => Str::upper(Str::random(6)),
            'contact_name' => 'Siti Noor', 'contact_email' => 'siti@example.com',
            'status' => 'PENDING', 'expires_at' => now()->addMinutes(5),
        ]);
        $addItem($b2, $f2, 'Siti Noor', '12A', 89.00, 10.00);
        Payment::create([
            'booking_id' => $b2->id, 'status' => 'SUCCEEDED', 'amount_myr' => $b2->grand_total_myr,
            'method' => 'CARD', 'provider' => 'fakepay', 'transaction_ref' => 'FP-'.Str::upper(Str::random(10)),
            'paid_at' => now(), 'payload' => ['note' => 'Sandbox capture OK'],
        ]);
        $b2->update(['status' => 'CONFIRMED', 'paid_total_myr' => $b2->grand_total_myr]);

        // 3) PENDING with PARTIAL payment
        $b3 = Booking::create([
            'booking_ref' => Str::upper(Str::random(6)),
            'contact_name' => 'Raj Kumar', 'contact_email' => 'raj@example.com',
            'status' => 'PENDING', 'expires_at' => now()->addMinutes(30),
        ]);
        $addItem($b3, $f3, 'Raj Kumar', null, 120.00, 12.00);   // total 132.00
        Payment::create([
            'booking_id' => $b3->id, 'status' => 'SUCCEEDED', 'amount_myr' => 50.00,
            'method' => 'CARD', 'provider' => 'fakepay', 'transaction_ref' => 'FP-'.Str::upper(Str::random(10)),
            'paid_at' => now(), 'payload' => ['note' => 'Partial payment'],
        ]);
        $b3->update(['paid_total_myr' => 50.00]);               // still PENDING

        // 4) EXPIRED hold (window passed)
        $b4 = Booking::create([
            'booking_ref' => Str::upper(Str::random(6)),
            'contact_name' => 'Chong Wei', 'contact_email' => 'chong@example.com',
            'status' => 'EXPIRED', 'expires_at' => now()->subMinutes(10),
        ]);
        $addItem($b4, $f4, 'Chong Wei', null, 199.00, 20.00);
        $b4->update(['paid_total_myr' => 0]);

        // 5) PENDING (fresh)
        $b5 = Booking::create([
            'booking_ref' => Str::upper(Str::random(6)),
            'contact_name' => 'Ng Mei Ling', 'contact_email' => 'ngml@example.com',
            'status' => 'PENDING', 'expires_at' => now()->addMinutes(20),
        ]);
        $addItem($b5, $f5, 'Ng Mei Ling', '7C', 99.00, 10.00);
        $b5->update(['paid_total_myr' => 0]);

        // 6) CONFIRMED (big fare; fully paid)
        $b6 = Booking::create([
            'booking_ref' => Str::upper(Str::random(6)),
            'contact_name' => 'Lina Ahmad', 'contact_email' => 'lina@example.com',
            'status' => 'PENDING', 'expires_at' => now()->addMinutes(5),
        ]);
        $addItem($b6, $f6, 'Lina Ahmad', '2B', 259.00, 26.00);  // total 285.00
        Payment::create([
            'booking_id' => $b6->id, 'status' => 'SUCCEEDED', 'amount_myr' => $b6->grand_total_myr,
            'method' => 'CARD', 'provider' => 'fakepay', 'transaction_ref' => 'FP-'.Str::upper(Str::random(10)),
            'paid_at' => now(), 'payload' => ['note' => 'Full payment'],
        ]);
        $b6->update(['status' => 'CONFIRMED', 'paid_total_myr' => $b6->grand_total_myr]);

        // 7) PENDING with a FAILED attempt
        $b7 = Booking::create([
            'booking_ref' => Str::upper(Str::random(6)),
            'contact_name' => 'Farid Rahman', 'contact_email' => 'farid@example.com',
            'status' => 'PENDING', 'expires_at' => now()->addMinutes(10),
        ]);
        $addItem($b7, $f1, 'Farid Rahman', null, 199.00, 20.00);
        Payment::create([
            'booking_id' => $b7->id, 'status' => 'FAILED', 'amount_myr' => 219.00,
            'method' => 'CARD', 'provider' => 'fakepay', 'transaction_ref' => null,
            'paid_at' => null, 'payload' => ['error' => 'Card declined (seeded)'],
        ]);
        $b7->update(['paid_total_myr' => 0]);

        // 8) CANCELLED (no payments)
        $b8 = Booking::create([
            'booking_ref' => Str::upper(Str::random(6)),
            'contact_name' => 'Arif Musa', 'contact_email' => 'arif@example.com',
            'status' => 'CANCELLED', 'expires_at' => now()->addMinutes(5),
        ]);
        $addItem($b8, $f2, 'Arif Musa', '15D', 89.00, 10.00);
        $b8->update(['paid_total_myr' => 0]);

        // 9) CONFIRMED via two partial payments
        $b9 = Booking::create([
            'booking_ref' => Str::upper(Str::random(6)),
            'contact_name' => 'Nora Ibrahim', 'contact_email' => 'nora@example.com',
            'status' => 'PENDING', 'expires_at' => now()->addMinutes(30),
        ]);
        $addItem($b9, $f3, 'Nora Ibrahim', '9A', 120.00, 12.00);     // total 132.00
        Payment::create([
            'booking_id' => $b9->id, 'status' => 'SUCCEEDED', 'amount_myr' => 50.00,
            'method' => 'CARD', 'provider' => 'fakepay', 'transaction_ref' => 'FP-'.Str::upper(Str::random(10)),
            'paid_at' => now(), 'payload' => ['note' => 'First partial'],
        ]);
        Payment::create([
            'booking_id' => $b9->id, 'status' => 'SUCCEEDED', 'amount_myr' => 82.00,
            'method' => 'CARD', 'provider' => 'fakepay', 'transaction_ref' => 'FP-'.Str::upper(Str::random(10)),
            'paid_at' => now(), 'payload' => ['note' => 'Second partial'],
        ]);
        $b9->update(['paid_total_myr' => 132.00, 'status' => 'CONFIRMED']);

        // 10) PENDING (fresh)
        $b10 = Booking::create([
            'booking_ref' => Str::upper(Str::random(6)),
            'contact_name' => 'Fatimah Zain', 'contact_email' => 'fzm@example.com',
            'status' => 'PENDING', 'expires_at' => now()->addMinutes(25),
        ]);
        $addItem($b10, $f5, 'Fatimah Zain', null, 99.00, 10.00);
        $b10->update(['paid_total_myr' => 0]);

        $this->command?->info('Seeded: 6 flights, 10 bookings (mix of PENDING/CONFIRMED/EXPIRED/CANCELLED).');
    }
}

<?php
/* Daniel Aidan Edmund*/

/**
 * This file fills the airports table with sample data.
 */

namespace Database\Seeders; // This tells PHP where this file belongs

use App\Models\Airport; // Brings in the Airport model so we can work with airport data
//use Illuminate\Database\Console\Seeds\WithoutModelEvents; // This line is commented out, not needed
use Illuminate\Database\Seeder; // Base class for all seeders

class AirportSeeder extends Seeder
{
    /**
     * This function runs when we want to add airport data to the database.
     * It's like opening the airports storage box and putting items inside.
     */
    public function run(): void
    {
        // Load the airport data from another file (like reading a list of airports to put in the box)
        $airports = include database_path('seeders/airports_seeder_data.php');

        // Go through each airport in the list
        foreach ($airports as $airport) {
            // Either update an existing airport or create a new one if it doesn't exist
            // This prevents duplicates - if the airport is already there, we update it; if not, we add it
            Airport::updateOrCreate(
                ['iata_code' => $airport['iata_code']], // Use IATA code to check if it exists
                $airport // Use all the data from the list
            );
        }
    }
}

<?php
/* Daniel Aidan Edmund*/

/**
 * This file fills the aircraft table with sample data.
 */

namespace Database\Seeders; // This tells PHP where this file belongs in the project

use App\Models\Aircraft; // This brings in the Aircraft model so we can work with aircraft data
//use Illuminate\Database\Console\Seeds\WithoutModelEvents; // This line is commented out, it's not needed right now
use Illuminate\Database\Seeder; // This is the base class for all seeders in Laravel

class AircraftSeeder extends Seeder
{
    /**
     * This function runs when we want to add aircraft data to the database.
     * It's like opening the storage box and putting items inside.
     */
    public function run(): void
    {
        // Load the aircraft data from another file (like reading a list of items to put in the box)
        $aircraft = include database_path('seeders/aircraft_seeder_data.php');

        // Go through each aircraft in the list
        foreach ($aircraft as $plane) {
            // Either update an existing aircraft or create a new one if it doesn't exist
            // This prevents duplicates - if the aircraft is already there, we update it; if not, we add it
            Aircraft::updateOrCreate(
                ['registration_number' => $plane['registration_number']], // Use registration number to check if it exists
                $plane // Use all the data from the list
            );
        }
    }
}

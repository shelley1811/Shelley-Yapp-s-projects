<?php
/* Daniel Aidan Edmund*/

/**
 * This file fills the routes table with sample flight route data.
 */

namespace Database\Seeders;

use App\Models\Route; 
//use Illuminate\Database\Console\Seeds\WithoutModelEvents; 
use Illuminate\Database\Seeder; 

class RoutesSeeder extends Seeder
{
    /**
     * This function runs when we want to add route data to the database.
     */
    public function run(): void
    {
        // Load the route data from another file (like reading a list of routes to put in the box)
        $routes = include database_path('seeders/routes_seeder_data.php');

        // Go through each route in the list
        foreach ($routes as $route) {
            Route::updateOrCreate(
                ['route_id' => $route['route_id']], // Use route ID to check if it exists
                $route // Use all the data from the list
            );
        }
    }
}

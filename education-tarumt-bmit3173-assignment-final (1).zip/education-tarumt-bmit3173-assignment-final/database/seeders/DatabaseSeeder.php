<?php

/**
 * This is the main seeder file that runs all other seeders.
 */

namespace Database\Seeders; 

use App\Models\User; 
// use Illuminate\Database\Console\Seeds\WithoutModelEvents; // This line is commented out, not needed
use Illuminate\Database\Seeder; 

class DatabaseSeeder extends Seeder
{

    public function run(): void
    {
        // These lines are commented out because they would create test users
        // User::factory(10)->create(); // Would create 10 fake users
        // User::factory()->create([ // Would create one specific test user
        //     'name' => 'Test User',
        //     'email' => 'test@example.com',
        // ]);

        // This calls the AirportSeeder, AircraftSeeder, and RoutesSeeder
        $this->call([
            AirportSeeder::class, // Fill airports table
            AircraftSeeder::class, // Fill aircraft table
            RoutesSeeder::class, // Fill routes table
            BookingPaymentSeeder::class, // Fill booking + payment table
            CrewAssignmentsSeeder::class,
            FlightScheduleSeeder::class, // Fill flight schedules table
        ]);
    }
}

<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class ModifyRoutesTableAddDelayMinutes extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('routes', function (Blueprint $table) {
            if (Schema::hasColumn('routes', 'delay_time_start')) {
                $table->dropColumn('delay_time_start');
            }
            if (Schema::hasColumn('routes', 'delay_time_end')) {
                $table->dropColumn('delay_time_end');
            }
            if (!Schema::hasColumn('routes', 'delay_in_minutes')) {
                $table->integer('delay_in_minutes')->default(0)->after('has_delay');
            }
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('routes', function (Blueprint $table) {
            if (Schema::hasColumn('routes', 'delay_in_minutes')) {
                $table->dropColumn('delay_in_minutes');
            }
            if (!Schema::hasColumn('routes', 'delay_time_start')) {
                $table->time('delay_time_start')->nullable()->after('has_delay');
            }
            if (!Schema::hasColumn('routes', 'delay_time_end')) {
                $table->time('delay_time_end')->nullable()->after('delay_time_start');
            }
        });
    }
}

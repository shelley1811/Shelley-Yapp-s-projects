<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::table('crew_assignments', function (Blueprint $table) {
            $table->foreignId('crew_id')->nullable()->after('id')->constrained('crews')->nullOnDelete();
            $table->index('crew_phone'); 
        });

        $pairs = DB::table('crew_assignments')
            ->select('id', 'crew_phone')
            ->whereNotNull('crew_phone')
            ->get();

        if ($pairs->count()) {
            $phones = $pairs->pluck('crew_phone')->filter()->unique()->values();
            foreach ($phones as $phone) {
                $crewId = DB::table('crews')->where('phone', $phone)->value('id');
                if (!$crewId) {
                    $crewId = DB::table('crews')->insertGetId([
                        'phone' => $phone,
                        'created_at' => now(),
                        'updated_at' => now(),
                    ]);
                }
                DB::table('crew_assignments')->where('crew_phone', $phone)->update(['crew_id' => $crewId]);
            }
        }
    }

    public function down(): void
    {
        Schema::table('crew_assignments', function (Blueprint $table) {
            $table->dropConstrainedForeignId('crew_id');
        });
    }
};

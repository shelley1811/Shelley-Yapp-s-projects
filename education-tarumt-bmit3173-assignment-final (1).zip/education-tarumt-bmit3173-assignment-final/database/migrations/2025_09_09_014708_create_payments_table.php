<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('payments', function (Blueprint $table) {
            $table->id();
            $table->foreignId('booking_id')->constrained()->cascadeOnDelete();

            $table->enum('status', ['PENDING','SUCCEEDED','FAILED','REFUNDED'])
                  ->default('PENDING');
            $table->double('amount_myr', 10, 2);
            $table->string('method', 20)->default('CARD');
            $table->string('provider', 30)->default('fakepay'); // simple sandbox
            $table->string('transaction_ref')->nullable();
            $table->timestamp('paid_at')->nullable();
            $table->json('payload')->nullable(); // raw gateway payload/token
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('payments');
    }
};

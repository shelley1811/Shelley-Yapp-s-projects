<?php
/**
 * Name: Daniel Aidan Edmund
 * Creating aircraft table migration
 *
 */
use Illuminate\Database\Migrations\Migration; 
use Illuminate\Database\Schema\Blueprint; 
use Illuminate\Support\Facades\Schema; 

class CreateAircraftTable extends Migration
{
    /**
     * This function runs when we want to create the table.
     *
     * @return void
     */
    public function up()
    {
        // Create a new table called 'aircraft' in the database
        Schema::create('aircraft', function (Blueprint $table) {
            $table->id(); // This creates an automatic number for each aircraft (like a unique ID)
            $table->string('registration_number')->unique(); // Each aircraft has a unique registration number (like a license plate)
            $table->string('model'); // The type of aircraft, like "Boeing 737"
            $table->string('manufacturer'); // Who made the aircraft, like "Boeing"
            $table->integer('capacity'); // How many passengers it can carry
            $table->integer('range_km'); // How far it can fly in kilometers
            $table->string('airline'); // Which airline owns this aircraft
            $table->string('base_iata'); // The airport code where this aircraft is based (connects to airports table)
        });
    }

    /**
     * This function runs if we need to undo the changes.
     *
     * @return void
     */
    public function down()
    {
        // Remove the aircraft table if it exists
        Schema::dropIfExists('aircraft');
    }
}

<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void {
        Schema::table('crews', function (Blueprint $table) {
            $table->dropUnique('crews_phone_unique');
            $table->unique(['phone', 'deleted_at'], 'crews_phone_deleted_at_unique');
        });
    }
    public function down(): void {
        Schema::table('crews', function (Blueprint $table) {
            $table->dropUnique('crews_phone_deleted_at_unique');
            $table->unique('phone', 'crews_phone_unique');
        });
    }
};

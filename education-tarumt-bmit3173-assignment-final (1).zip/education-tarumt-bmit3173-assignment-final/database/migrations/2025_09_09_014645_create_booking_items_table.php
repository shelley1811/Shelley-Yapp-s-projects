<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('booking_items', function (Blueprint $table) {
            $table->id();
            $table->foreignId('booking_id')->constrained()->cascadeOnDelete();
            $table->foreignId('flight_id')->constrained()->restrictOnDelete();

            // store pax per item (keeps it simple; no separate passengers table)
            $table->string('passenger_name');
            $table->string('seat_no', 5)->nullable();
            $table->string('fare_class', 10)->default('ECON');

            // MYR as double
            $table->double('unit_price_myr', 10, 2);
            $table->double('tax_myr', 10, 2)->default(0);
            $table->unsignedTinyInteger('quantity')->default(1);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('booking_items');
    }
};

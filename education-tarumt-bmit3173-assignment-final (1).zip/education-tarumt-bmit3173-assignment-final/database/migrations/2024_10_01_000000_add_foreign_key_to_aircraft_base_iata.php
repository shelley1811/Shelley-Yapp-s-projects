<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddForeignKeyToAircraftBaseIata extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('aircraft', function (Blueprint $table) {
            // Change base_iata column length to 3 to match airports.iata_code
            $table->string('base_iata', 3)->change();

            // Add foreign key constraint
            $table->foreign('base_iata')->references('iata_code')->on('airports')->onDelete('restrict');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('aircraft', function (Blueprint $table) {
            $table->dropForeign(['base_iata']);
            // Optionally revert base_iata column length to previous state (string without length)
            $table->string('base_iata')->change();
        });
    }
}

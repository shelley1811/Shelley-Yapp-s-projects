<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        if (!Schema::hasTable('crew_assignments')) {
            Schema::create('crew_assignments', function (Blueprint $table) {
                $table->id();
                $table->string('crew_phone', 20);
                $table->string('flight_no', 20);
                $table->dateTime('dep_time');
                $table->string('role', 20)->nullable();
                $table->enum('status', ['queued', 'sent', 'failed'])->default('queued');
                $table->timestamp('sent_at')->nullable();
                $table->string('vendor_message_id')->nullable();
                $table->json('vendor_payload')->nullable();
                $table->string('channel', 20)->default('whatsapp');
                $table->timestamps();
            });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('crew_assignments');
    }
};

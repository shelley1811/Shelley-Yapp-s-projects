<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::table('crew_assignments', function (Blueprint $table) {
            $table->unique(['crew_phone', 'flight_no', 'dep_time'], 'uniq_crew_flight_dep');
        });
    }

    public function down(): void
    {
        Schema::table('crew_assignments', function (Blueprint $table) {
            $table->dropUnique('uniq_crew_flight_dep');
        });
    }
};

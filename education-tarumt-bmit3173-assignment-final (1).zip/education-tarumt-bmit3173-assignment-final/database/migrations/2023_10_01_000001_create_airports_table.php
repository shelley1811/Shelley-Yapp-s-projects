<?php
/**
 * Name: Daniel Aidan Edmund
 * Creating airports table migration
 *
 * This file creates a table for storing airport information in the database.
 */
use Illuminate\Database\Migrations\Migration; 
use Illuminate\Database\Schema\Blueprint; 
use Illuminate\Support\Facades\Schema; 

class CreateAirportsTable extends Migration
{
    /**
     * This function creates the airports table.
     * @return void
     */
    public function up()
    {
        // Create a new table called 'airports' in the database
        Schema::create('airports', function (Blueprint $table) {
            $table->id(); // Creates an automatic number for each airport (unique ID)
            $table->string('iata_code', 10)->unique(); // Airport code like "LAX" or "JFK" (must be unique)
            $table->string('name'); // Full name of the airport
            $table->string('city'); // City where the airport is located
            $table->string('country'); // Country where the airport is located
            $table->decimal('latitude', 10, 7); // North-south position on Earth (GPS coordinate)
            $table->decimal('longitude', 10, 7); // East-west position on Earth (GPS coordinate)
        });
    }

    /**
     * This function removes the airports table if needed.
     *      
     * @return void
     */
    public function down()
    {
        // Remove the airports table if it exists
        Schema::dropIfExists('airports');
    }
}

<?php

/**
 * Name: Bryian Aldey
 * Creating flight schedule table migrations
 */

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('flight_schedules', function (Blueprint $table) {
            // route_id is the primary key (enforces 1-to-1 relationship with routes table)
            $table->string('route_id', 15)->primary();
            
            // Foreign keys to link departure and arrival airports (use IATA codes)
            $table->string('departure_airport', 5); // departure airport code
            $table->string('arrival_airport', 5);   // arrival airport code

            // Flight schedule details
            $table->date('departure_date');          // departure date (YYYY-MM-DD)
            $table->time('departure_time');          // departure time (HH:MM:SS)
            $table->time('arrival_time');            // arrival time (HH:MM:SS)

            // Optional gate info (may be NULL)
            $table->string('gate', 10)->nullable();

            // Foreign key to reference the aircraft used for the flight
            $table->string('aircraft_registration_number', 20);

            // =====================
            // Foreign Key Constraints
            // =====================

            // departure_airport must exist in airports.iata_code
            $table->foreign('departure_airport')
                  ->references('iata_code')
                  ->on('airports')
                  ->onDelete('cascade'); // If airport is deleted, remove schedule

            // arrival_airport must exist in airports.iata_code
            $table->foreign('arrival_airport')
                  ->references('iata_code')
                  ->on('airports')
                  ->onDelete('cascade');

            // aircraft_registration_number must exist in aircraft.registration_number
            $table->foreign('aircraft_registration_number')
                  ->references('registration_number')
                  ->on('aircraft')
                  ->onDelete('cascade');

           
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        // Drops the flight_schedules table if it exists
        Schema::dropIfExists('flight_schedules');
    }
};

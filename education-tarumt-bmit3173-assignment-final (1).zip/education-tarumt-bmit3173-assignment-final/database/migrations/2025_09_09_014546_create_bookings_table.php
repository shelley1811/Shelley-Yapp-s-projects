<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('bookings', function (Blueprint $table) {
            $table->id();
            $table->string('booking_ref', 10)->unique();
            $table->foreignId('user_id')->nullable()->constrained()->nullOnDelete();

            $table->string('contact_name');
            $table->string('contact_email');
            $table->string('contact_phone', 30)->nullable();

            $table->enum('status', ['PENDING','CONFIRMED','CANCELLED','EXPIRED'])
                  ->default('PENDING');
            $table->double('grand_total_myr', 10, 2)->default(0);
            $table->double('paid_total_myr', 10, 2)->default(0);
            $table->timestamp('expires_at')->nullable();   // now()+5min when created
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('bookings');
    }
};

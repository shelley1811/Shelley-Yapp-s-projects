<?php
/**
 * Name: Daniel Aidan Edmund
 * Creating route table migrations
 *
 * This file creates a table for storing flight route information in the database.
 */
use Illuminate\Database\Migrations\Migration; 
use Illuminate\Database\Schema\Blueprint; 
use Illuminate\Support\Facades\Schema; 

class CreateRoutesTable extends Migration
{
    /**
     * This function creates the routes table.
     *
     * @return void
     */
    public function up()
    {
        // Create a new table called 'routes' in the database
        Schema::create('routes', function (Blueprint $table) {
            $table->id(); // Creates an automatic number for each route (unique ID)
            $table->string('route_id')->unique(); // Unique code for this route, like "FL001"
            $table->string('aircraft_registration'); // Links to the aircraft flying this route
            $table->string('status'); // Current status of the route
            $table->string('weather_condition')->nullable(); // Weather info that might affect the flight
            $table->boolean('has_delay')->default(false); // True if the flight is delayed
            $table->integer('delay_in_minutes')->default(0); // Delay duration in minutes
            $table->string('delay_reason')->nullable(); // Why the flight is delayed
        });
    }

    /**
     * This function removes the routes table if needed.
     *
     * @return void
     */
    public function down()
    {
        // Remove the routes table if it exists
        Schema::dropIfExists('routes');
    }
}

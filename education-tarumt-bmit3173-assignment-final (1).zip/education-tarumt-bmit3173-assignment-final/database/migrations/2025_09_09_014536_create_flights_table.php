<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('flights', function (Blueprint $table) {
            $table->id();
            $table->string('flight_no', 8);
            $table->string('origin', 3);
            $table->string('destination', 3);
            $table->date('flight_date');
            $table->time('departure_time');
            $table->time('arrival_time');
            $table->unsignedInteger('duration_minutes');
            $table->double('base_fare_myr', 10, 2);
            $table->unsignedSmallInteger('seats_total')->default(180);
            $table->unsignedSmallInteger('seats_available')->default(180);
            $table->timestamps();
            $table->unique(['flight_no','flight_date']);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('flights');
    }
};

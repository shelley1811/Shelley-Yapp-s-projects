<?php

namespace Database\Factories;

use App\Models\CrewAssignment;
use Illuminate\Database\Eloquent\Factories\Factory;

class CrewAssignmentFactory extends Factory
{
    protected $model = CrewAssignment::class;

    public function definition(): array
    {
        return [
            'crew_phone' => '+60'.$this->faker->numerify('1########'),
            'flight_no'  => strtoupper($this->faker->bothify('??###')),
            'dep_time'   => $this->faker->dateTimeBetween('+1 hour', '+2 days'),
            'role'       => $this->faker->randomElement(['CPT','FO','FA']),
            'status'     => CrewAssignment::STATUS_QUEUED,
            'channel'    => 'whatsapp',
        ];
    }

    public function sent(): self
    {
        return $this->state(fn() => [
            'status' => CrewAssignment::STATUS_SENT,
            'sent_at'=> now(),
        ]);
    }
}

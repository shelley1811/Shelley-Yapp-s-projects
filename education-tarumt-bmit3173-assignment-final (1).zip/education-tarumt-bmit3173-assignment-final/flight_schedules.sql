-- Flight Schedules SQL Insert Script
-- Name: Bryian Aldey
-- Pre-populated flight schedules for testing

INSERT INTO flight_schedules (
    route_id, departure_airport, arrival_airport, departure_date, departure_time, arrival_time, gate, aircraft_registration_number, created_at, updated_at
) VALUES
    ('KUL-SBH458', 'KUL', 'SBH', '2025-09-15', '08:30:00', '11:30:00', 'A1', '9M-MAA001', NOW(), NOW()),
    ('SBH-KUL732', 'SBH', 'KUL', '2025-09-16', '14:00:00', '17:00:00', 'B2', '9M-MAA002', NOW(), NOW()),
    ('PEN-LBU865', 'PEN', 'LBU', '2025-09-17', '09:45:00', '12:15:00', 'C3', '9M-MAA003', NOW(), NOW()),
    ('LGK-MYY309', 'LGK', 'MYY', '2025-09-18', '07:00:00', '09:30:00', 'D4', '9M-MAA004', NOW(), NOW()),
    ('JHB-TWU671', 'JHB', 'TWU', '2025-09-19', '15:20:00', '18:50:00', 'E5', '9M-MAA005', NOW(), NOW()),
    ('BKI-KUL128', 'BKI', 'KUL', '2025-09-20', '10:10:00', '13:10:00', 'F6', '9M-MAA006', NOW(), NOW()),
    ('MYY-JHB547', 'MYY', 'JHB', '2025-09-21', '12:00:00', '14:30:00', 'G7', '9M-MAA007', NOW(), NOW()),
    ('KCH-PEN803', 'KCH', 'PEN', '2025-09-22', '06:50:00', '09:20:00', 'H8', '9M-MAA008', NOW(), NOW()),
    ('TWU-LGK256', 'TWU', 'LGK', '2025-09-23', '11:40:00', '14:40:00', 'I9', '9M-MAA009', NOW(), NOW()),
    ('LBU-BKI984', 'LBU', 'BKI', '2025-09-24', '13:15:00', '14:45:00', 'J10', '9M-MAA010', NOW(), NOW());

-- Routes table definition
-- Created by Daniel Aidan Edmund
--
-- This SQL file creates a table to store flight route information in the SkyReserve system.

-- Remove the old routes table if it exists (clean slate)
DROP TABLE IF EXISTS routes;

-- Create a new routes table with all the necessary columns
CREATE TABLE routes (
  id INTEGER PRIMARY KEY AUTOINCREMENT, -- Unique number for each route (auto-generated)
  route_id VARCHAR(255) NOT NULL UNIQUE, -- Unique identifier for this route (like MH370)
  aircraft_registration VARCHAR(255) NOT NULL, -- Which aircraft will fly this route
  status VARCHAR(20) DEFAULT 'active', -- Current status of the route (active, inactive, cancelled)
  weather_condition VARCHAR(255), -- Weather information that might affect the flight
  has_delay INTEGER DEFAULT 0, -- Whether this flight is delayed (1 = yes, 0 = no)
  delay_in_minutes INTEGER DEFAULT 0, -- Delay duration in minutes
  delay_reason VARCHAR(255) -- Why the flight is delayed
);

-- Sample data - This adds some example flight routes to our table
INSERT OR IGNORE INTO routes (route_id, aircraft_registration, status, weather_condition, has_delay, delay_in_minutes, delay_reason) VALUES
('KUL-SBH458', '9M-MAA001', 'inactive', 'Stormy', 1, 60, 'Weather delay'),
('SBH-KUL732', '9M-MAA002', 'cancelled', NULL, 1, 60, 'Weather delay'),
('SBH-KUL194', '9M-MAA003', 'inactive', 'Stormy', 0, 0, NULL),
('PEN-LBU865', '9M-MAA004', 'active', 'Sunny', 1, 60, 'Weather delay'),
('LGK-MYY309', '9M-MAA005', 'cancelled', 'Cloudy', 1, 60, 'Weather delay'),
('JHB-TWU671', '9M-MAA006', 'inactive', 'Rainy', 0, 0, NULL),
('BKI-KUL128', '9M-MAA007', 'cancelled', 'Sunny', 0, 0, NULL),
('MYY-JHB547', '9M-MAA008', 'cancelled', 'Sunny', 0, 0, NULL),
('KCH-PEN803', '9M-MAA009', 'active', 'Sunny', 0, 0, NULL),
('TWU-LGK256', '9M-MAA010', 'cancelled', 'Sunny', 0, 0, NULL),
('LBU-BKI984', '9M-MAA011', 'inactive', NULL, 0, 0, NULL),
('KUL-MYY413', '9M-MAA012', 'cancelled', NULL, 1, 60, 'Weather delay'),
('SBH-JHB790', '9M-MAA013', 'cancelled', 'Rainy', 1, 60, 'Weather delay'),
('PEN-KCH602', '9M-MAA014', 'cancelled', 'Stormy', 1, 60, 'Weather delay'),
('LGK-SBH375', '9M-MAA015', 'active', 'Stormy', 1, 60, 'Weather delay'),
('JHB-LBU149', '9M-MAA016', 'active', 'Rainy', 0, 0, NULL),
('BKI-TWU928', '9M-MAA017', 'cancelled', NULL, 1, 60, 'Weather delay'),
('MYY-KUL284', '9M-MAA018', 'cancelled', 'Rainy', 0, 0, NULL),
('KCH-LGK671', '9M-MAA019', 'cancelled', 'Sunny', 1, 60, 'Weather delay'),
('TWU-PEN503', '9M-MAA020', 'cancelled', 'Cloudy', 0, 0, NULL),
('LBU-SBH317', '9M-MAA021', 'cancelled', 'Cloudy', 1, 60, 'Weather delay'),
('KUL-LGK846', '9M-MAA022', 'inactive', 'Stormy', 1, 60, 'Weather delay'),
('SBH-BKI190', '9M-MAA023', 'active', 'Sunny', 1, 60, 'Weather delay'),
('PEN-JHB728', '9M-MAA024', 'cancelled', 'Cloudy', 1, 60, 'Weather delay'),
('LGK-KCH659', '9M-AKA001', 'cancelled', 'Sunny', 1, 60, 'Weather delay'),
('JHB-MYY402', '9M-AKA002', 'cancelled', 'Cloudy', 1, 60, 'Weather delay'),
('BKI-PEN577', '9M-AKA003', 'inactive', NULL, 0, 0, NULL),
('MYY-TWU831', '9M-AKA004', 'inactive', 'Sunny', 1, 60, 'Weather delay'),
('KCH-JHB265', '9M-AKA005', 'cancelled', 'Rainy', 0, 0, NULL),
('TWU-KUL994', '9M-AKA006', 'inactive', NULL, 0, 0, NULL),
('LBU-MYY312', '9M-AKA007', 'inactive', 'Rainy', 1, 60, 'Weather delay'),
('KUL-KCH759', '9M-AKA008', 'inactive', NULL, 0, 0, NULL),
('SBH-LGK186', '9M-AKA009', 'active', 'Stormy', 1, 60, 'Weather delay'),
('PEN-TWU640', '9M-AKA010', 'inactive', 'Sunny', 1, 60, 'Weather delay'),
('LGK-JHB501', '9M-AKA011', 'cancelled', 'Stormy', 1, 60, 'Weather delay'),
('JHB-KUL823', '9M-AKA012', 'inactive', NULL, 0, 0, NULL),
('BKI-MYY278', '9M-AKA013', 'active', 'Cloudy', 1, 60, 'Weather delay'),
('MYY-LBU690', '9M-AKA014', 'cancelled', NULL, 1, 60, 'Weather delay'),
('KCH-SBH347', '9M-AKA015', 'inactive', 'Rainy', 1, 60, 'Weather delay'),
('TWU-JHB105', '9M-AKA016', 'inactive', 'Cloudy', 0, 0, NULL),
('LBU-KCH921', '9M-AKA017', 'inactive', 'Cloudy', 1, 60, 'Weather delay'),
('KUL-TWU134', '9M-AKA018', 'inactive', NULL, 1, 60, 'Weather delay'),
('SBH-MYY788', '9M-AKA019', 'cancelled', 'Cloudy', 1, 60, 'Weather delay'),
('PEN-BKI219', '9M-AKA020', 'active', 'Cloudy', 0, 0, NULL),
('LGK-LBU466', '9M-BKA001', 'active', 'Sunny', 0, 0, NULL),
('JHB-SBH553', '9M-BKA002', 'active', 'Rainy', 0, 0, NULL),
('BKI-JHB382', '9M-BKA003', 'active', 'Cloudy', 1, 60, 'Weather delay'),
('MYY-KCH607', '9M-BKA004', 'inactive', 'Stormy', 0, 0, NULL),
('KCH-LBU845', '9M-BKA005', 'active', 'Cloudy', 1, 60, 'Weather delay'),
('TWU-SBH341', '9M-BKA006', 'active', 'Cloudy', 1, 60, 'Weather delay');
